package id.sejukjiwa.microscope

import android.Manifest
import android.content.ContentValues
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Matrix
import android.media.MediaScannerConnection
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.widget.Button
import android.widget.EditText
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.AspectRatio
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import kotlin.math.max
import kotlin.math.min

class MainActivity : AppCompatActivity() {

    private lateinit var previewView: PreviewView
    private lateinit var seekZoom: SeekBar
    private lateinit var seekBright: SeekBar
    private lateinit var txtZoom: TextView
    private lateinit var txtBright: TextView
    private lateinit var btnFlash: Button
    private lateinit var btnShot: Button
    private lateinit var btnFolder: Button

    private var camera: Camera? = null
    private var imageCapture: ImageCapture? = null
    private var hwMax = 1f      // zoom maksimum dari kamera (optik/hardware)
    private var zoom = 1f       // total zoom 1..20
    private var extra = 1f      // sisa zoom digital di atas hwMax
    private var torchOn = false
    private val io = Executors.newSingleThreadExecutor()
    private val prefs by lazy { getSharedPreferences("mic", MODE_PRIVATE) }

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            if (hasPerms()) startCamera()
            else Toast.makeText(this, "Izin kamera diperlukan", Toast.LENGTH_LONG).show()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        previewView = findViewById(R.id.preview)
        previewView.implementationMode = PreviewView.ImplementationMode.COMPATIBLE
        previewView.scaleType = PreviewView.ScaleType.FIT_CENTER
        seekZoom = findViewById(R.id.seekZoom)
        seekBright = findViewById(R.id.seekBright)
        txtZoom = findViewById(R.id.txtZoom)
        txtBright = findViewById(R.id.txtBright)
        btnFlash = findViewById(R.id.btnFlash)
        btnShot = findViewById(R.id.btnShot)
        btnFolder = findViewById(R.id.btnFolder)

        seekZoom.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, user: Boolean) {
                zoom = 1f + p / 10f
                applyZoom()
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })

        seekBright.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, user: Boolean) {
                val r = camera?.cameraInfo?.exposureState?.exposureCompensationRange ?: return
                val idx = r.lower + ((r.upper - r.lower) * p / 100f).toInt()
                camera?.cameraControl?.setExposureCompensationIndex(idx)
                txtBright.text = "Kecerahan  $p%"
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })

        btnFlash.setOnClickListener {
            torchOn = !torchOn
            camera?.cameraControl?.enableTorch(torchOn)
            btnFlash.text = if (torchOn) "Flash: ON" else "Flash: OFF"
        }
        btnShot.setOnClickListener { takePhoto() }
        btnFolder.setOnClickListener { askFolder() }

        if (hasPerms()) startCamera() else permLauncher.launch(neededPerms())
    }

    private fun neededPerms(): Array<String> =
        if (Build.VERSION.SDK_INT <= 28)
            arrayOf(Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE)
        else arrayOf(Manifest.permission.CAMERA)

    private fun hasPerms() = neededPerms().all {
        ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED
    }

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            val provider = future.get()
            val preview = Preview.Builder()
                .setTargetAspectRatio(AspectRatio.RATIO_4_3).build()
                .also { it.setSurfaceProvider(previewView.surfaceProvider) }
            imageCapture = ImageCapture.Builder()
                .setTargetAspectRatio(AspectRatio.RATIO_4_3)
                .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
                .build()
            provider.unbindAll()
            val cam = provider.bindToLifecycle(
                this, CameraSelector.DEFAULT_BACK_CAMERA, preview, imageCapture
            )
            camera = cam
            cam.cameraInfo.zoomState.observe(this) {
                hwMax = max(1f, it.maxZoomRatio)
                applyZoom()
            }
            btnFlash.isEnabled = cam.cameraInfo.hasFlashUnit()
            val r = cam.cameraInfo.exposureState.exposureCompensationRange
            if (r.upper == r.lower) {
                seekBright.isEnabled = false
                txtBright.text = "Kecerahan (tidak didukung kamera ini)"
            } else {
                val p = ((0 - r.lower) * 100f / (r.upper - r.lower)).toInt()
                seekBright.progress = p
                txtBright.text = "Kecerahan  $p%"
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun applyZoom() {
        val hw = min(zoom, hwMax)
        camera?.cameraControl?.setZoomRatio(hw)
        extra = zoom / hw
        previewView.scaleX = extra
        previewView.scaleY = extra
        txtZoom.text = String.format(Locale.US, "Zoom %.1fx", zoom)
    }

    private fun folderName(): String = prefs.getString("folder", "Microscope") ?: "Microscope"

    private fun askFolder() {
        val et = EditText(this).apply { setText(folderName()) }
        AlertDialog.Builder(this)
            .setTitle("Nama folder di galeri (Pictures/...)")
            .setView(et)
            .setPositiveButton("Simpan") { _, _ ->
                val n = et.text.toString().replace(Regex("[\\\\/:*?\"<>|]"), "").trim()
                if (n.isNotEmpty()) prefs.edit().putString("folder", n).apply()
                Toast.makeText(this, "Folder: Pictures/${folderName()}", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun takePhoto() {
        val ic = imageCapture ?: return
        val crop = extra
        btnShot.isEnabled = false
        ic.takePicture(io, object : ImageCapture.OnImageCapturedCallback() {
            override fun onCaptureSuccess(image: ImageProxy) {
                try {
                    val rot = image.imageInfo.rotationDegrees
                    var bmp = image.toBitmap()
                    image.close()
                    if (rot != 0) {
                        val m = Matrix().apply { postRotate(rot.toFloat()) }
                        bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
                    }
                    if (crop > 1.01f) {
                        val cw = (bmp.width / crop).toInt()
                        val ch = (bmp.height / crop).toInt()
                        bmp = Bitmap.createBitmap(
                            bmp, (bmp.width - cw) / 2, (bmp.height - ch) / 2, cw, ch
                        )
                    }
                    save(bmp)
                    runOnUiThread {
                        Toast.makeText(
                            this@MainActivity, "Tersimpan di Pictures/${folderName()}",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                } catch (e: Exception) {
                    runOnUiThread {
                        Toast.makeText(this@MainActivity, "Gagal: ${e.message}", Toast.LENGTH_LONG).show()
                    }
                } finally {
                    runOnUiThread { btnShot.isEnabled = true }
                }
            }

            override fun onError(e: ImageCaptureException) {
                runOnUiThread {
                    btnShot.isEnabled = true
                    Toast.makeText(this@MainActivity, "Gagal: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        })
    }

    private fun save(bmp: Bitmap) {
        val name = "MIC_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".jpg"
        val folder = folderName()
        if (Build.VERSION.SDK_INT >= 29) {
            val cv = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, name)
                put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/" + folder)
            }
            val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv)!!
            contentResolver.openOutputStream(uri)!!.use { bmp.compress(Bitmap.CompressFormat.JPEG, 95, it) }
        } else {
            val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), folder)
            dir.mkdirs()
            val f = File(dir, name)
            FileOutputStream(f).use { bmp.compress(Bitmap.CompressFormat.JPEG, 95, it) }
            MediaScannerConnection.scanFile(this, arrayOf(f.path), arrayOf("image/jpeg"), null)
        }
    }
}
