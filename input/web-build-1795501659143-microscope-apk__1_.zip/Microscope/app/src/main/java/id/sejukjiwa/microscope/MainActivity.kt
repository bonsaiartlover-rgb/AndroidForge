package id.sejukjiwa.microscope

import android.Manifest
import android.content.ContentValues
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Matrix
import android.media.MediaScannerConnection
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.MotionEvent
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.AspectRatio
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

class MainActivity : AppCompatActivity() {

    private lateinit var root: FrameLayout
    private lateinit var previewBox: FrameLayout
    private lateinit var previewView: PreviewView
    private lateinit var roller: ZoomRoller
    private lateinit var txtZoom: TextView
    private lateinit var seekBright: SeekBar
    private lateinit var txtBright: TextView
    private lateinit var btnFlash: TextView
    private lateinit var btnLock: TextView
    private lateinit var btnFolder: TextView
    private lateinit var btnShot: View
    private lateinit var focusRing: View

    private var camera: Camera? = null
    private var imageCapture: ImageCapture? = null
    private var hwMax = 1f      // zoom maksimum kamera (hardware)
    private var zoom = 1f       // total zoom 1..20
    private var extra = 1f      // sisa zoom digital di atas hwMax
    private var lastHw = 0f
    private var torchOn = false
    private var focusLocked = false
    private val io = Executors.newSingleThreadExecutor()
    private val prefs by lazy { getSharedPreferences("mic", MODE_PRIVATE) }

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            if (hasPerms()) startCamera()
            else Toast.makeText(this, "Izin kamera diperlukan", Toast.LENGTH_LONG).show()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        root = findViewById(R.id.root)
        previewBox = findViewById(R.id.previewBox)
        previewView = findViewById(R.id.preview)
        previewView.implementationMode = PreviewView.ImplementationMode.COMPATIBLE
        previewView.scaleType = PreviewView.ScaleType.FIT_CENTER
        roller = findViewById(R.id.roller)
        txtZoom = findViewById(R.id.txtZoom)
        seekBright = findViewById(R.id.seekBright)
        txtBright = findViewById(R.id.txtBright)
        btnFlash = findViewById(R.id.btnFlash)
        btnLock = findViewById(R.id.btnLock)
        btnFolder = findViewById(R.id.btnFolder)
        btnShot = findViewById(R.id.btnShot)
        focusRing = findViewById(R.id.focusRing)

        roller.value = 1f
        roller.onChange = { z ->
            zoom = z
            applyZoom()
        }

        seekBright.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, user: Boolean) {
                txtBright.text = "$p%"
                val r = camera?.cameraInfo?.exposureState?.exposureCompensationRange ?: return
                val idx = r.lower + ((r.upper - r.lower) * p / 100f).toInt()
                camera?.cameraControl?.setExposureCompensationIndex(idx)
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })

        btnFlash.setOnClickListener {
            torchOn = !torchOn
            camera?.cameraControl?.enableTorch(torchOn)
            btnFlash.isSelected = torchOn
        }
        btnShot.setOnClickListener { takePhoto() }
        btnFolder.setOnClickListener { askFolder() }
        btnLock.setOnClickListener { toggleFocusLock() }

        // ketuk layar = fokus di titik itu
        val dens = resources.displayMetrics.density
        var downX = 0f
        var downY = 0f
        var downT = 0L
        previewView.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { downX = e.x; downY = e.y; downT = e.eventTime }
                MotionEvent.ACTION_UP -> {
                    if (abs(e.x - downX) < 24 * dens && abs(e.y - downY) < 24 * dens &&
                        e.eventTime - downT < 400
                    ) {
                        focusAt(e.x, e.y, e.rawX, e.rawY)
                        v.performClick()
                    }
                }
            }
            true
        }

        if (hasPerms()) startCamera() else permLauncher.launch(neededPerms())
    }

    private fun neededPerms(): Array<String> =
        if (Build.VERSION.SDK_INT <= 28)
            arrayOf(Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE)
        else arrayOf(Manifest.permission.CAMERA)

    private fun hasPerms() = neededPerms().all {
        ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED
    }

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            val provider = future.get()
            val preview = Preview.Builder()
                .setTargetAspectRatio(AspectRatio.RATIO_4_3).build()
                .also { it.setSurfaceProvider(previewView.surfaceProvider) }
            imageCapture = ImageCapture.Builder()
                .setTargetAspectRatio(AspectRatio.RATIO_4_3)
                .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
                .build()
            provider.unbindAll()
            val cam = try {
                provider.bindToLifecycle(
                    this, CameraSelector.DEFAULT_BACK_CAMERA, preview, imageCapture
                )
            } catch (e: Exception) {
                Toast.makeText(this, "Kamera gagal: ${e.message}", Toast.LENGTH_LONG).show()
                return@addListener
            }
            camera = cam
            cam.cameraInfo.zoomState.observe(this) {
                val m = max(1f, it.maxZoomRatio)
                if (m != hwMax) {
                    hwMax = m
                    applyZoom()
                }
            }
            val hasFlash = cam.cameraInfo.hasFlashUnit()
            btnFlash.isEnabled = hasFlash
            btnFlash.alpha = if (hasFlash) 1f else 0.35f
            val r = cam.cameraInfo.exposureState.exposureCompensationRange
            if (r.upper == r.lower) {
                seekBright.isEnabled = false
                seekBright.alpha = 0.4f
                txtBright.text = "-"
            } else {
                val p = ((0 - r.lower) * 100f / (r.upper - r.lower)).toInt()
                seekBright.progress = p
                txtBright.text = "$p%"
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun applyZoom() {
        val hw = min(zoom, hwMax)
        if (hw != lastHw) {
            lastHw = hw
            camera?.cameraControl?.setZoomRatio(hw)
        }
        extra = zoom / hw
        previewView.scaleX = extra
        previewView.scaleY = extra
        txtZoom.text = String.format(Locale.US, "%.1fx", zoom)
    }

    // ---------- fokus ----------
    private fun focusAt(x: Float, y: Float, rawX: Float, rawY: Float) {
        val cam = camera ?: return
        try {
            val pt = previewView.meteringPointFactory.createPoint(x, y)
            val b = FocusMeteringAction.Builder(
                pt, FocusMeteringAction.FLAG_AF or FocusMeteringAction.FLAG_AE
            )
            if (focusLocked) b.disableAutoCancel() else b.setAutoCancelDuration(4, TimeUnit.SECONDS)
            cam.cameraControl.startFocusAndMetering(b.build())
        } catch (e: Exception) {
            // kamera tidak mendukung area fokus; abaikan
        }
        showRing(rawX, rawY)
    }

    private fun showRing(rawX: Float, rawY: Float) {
        val loc = IntArray(2)
        root.getLocationOnScreen(loc)
        focusRing.animate().cancel()
        focusRing.x = rawX - loc[0] - focusRing.width / 2f
        focusRing.y = rawY - loc[1] - focusRing.height / 2f
        focusRing.isSelected = focusLocked
        focusRing.visibility = View.VISIBLE
        focusRing.alpha = 1f
        focusRing.scaleX = 1.5f
        focusRing.scaleY = 1.5f
        val a = focusRing.animate().scaleX(1f).scaleY(1f).setStartDelay(0).setDuration(220)
        if (!focusLocked) {
            a.withEndAction {
                focusRing.animate().alpha(0f).setStartDelay(900).setDuration(300)
                    .withEndAction { focusRing.visibility = View.INVISIBLE }.start()
            }
        }
        a.start()
    }

    private fun toggleFocusLock() {
        focusLocked = !focusLocked
        btnLock.isSelected = focusLocked
        if (focusLocked) {
            val l = IntArray(2)
            previewBox.getLocationOnScreen(l)
            focusAt(
                previewView.width / 2f, previewView.height / 2f,
                l[0] + previewBox.width / 2f, l[1] + previewBox.height / 2f
            )
            Toast.makeText(this, "Fokus terkunci. Ketuk layar untuk pindah titik", Toast.LENGTH_SHORT).show()
        } else {
            camera?.cameraControl?.cancelFocusAndMetering()
            focusRing.animate().cancel()
            focusRing.visibility = View.INVISIBLE
        }
    }

    // ---------- folder & simpan ----------
    private fun folderName(): String = prefs.getString("folder", "Microscope") ?: "Microscope"

    private fun askFolder() {
        val et = EditText(this).apply { setText(folderName()) }
        AlertDialog.Builder(this)
            .setTitle("Nama folder di galeri (Pictures/...)")
            .setView(et)
            .setPositiveButton("Simpan") { _, _ ->
                val n = et.text.toString().replace(Regex("[\\\\/:*?\"<>|]"), "").trim()
                if (n.isNotEmpty()) prefs.edit().putString("folder", n).apply()
                Toast.makeText(this, "Folder: Pictures/${folderName()}", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun setShotEnabled(on: Boolean) {
        btnShot.isEnabled = on
        btnShot.alpha = if (on) 1f else 0.5f
    }

    private fun takePhoto() {
        val ic = imageCapture ?: return
        val crop = extra
        setShotEnabled(false)
        ic.takePicture(io, object : ImageCapture.OnImageCapturedCallback() {
            override fun onCaptureSuccess(image: ImageProxy) {
                try {
                    val rot = image.imageInfo.rotationDegrees
                    var bmp = image.toBitmap()
                    image.close()
                    if (rot != 0) {
                        val m = Matrix().apply { postRotate(rot.toFloat()) }
                        bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
                    }
                    if (crop > 1.01f) {
                        val cw = (bmp.width / crop).toInt()
                        val ch = (bmp.height / crop).toInt()
                        bmp = Bitmap.createBitmap(
                            bmp, (bmp.width - cw) / 2, (bmp.height - ch) / 2, cw, ch
                        )
                    }
                    save(bmp)
                    runOnUiThread {
                        Toast.makeText(
                            this@MainActivity, "Tersimpan di Pictures/${folderName()}",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                } catch (e: Exception) {
                    runOnUiThread {
                        Toast.makeText(this@MainActivity, "Gagal: ${e.message}", Toast.LENGTH_LONG).show()
                    }
                } finally {
                    runOnUiThread { setShotEnabled(true) }
                }
            }

            override fun onError(e: ImageCaptureException) {
                runOnUiThread {
                    setShotEnabled(true)
                    Toast.makeText(this@MainActivity, "Gagal: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        })
    }

    private fun save(bmp: Bitmap) {
        val name = "MIC_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".jpg"
        val folder = folderName()
        if (Build.VERSION.SDK_INT >= 29) {
            val cv = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, name)
                put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/" + folder)
            }
            val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv)!!
            contentResolver.openOutputStream(uri)!!.use { bmp.compress(Bitmap.CompressFormat.JPEG, 95, it) }
        } else {
            val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), folder)
            dir.mkdirs()
            val f = File(dir, name)
            FileOutputStream(f).use { bmp.compress(Bitmap.CompressFormat.JPEG, 95, it) }
            MediaScannerConnection.scanFile(this, arrayOf(f.path), arrayOf("image/jpeg"), null)
        }
    }
}
