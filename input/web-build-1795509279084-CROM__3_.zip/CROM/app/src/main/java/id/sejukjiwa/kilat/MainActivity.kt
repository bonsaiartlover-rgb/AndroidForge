package id.sejukjiwa.kilat

import android.annotation.SuppressLint
import android.app.DownloadManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Canvas
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.Message
import android.os.SystemClock
import android.text.InputType
import android.util.TypedValue
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.CookieManager
import android.webkit.JsPromptResult
import android.webkit.JsResult
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebStorage
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.URLUtil
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.GridView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.PopupMenu
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.widget.doAfterTextChanged
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private class Tab {
    var web: WebView? = null
    var url = ""
    var title = ""
    var desktop = false
    var pending: String? = null     // URL yang akan dimuat saat WebView dibuat
    var state: Bundle? = null       // status WebView saat tab "ditidurkan"
    var errorFor: String? = null    // URL yang gagal dimuat (halaman error sedang tampil)
    var progress = 100
    var lastUsed = 0L
    var thumb: Bitmap? = null       // cuplikan halaman untuk daftar tab
    var ntVer = -1                  // versi pintasan saat halaman tab baru dimuat
}

private class Row(val title: String, val url: String, val active: Boolean)

private fun sameUrl(a: String, b: String) = a.trimEnd('/') == b.trimEnd('/')

open class MainActivity : AppCompatActivity() {

    protected open val isPrivate = false

    private lateinit var store: Store
    private val tabs = ArrayList<Tab>()
    private var cur = -1

    private lateinit var webHost: FrameLayout
    private lateinit var urlInput: EditText
    private lateinit var icSecurity: ImageView
    private lateinit var btnReload: ImageView
    private lateinit var progress: ProgressBar
    private lateinit var btnBack: ImageView
    private lateinit var btnFwd: ImageView
    private lateinit var btnBookmark: ImageView
    private lateinit var btnSave: ImageView
    private lateinit var tabCount: TextView
    private lateinit var findBar: View
    private lateinit var findInput: EditText
    private lateinit var findCount: TextView
    private lateinit var panel: View
    private lateinit var panelTitle: TextView
    private lateinit var panelAction: TextView
    private lateinit var panelList: ListView
    private lateinit var tabGrid: GridView
    private lateinit var panelEmpty: TextView
    private lateinit var fullscreen: FrameLayout

    private var customView: View? = null
    private var customCb: WebChromeClient.CustomViewCallback? = null
    private var panelMode = P_NONE
    private var shortVer = 0
    private var homeEdit = false
    private var panelRows: List<Row> = emptyList()
    private var fileCb: ValueCallback<Array<Uri>>? = null
    private var pendingDl: Array<String?>? = null
    private lateinit var baseUa: String
    private lateinit var desktopUa: String
    private val ui = Handler(Looper.getMainLooper())

    private val fileLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
            fileCb?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(r.resultCode, r.data))
            fileCb = null
        }

    private val storagePerm =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
            val d = pendingDl
            pendingDl = null
            if (ok && d != null) startDownload(d[0]!!, d[1], d[2], d[3])
            else toast("Izin penyimpanan diperlukan untuk mengunduh")
        }

    // =========================================================== siklus hidup

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = Store(this, !isPrivate)
        setContentView(R.layout.activity_main)

        webHost = findViewById(R.id.webHost)
        urlInput = findViewById(R.id.urlInput)
        icSecurity = findViewById(R.id.icSecurity)
        btnReload = findViewById(R.id.btnReload)
        progress = findViewById(R.id.progress)
        btnBack = findViewById(R.id.btnBack)
        btnFwd = findViewById(R.id.btnFwd)
        btnBookmark = findViewById(R.id.btnBookmark)
        btnSave = findViewById(R.id.btnSave)
        tabCount = findViewById(R.id.tabCount)
        findBar = findViewById(R.id.findBar)
        findInput = findViewById(R.id.findInput)
        findCount = findViewById(R.id.findCount)
        panel = findViewById(R.id.panel)
        panelTitle = findViewById(R.id.panelTitle)
        panelAction = findViewById(R.id.panelAction)
        panelList = findViewById(R.id.panelList)
        tabGrid = findViewById(R.id.tabGrid)
        panelEmpty = findViewById(R.id.panelEmpty)
        fullscreen = findViewById(R.id.fullscreen)

        if (isPrivate) {
            findViewById<View>(R.id.privChip).visibility = View.VISIBLE
            btnBookmark.visibility = View.GONE
            btnSave.visibility = View.GONE
        }

        setupBars()
        setupUserAgents()
        wireUi()
        restoreTabs(intent)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() = onBack()
        })
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.action == Intent.ACTION_VIEW) {
            intent.dataString?.let { newTab(it) }
        }
    }

    override fun onResume() {
        super.onResume()
        curWeb()?.onResume()
    }

    override fun onPause() {
        curWeb()?.onPause()
        CookieManager.getInstance().flush()
        if (!isPrivate) {
            store.save()
            store.saveSession(tabs.map { if (it.errorFor != null) it.errorFor!! else it.url.ifEmpty { NEWTAB } }, cur)
        }
        super.onPause()
    }

    override fun onDestroy() {
        if (isPrivate && isFinishing) {
            try {
                curWeb()?.clearCache(true)
                tabs.forEach { destroyWeb(it) }
                CookieManager.getInstance().removeAllCookies(null)
                CookieManager.getInstance().flush()
                WebStorage.getInstance().deleteAllData()
            } catch (e: Exception) {
                // abaikan
            }
            super.onDestroy()
            android.os.Process.killProcess(android.os.Process.myPid())
            return
        }
        tabs.forEach { destroyWeb(it) }
        super.onDestroy()
    }

    // =========================================================== setup

    private fun attrColor(attr: Int): Int {
        val tv = TypedValue()
        theme.resolveAttribute(attr, tv, true)
        return tv.data
    }

    private fun setupBars() {
        val night = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
            Configuration.UI_MODE_NIGHT_YES
        val dark = isPrivate || night
        val c = WindowCompat.getInsetsController(window, window.decorView)
        c.isAppearanceLightStatusBars = !dark
        c.isAppearanceLightNavigationBars = !dark
        window.statusBarColor = attrColor(R.attr.barBg)
        window.navigationBarColor = attrColor(R.attr.barBg)
    }

    private fun setupUserAgents() {
        val def = WebSettings.getDefaultUserAgent(this)
        baseUa = def.replace("; wv", "").replace(" Version/4.0", "")
        desktopUa = baseUa
            .replace(Regex("\\(Linux; Android[^)]*\\)"), "(X11; Linux x86_64)")
            .replace(" Mobile", "")
    }

    private fun wireUi() {
        urlInput.setOnEditorActionListener { _, id, ev ->
            if (id == EditorInfo.IME_ACTION_GO ||
                (ev != null && ev.keyCode == KeyEvent.KEYCODE_ENTER && ev.action == KeyEvent.ACTION_DOWN)
            ) {
                go(urlInput.text.toString())
                true
            } else false
        }
        urlInput.setOnFocusChangeListener { _, focused ->
            val t = curTab()
            if (focused) {
                urlInput.setText(if (t == null || isNewTab(t.url) || t.url.startsWith("file:")) "" else t.url)
                urlInput.post { urlInput.selectAll() }
            } else {
                urlInput.setText(display(t?.url ?: ""))
            }
        }
        btnReload.setOnClickListener {
            val t = curTab() ?: return@setOnClickListener
            if (t.progress in 1..99) {
                t.web?.stopLoading()
                t.progress = 100
                updateLoading(t)
            } else reloadTab(t)
        }
        btnBack.setOnClickListener { curWeb()?.let { if (it.canGoBack()) it.goBack() } }
        btnFwd.setOnClickListener { curWeb()?.let { if (it.canGoForward()) it.goForward() } }
        btnBookmark.setOnClickListener { toggleBookmark() }
        btnSave.setOnClickListener { savePage() }
        findViewById<View>(R.id.btnNewTab).setOnClickListener { openNewTabAndFocus() }
        findViewById<View>(R.id.btnTabs).setOnClickListener { showPanel(P_TABS) }
        findViewById<View>(R.id.btnMenu).setOnClickListener { showMenu(it) }

        panelList.adapter = rowAdapter
        panelList.setOnItemClickListener { _, _, i, _ -> onRowClick(i) }
        tabGrid.adapter = tabAdapter
        tabGrid.setOnItemClickListener { _, _, i, _ -> selectTab(i); closePanel() }
        findViewById<View>(R.id.panelClose).setOnClickListener { closePanel() }
        panelAction.setOnClickListener { onPanelAction() }

        findInput.doAfterTextChanged { s ->
            val q = s?.toString().orEmpty()
            if (q.isEmpty()) {
                curWeb()?.clearMatches()
                findCount.text = ""
            } else curWeb()?.findAllAsync(q)
        }
        findInput.setOnEditorActionListener { _, _, _ -> curWeb()?.findNext(true); true }
        findViewById<View>(R.id.findNext).setOnClickListener { curWeb()?.findNext(true) }
        findViewById<View>(R.id.findPrev).setOnClickListener { curWeb()?.findNext(false) }
        findViewById<View>(R.id.findClose).setOnClickListener { closeFind() }
    }

    private fun restoreTabs(i: Intent?) {
        val start = if (i != null && i.action == Intent.ACTION_VIEW) i.dataString else null
        if (!isPrivate) {
            val (urls, idx) = store.loadSession()
            for (u in urls) {
                val t = Tab()
                t.pending = u
                t.url = u
                tabs.add(t)
            }
            if (tabs.isNotEmpty()) selectTab(idx.coerceIn(0, tabs.size - 1))
        }
        if (start != null) newTab(start) else if (tabs.isEmpty()) newTab(null)
    }

    private fun onBack() {
        when {
            customView != null -> hideCustom()
            panel.visibility == View.VISIBLE -> closePanel()
            findBar.visibility == View.VISIBLE -> closeFind()
            urlInput.hasFocus() -> { urlInput.clearFocus(); hideKeyboard() }
            curWeb()?.canGoBack() == true -> curWeb()?.goBack()
            tabs.size > 1 -> closeTab(cur)
            else -> finish()
        }
    }

    // =========================================================== tab

    private fun curTab(): Tab? = tabs.getOrNull(cur)
    private fun curWeb(): WebView? = curTab()?.web

    private fun newTab(url: String?, select: Boolean = true, load: Boolean = true): Tab {
        val t = Tab()
        if (load) {
            t.pending = url ?: NEWTAB
            t.url = url ?: NEWTAB
        }
        tabs.add(t)
        if (select) selectTab(tabs.size - 1)
        return t
    }

    private fun openNewTabAndFocus() {
        closePanel()
        newTab(null)
        urlInput.requestFocus()
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
            .showSoftInput(urlInput, InputMethodManager.SHOW_IMPLICIT)
    }

    private fun selectTab(i: Int) {
        if (i !in tabs.indices) return
        curTab()?.let { capture(it) }
        curTab()?.web?.let {
            it.onPause()
            webHost.removeView(it)
        }
        cur = i
        val t = tabs[i]
        val w = ensureWeb(t)
        t.lastUsed = SystemClock.uptimeMillis()
        if (w.parent == null) {
            webHost.addView(
                w,
                ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            )
        }
        w.onResume()
        if (isNewTab(t.url) && t.errorFor == null && t.ntVer >= 0 && t.ntVer != shortVer) loadNewTab(t, w)
        discardOld()
        closeFind()
        refreshUi()
    }

    private fun closeTab(i: Int) {
        if (i !in tabs.indices) return
        val t = tabs.removeAt(i)
        destroyWeb(t)
        if (tabs.isEmpty()) {
            cur = -1
            if (isPrivate) finish() else newTab(null)
            return
        }
        if (i == cur) {
            cur = -1
            selectTab(minOf(i, tabs.size - 1))
        } else {
            if (i < cur) cur--
            refreshUi()
        }
    }

    /** Menjaga memori: hanya beberapa WebView hidup; sisanya disimpan statusnya. */
    private fun discardOld() {
        val live = tabs.filter { it.web != null && it !== curTab() }
        if (live.size <= MAX_LIVE - 1) return
        live.sortedBy { it.lastUsed }.take(live.size - (MAX_LIVE - 1)).forEach { discard(it) }
    }

    private fun discard(t: Tab) {
        val w = t.web ?: return
        if (t.errorFor != null) {
            t.pending = t.errorFor
        } else if (isNewTab(t.url)) {
            t.pending = NEWTAB
        } else {
            val b = Bundle()
            w.saveState(b)
            t.state = b
        }
        destroyWeb(t)
    }

    private fun destroyWeb(t: Tab) {
        val w = t.web ?: return
        t.web = null
        (w.parent as? ViewGroup)?.removeView(w)
        w.stopLoading()
        w.webChromeClient = null
        w.destroy()
    }

    private fun ensureWeb(t: Tab): WebView {
        t.web?.let { return it }
        val w = makeWeb(t)
        t.web = w
        val st = t.state
        val p = t.pending
        t.state = null
        t.pending = null
        when {
            st != null -> {
                if (w.restoreState(st) == null && t.url.isNotEmpty()) w.loadUrl(t.url)
            }
            p == null -> {}
            isNewTab(p) -> { t.url = NEWTAB; loadNewTab(t, w) }
            else -> { t.url = p; w.loadUrl(p) }
        }
        return w
    }

    // =========================================================== WebView

    @SuppressLint("SetJavaScriptEnabled")
    private fun makeWeb(t: Tab): WebView {
        val w = WebView(this)
        w.setBackgroundColor(attrColor(R.attr.pageBg))
        val s = w.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.mediaPlaybackRequiresUserGesture = true
        s.allowFileAccess = true   // hanya untuk halaman offline; file lain diblokir di handleUrl
        s.allowFileAccessFromFileURLs = false
        s.allowUniversalAccessFromFileURLs = false
        s.allowContentAccess = false
        s.setSupportZoom(true)
        s.builtInZoomControls = true
        s.displayZoomControls = false
        s.setSupportMultipleWindows(true)
        applyDesktop(w, t)
        CookieManager.getInstance().apply {
            setAcceptCookie(true)
            setAcceptThirdPartyCookies(w, !isPrivate)
        }
        w.setDownloadListener { url, ua, cd, mime, _ -> startDownload(url, ua, cd, mime) }
        w.webViewClient = makeClient(t)
        w.webChromeClient = makeChrome(t)
        w.setOnLongClickListener { onLongPress(w) }
        w.setFindListener { active, total, _ ->
            if (t === curTab() && findInput.text.isNotEmpty()) {
                findCount.text = if (total > 0) "${active + 1}/$total" else "0/0"
            }
        }
        return w
    }

    private fun applyDesktop(w: WebView, t: Tab) {
        val s = w.settings
        s.userAgentString = if (t.desktop) desktopUa else baseUa
        s.useWideViewPort = true
        s.loadWithOverviewMode = t.desktop
    }

    private fun makeClient(t: Tab) = object : WebViewClient() {
        override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean =
            handleUrl(view, request.url.toString())

        override fun onPageStarted(view: WebView, url: String, favicon: Bitmap?) {
            if (url != t.errorFor) t.errorFor = null
            t.url = url
            t.progress = 5
            if (t === curTab()) {
                updateAddress(t)
                updateLoading(t)
                updateNav()
            }
        }

        override fun onPageFinished(view: WebView, url: String) {
            t.progress = 100
            t.title = view.title ?: ""
            if (t.errorFor == null) addHistory(t, url)
            ui.postDelayed({ if (t === curTab() && t.web === view && panel.visibility != View.VISIBLE) capture(t) }, 900)
            if (t === curTab()) {
                updateAddress(t)
                updateLoading(t)
                updateNav()
            }
        }

        override fun doUpdateVisitedHistory(view: WebView, url: String, isReload: Boolean) {
            t.url = url
            if (t === curTab()) {
                updateAddress(t)
                updateNav()
            }
        }

        override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
            if (!request.isForMainFrame) return
            val u = request.url.toString()
            t.errorFor = u
            view.loadDataWithBaseURL(
                u, errorHtml(u, error.description.toString(), if (isPrivate) null else store.findSaved(u)),
                "text/html", "utf-8", u
            )
        }
    }

    private fun makeChrome(t: Tab) = object : WebChromeClient() {
        override fun onProgressChanged(view: WebView, newProgress: Int) {
            t.progress = newProgress
            if (t === curTab()) updateLoading(t)
        }

        override fun onReceivedTitle(view: WebView, title: String?) {
            t.title = title ?: ""
            if (!isPrivate) store.setTitle(view.url, title)
        }

        override fun onShowCustomView(view: View, callback: WebChromeClient.CustomViewCallback) {
            if (customView != null) {
                callback.onCustomViewHidden()
                return
            }
            customView = view
            customCb = callback
            fullscreen.addView(view)
            fullscreen.visibility = View.VISIBLE
            setBars(false)
        }

        override fun onHideCustomView() = hideCustom()

        override fun onShowFileChooser(
            webView: WebView, filePathCallback: ValueCallback<Array<Uri>>, params: WebChromeClient.FileChooserParams
        ): Boolean {
            fileCb?.onReceiveValue(null)
            fileCb = filePathCallback
            try {
                fileLauncher.launch(params.createIntent())
            } catch (e: Exception) {
                fileCb = null
                filePathCallback.onReceiveValue(null)
            }
            return true
        }

        override fun onCreateWindow(view: WebView, isDialog: Boolean, isUserGesture: Boolean, resultMsg: Message): Boolean {
            if (!isUserGesture) return false      // blokir popup otomatis
            val nt = newTab(null, select = true, load = false)
            val transport = resultMsg.obj as WebView.WebViewTransport
            transport.webView = nt.web
            resultMsg.sendToTarget()
            return true
        }

        override fun onCloseWindow(window: WebView) {
            val i = tabs.indexOfFirst { it.web === window }
            if (i >= 0) closeTab(i)
        }

        override fun onJsAlert(view: WebView, url: String, message: String, result: JsResult): Boolean {
            AlertDialog.Builder(this@MainActivity)
                .setTitle(Uri.parse(url).host ?: "")
                .setMessage(message)
                .setPositiveButton("OK") { _, _ -> result.confirm() }
                .setOnCancelListener { result.cancel() }
                .show()
            return true
        }

        override fun onJsConfirm(view: WebView, url: String, message: String, result: JsResult): Boolean {
            AlertDialog.Builder(this@MainActivity)
                .setTitle(Uri.parse(url).host ?: "")
                .setMessage(message)
                .setPositiveButton("OK") { _, _ -> result.confirm() }
                .setNegativeButton("Batal") { _, _ -> result.cancel() }
                .setOnCancelListener { result.cancel() }
                .show()
            return true
        }

        override fun onJsPrompt(
            view: WebView, url: String, message: String, defaultValue: String?, result: JsPromptResult
        ): Boolean {
            val et = EditText(this@MainActivity)
            et.setText(defaultValue ?: "")
            AlertDialog.Builder(this@MainActivity)
                .setTitle(Uri.parse(url).host ?: "")
                .setMessage(message)
                .setView(et)
                .setPositiveButton("OK") { _, _ -> result.confirm(et.text.toString()) }
                .setNegativeButton("Batal") { _, _ -> result.cancel() }
                .setOnCancelListener { result.cancel() }
                .show()
            return true
        }
    }

    private fun handleUrl(v: WebView, url: String): Boolean {
        val scheme = Uri.parse(url).scheme?.lowercase(Locale.US)
        if (scheme == null || scheme == "http" || scheme == "https" || scheme == "about" ||
            scheme == "blob" || scheme == "data" || scheme == "javascript"
        ) return false
        if (scheme == "kilat") { handleInternal(url); return true }
        if (scheme == "file") return !isOwnFile(url)
        var fallback: String? = null
        try {
            val i = if (scheme == "intent") Intent.parseUri(url, Intent.URI_INTENT_SCHEME)
            else Intent(Intent.ACTION_VIEW, Uri.parse(url))
            fallback = i.getStringExtra("browser_fallback_url")
            i.addCategory(Intent.CATEGORY_BROWSABLE)
            i.component = null
            i.selector = null
            startActivity(i)
        } catch (e: Exception) {
            if (fallback != null && fallback.startsWith("http")) v.loadUrl(fallback)
            else toast("Tidak ada aplikasi untuk membuka tautan ini")
        }
        return true
    }

    private fun isOwnFile(url: String) = url.startsWith("file://" + store.offlineDir().absolutePath + "/")

    private fun handleInternal(url: String) {
        val u = Uri.parse(url)
        when (u.host) {
            "add" -> if (!isPrivate) shortcutDialog(-1)
            "edit" -> if (!isPrivate) u.getQueryParameter("i")?.toIntOrNull()?.let { shortcutDialog(it) }
            "del" -> if (!isPrivate) u.getQueryParameter("i")?.toIntOrNull()?.let {
                homeEdit = true
                store.removeShortcut(it)
                shortcutsChanged()
            }
            "offline" -> {
                val f = u.getQueryParameter("f") ?: return
                store.saved.firstOrNull { it.file == f }?.let { openSaved(it) }
            }
        }
    }

    private fun reloadTab(t: Tab) {
        val w = t.web ?: return
        val err = t.errorFor
        if (err != null) {
            t.errorFor = null
            w.loadUrl(err)
        } else if (isNewTab(t.url)) loadNewTab(t, w)
        else w.reload()
    }

    private fun loadIn(t: Tab, url: String) {
        t.errorFor = null
        ensureWeb(t).loadUrl(url)
    }

    private fun go(input: String) {
        val u = resolve(input)
        if (u.isEmpty()) return
        curTab()?.let { loadIn(it, u) }
        hideKeyboard()
        urlInput.clearFocus()
    }

    private fun resolve(input: String): String {
        val t = input.trim()
        if (t.isEmpty()) return ""
        val lower = t.lowercase(Locale.US)
        if (lower.startsWith("http://") || lower.startsWith("https://") || lower.startsWith("about:")) return t
        val looksUrl = !t.contains(' ') && !t.startsWith("?") &&
            (t.contains('.') || lower.startsWith("localhost"))
        if (looksUrl) {
            val host = t.substringBefore('/').substringBefore(':')
            val local = host == "localhost" || Regex("\\d{1,3}(\\.\\d{1,3}){3}").matches(host)
            return (if (local) "http://" else "https://") + t
        }
        return Store.ENGINES[store.engine].search + Uri.encode(t)
    }

    // =========================================================== UI state

    private fun isNewTab(u: String) = u.isEmpty() || u.startsWith("about:")

    private fun display(u: String): String =
        if (isNewTab(u)) "" else if (u.startsWith("file:")) "Dibaca offline" else u.removePrefix("https://").removePrefix("http://").removePrefix("www.").trimEnd('/')

    private fun refreshUi() {
        val t = curTab() ?: return
        updateAddress(t)
        updateLoading(t)
        updateNav()
        tabCount.text = tabs.size.toString()
    }

    private fun updateAddress(t: Tab) {
        if (!urlInput.hasFocus()) urlInput.setText(display(t.url))
        icSecurity.setImageResource(
            when {
                isNewTab(t.url) -> R.drawable.ic_search
                t.url.startsWith("file:") -> R.drawable.ic_offline
                t.url.startsWith("https://") -> R.drawable.ic_lock
                else -> R.drawable.ic_info
            }
        )
        updateBookmark()
    }

    private fun updateBookmark() {
        val t = curTab()
        val on = t != null && t.url.startsWith("http") && store.hasBookmark(t.url)
        btnBookmark.setImageResource(if (on) R.drawable.ic_star_on else R.drawable.ic_star)
    }

    private fun toggleBookmark() {
        val t = curTab() ?: return
        if (!t.url.startsWith("http")) {
            toast("Buka sebuah halaman dulu")
            return
        }
        val added = store.toggleBookmark(t.title.ifEmpty { t.url }, t.url)
        toast(if (added) "Bookmark ditambahkan" else "Bookmark dihapus")
        updateBookmark()
    }

    /** Menyimpan halaman sebagai arsip MHTML agar bisa dibaca tanpa internet. */
    private fun savePage() {
        val t = curTab() ?: return
        val w = t.web ?: return
        when {
            isNewTab(t.url) || t.errorFor != null || !t.url.startsWith("http") -> {
                toast("Buka sebuah halaman dulu")
                return
            }
            t.progress in 1..99 -> {
                toast("Tunggu halaman selesai dimuat")
                return
            }
        }
        val dir = store.offlineDir()
        dir.mkdirs()
        val f = File(dir, "p" + System.currentTimeMillis() + ".mht")
        val title = t.title.ifEmpty { display(t.url) }
        val url = t.url
        toast("Menyimpan halaman…")
        w.saveWebArchive(f.absolutePath, false) { path ->
            runOnUiThread {
                if (path != null && f.exists() && f.length() > 0) {
                    store.addSaved(Saved(title, url, f.name, System.currentTimeMillis()))
                    if (panelMode == P_SAVED) refreshPanel()
                    toast("Halaman tersimpan, bisa dibaca offline")
                } else {
                    f.delete()
                    toast("Gagal menyimpan halaman")
                }
            }
        }
    }

    private fun openSaved(sv: Saved) {
        val f = store.fileOf(sv)
        if (!f.exists()) {
            toast("File tersimpan tidak ditemukan")
            return
        }
        curTab()?.let { loadIn(it, Uri.fromFile(f).toString()) }
    }

    private fun updateLoading(t: Tab) {
        val loading = t.progress in 1..99
        btnReload.setImageResource(if (loading) R.drawable.ic_close else R.drawable.ic_refresh)
        btnReload.contentDescription = if (loading) "Berhenti" else "Muat ulang"
        progress.visibility = if (loading) View.VISIBLE else View.GONE
        progress.progress = t.progress
    }

    private fun updateNav() {
        val w = curWeb()
        btnBack.alpha = if (w?.canGoBack() == true) 1f else 0.35f
        btnFwd.alpha = if (w?.canGoForward() == true) 1f else 0.35f
    }

    private fun addHistory(t: Tab, url: String) {
        if (isPrivate || isNewTab(url) || url.startsWith("file:")) return
        store.addHistory(t.title, url)
        ui.removeCallbacks(saveRunnable)
        ui.postDelayed(saveRunnable, 3000)
    }

    private val saveRunnable = Runnable { store.save() }

    private fun setBars(show: Boolean) {
        val c = WindowCompat.getInsetsController(window, window.decorView)
        c.systemBarsBehavior = androidx.core.view.WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        if (show) c.show(WindowInsetsCompat.Type.systemBars()) else c.hide(WindowInsetsCompat.Type.systemBars())
    }

    private fun hideCustom() {
        val v = customView ?: return
        fullscreen.removeView(v)
        fullscreen.visibility = View.GONE
        customView = null
        customCb?.onCustomViewHidden()
        customCb = null
        setBars(true)
    }

    private fun hideKeyboard() {
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(urlInput.windowToken, 0)
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun copy(s: String) {
        (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
            .setPrimaryClip(ClipData.newPlainText("url", s))
        toast("Disalin")
    }

    // =========================================================== menu

    private fun showMenu(anchor: View) {
        val t = curTab() ?: return
        val pm = PopupMenu(this, anchor)
        val m = pm.menu
        m.add(0, 1, 0, if (isPrivate) "Tab pribadi baru" else "Tab baru")
        if (!isPrivate) m.add(0, 2, 0, "Tab pribadi baru (jendela terpisah)")
        if (!isPrivate && t.url.startsWith("http")) {
            m.add(0, 3, 0, if (store.hasBookmark(t.url)) "Hapus bookmark" else "Tambah bookmark")
            m.add(0, 14, 0, "Simpan halaman (baca offline)")
        }
        if (!isPrivate) {
            m.add(0, 4, 0, "Bookmark")
            m.add(0, 15, 0, "Halaman tersimpan")
            m.add(0, 5, 0, "Riwayat")
        }
        m.add(0, 6, 0, "Unduhan")
        m.add(0, 7, 0, "Situs desktop").apply { isCheckable = true; isChecked = t.desktop }
        m.add(0, 8, 0, "Cari di halaman")
        m.add(0, 9, 0, "Bagikan")
        m.add(0, 10, 0, "Salin tautan")
        if (!isPrivate) m.add(0, 11, 0, "Hapus data penjelajahan")
        m.add(0, 12, 0, "Mesin pencari")
        if (isPrivate) m.add(0, 13, 0, "Tutup mode pribadi")
        pm.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                1 -> openNewTabAndFocus()
                2 -> openPrivate()
                3 -> toggleBookmark()
                14 -> savePage()
                15 -> showPanel(P_SAVED)
                4 -> showPanel(P_BOOK)
                5 -> showPanel(P_HIST)
                6 -> try {
                    startActivity(Intent(DownloadManager.ACTION_VIEW_DOWNLOADS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                } catch (e: Exception) {
                    toast("Tidak dapat membuka daftar unduhan")
                }
                7 -> {
                    t.desktop = !t.desktop
                    t.web?.let { applyDesktop(it, t) }
                    reloadTab(t)
                    toast(if (t.desktop) "Situs desktop aktif" else "Situs seluler aktif")
                }
                8 -> showFind()
                9 -> if (t.url.startsWith("http")) startActivity(
                    Intent.createChooser(
                        Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, t.url), null
                    )
                )
                10 -> if (t.url.startsWith("http")) copy(t.url)
                11 -> clearDataDialog()
                12 -> engineDialog()
                13 -> finish()
            }
            true
        }
        pm.show()
    }

    private fun openPrivate() {
        if (Build.VERSION.SDK_INT < 28) {
            toast("Mode pribadi membutuhkan Android 9 atau lebih baru")
            return
        }
        startActivity(Intent(this, PrivateActivity::class.java))
    }

    private fun clearDataDialog() {
        val items = arrayOf("Riwayat penjelajahan", "Cookie dan data situs", "Gambar dan file dalam cache")
        val on = booleanArrayOf(true, true, true)
        AlertDialog.Builder(this)
            .setTitle("Hapus data penjelajahan")
            .setMultiChoiceItems(items, on) { _, i, c -> on[i] = c }
            .setPositiveButton("Hapus") { _, _ ->
                if (on[0]) {
                    store.clearHistory()
                    if (panelMode == P_HIST) refreshPanel()
                }
                if (on[1]) {
                    CookieManager.getInstance().removeAllCookies(null)
                    CookieManager.getInstance().flush()
                    WebStorage.getInstance().deleteAllData()
                }
                if (on[2]) curWeb()?.clearCache(true)
                toast("Data dihapus")
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun engineDialog() {
        val names = Store.ENGINES.map { it.name }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Mesin pencari")
            .setSingleChoiceItems(names, store.engine) { d, which ->
                store.engine = which
                d.dismiss()
            }
            .show()
    }

    // =========================================================== cari di halaman

    private fun showFind() {
        findBar.visibility = View.VISIBLE
        findInput.requestFocus()
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
            .showSoftInput(findInput, InputMethodManager.SHOW_IMPLICIT)
    }

    private fun closeFind() {
        if (findBar.visibility != View.VISIBLE) return
        curWeb()?.clearMatches()
        findInput.setText("")
        findCount.text = ""
        findBar.visibility = View.GONE
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(findInput.windowToken, 0)
    }

    // =========================================================== panel (tab / riwayat / bookmark)

    /** Mengambil cuplikan bagian atas halaman (rasio 4:5) sebagai thumbnail tab. */
    private fun capture(t: Tab) {
        val w = t.web ?: return
        if (w.width <= 0 || w.height <= 0 || w.parent == null) return
        try {
            val tw = 360
            val th = 450
            val sc = tw / w.width.toFloat()
            val bmp = Bitmap.createBitmap(tw, th, Bitmap.Config.RGB_565)
            bmp.eraseColor(attrColor(R.attr.pageBg))
            val c = Canvas(bmp)
            c.scale(sc, sc)
            w.draw(c)
            t.thumb = bmp
        } catch (e: Throwable) {
            // abaikan: thumbnail opsional
        }
    }

    private val tabAdapter = object : BaseAdapter() {
        override fun getCount() = tabs.size
        override fun getItem(p: Int) = tabs[p]
        override fun getItemId(p: Int) = p.toLong()
        override fun getView(p: Int, cv: View?, parent: ViewGroup): View {
            val v = cv ?: layoutInflater.inflate(R.layout.item_tab, parent, false)
            val t = tabs[p]
            val title = t.title.ifEmpty { if (isNewTab(t.url)) "Tab baru" else display(t.url) }
            v.findViewById<TextView>(R.id.tabTitle).text = title
            val img = v.findViewById<ImageView>(R.id.tabThumb)
            img.setImageBitmap(t.thumb)
            v.findViewById<TextView>(R.id.tabLetter).text =
                if (t.thumb == null) title.trim().take(1).uppercase(Locale.getDefault()) else ""
            v.isActivated = p == cur
            v.findViewById<View>(R.id.tabClose).setOnClickListener { onRowRemove(p) }
            return v
        }
    }

    private val rowAdapter = object : BaseAdapter() {
        override fun getCount() = panelRows.size
        override fun getItem(p: Int) = panelRows[p]
        override fun getItemId(p: Int) = p.toLong()
        override fun getView(p: Int, cv: View?, parent: ViewGroup): View {
            val v = cv ?: layoutInflater.inflate(R.layout.item_row, parent, false)
            val r = panelRows[p]
            v.findViewById<TextView>(R.id.rowTitle).text = r.title
            v.findViewById<TextView>(R.id.rowUrl).text = r.url
            v.isActivated = r.active
            v.findViewById<View>(R.id.rowClose).setOnClickListener { onRowRemove(p) }
            return v
        }
    }

    private fun showPanel(mode: Int) {
        closeFind()
        hideKeyboard()
        if (mode == P_TABS) curTab()?.let { capture(it) }
        panelMode = mode
        when (mode) {
            P_TABS -> { panelAction.text = "+ Tab baru"; panelAction.visibility = View.VISIBLE }
            P_HIST -> { panelTitle.text = "Riwayat"; panelAction.text = "Hapus semua"; panelAction.visibility = View.VISIBLE }
            P_SAVED -> { panelTitle.text = "Tersimpan (offline)"; panelAction.visibility = View.GONE }
            else -> { panelTitle.text = "Bookmark"; panelAction.visibility = View.GONE }
        }
        refreshPanel()
        panel.visibility = View.VISIBLE
    }

    private fun closePanel() {
        panel.visibility = View.GONE
        panelMode = P_NONE
    }

    private fun refreshPanel() {
        panelRows = when (panelMode) {
            P_TABS -> {
                panelTitle.text = if (isPrivate) "${tabs.size} tab pribadi" else "${tabs.size} tab"
                tabs.mapIndexed { i, t ->
                    Row(
                        t.title.ifEmpty { if (isNewTab(t.url)) "Tab baru" else display(t.url) },
                        display(t.url), i == cur
                    )
                }
            }
            P_HIST -> store.history.map { Row(it.title.ifEmpty { it.url }, it.url, false) }
            P_SAVED -> {
                val fmt = SimpleDateFormat("d MMM yyyy HH:mm", Locale.getDefault())
                store.saved.map { Row(it.title.ifEmpty { display(it.url) }, display(it.url) + "  •  " + fmt.format(Date(it.time)), false) }
            }
            else -> store.bookmarks.map { Row(it.title.ifEmpty { it.url }, it.url, false) }
        }
        rowAdapter.notifyDataSetChanged()
        tabAdapter.notifyDataSetChanged()
        tabGrid.visibility = if (panelMode == P_TABS) View.VISIBLE else View.GONE
        panelList.visibility = if (panelMode == P_TABS) View.GONE else View.VISIBLE
        panelEmpty.text = when (panelMode) {
            P_HIST -> "Belum ada riwayat"
            P_SAVED -> "Belum ada halaman tersimpan.\nBuka halaman, lalu ketuk ikon simpan di atas."
            else -> "Belum ada bookmark"
        }
        panelEmpty.gravity = android.view.Gravity.CENTER
        panelEmpty.setPadding(48, 0, 48, 0)
        panelEmpty.visibility = if (panelRows.isEmpty() && panelMode != P_TABS) View.VISIBLE else View.GONE
    }

    private fun onRowClick(i: Int) {
        when (panelMode) {
            P_TABS -> { selectTab(i); closePanel() }
            P_SAVED -> store.saved.getOrNull(i)?.let { closePanel(); openSaved(it) }
            P_HIST, P_BOOK -> {
                val url = (if (panelMode == P_HIST) store.history else store.bookmarks).getOrNull(i)?.url ?: return
                closePanel()
                curTab()?.let { loadIn(it, url) }
            }
        }
    }

    private fun onRowRemove(i: Int) {
        when (panelMode) {
            P_TABS -> closeTab(i)
            P_HIST -> store.removeHistory(i)
            P_BOOK -> { store.removeBookmark(i); updateBookmark() }
            P_SAVED -> store.removeSaved(i)
        }
        if (panelMode != P_NONE) refreshPanel()
    }

    private fun onPanelAction() {
        when (panelMode) {
            P_TABS -> openNewTabAndFocus()
            P_HIST -> AlertDialog.Builder(this)
                .setMessage("Hapus seluruh riwayat penjelajahan?")
                .setPositiveButton("Hapus") { _, _ -> store.clearHistory(); refreshPanel() }
                .setNegativeButton("Batal", null)
                .show()
        }
    }

    // =========================================================== tekan lama

    private fun onLongPress(w: WebView): Boolean {
        val r = w.hitTestResult
        // Halaman utama (tab baru): tekan lama pada thumbnail = masuk mode ubah (goyang, silang, ubah URL)
        val ct = curTab()
        if (!isPrivate && ct != null && (isNewTab(ct.url) || ct.url.startsWith("data:"))) {
            if (r.type != WebView.HitTestResult.UNKNOWN_TYPE && r.type != WebView.HitTestResult.EDIT_TEXT_TYPE) {
                w.evaluateJavascript("document.body.classList.add('edit')", null)
            }
            return true
        }
        val extra = r.extra ?: return false
        if (extra.startsWith("kilat:")) return true
        when (r.type) {
            WebView.HitTestResult.SRC_ANCHOR_TYPE -> linkMenu(extra, null)
            WebView.HitTestResult.IMAGE_TYPE -> linkMenu(null, extra)
            WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE -> {
                val h = Handler(Looper.getMainLooper()) { m ->
                    linkMenu(m.data?.getString("url"), m.data?.getString("src") ?: extra)
                    true
                }
                w.requestFocusNodeHref(h.obtainMessage())
            }
            else -> return false
        }
        return true
    }

    private fun shortcutsChanged() {
        shortVer++
        val t = curTab() ?: return
        val w = t.web ?: return
        if (isNewTab(t.url) && t.errorFor == null) loadNewTab(t, w)
    }

    /** Dialog tambah (index < 0) atau ubah pintasan situs di halaman tab baru. */
    private fun shortcutDialog(index: Int) {
        val pad = (20 * resources.displayMetrics.density).toInt()
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(pad, pad / 3, pad, 0)
        val name = EditText(this)
        name.hint = "Nama situs"
        name.setSingleLine()
        name.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_WORDS
        val addr = EditText(this)
        addr.hint = "Alamat, mis. detik.com"
        addr.setSingleLine()
        addr.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
        val old = store.shortcuts.getOrNull(index)
        if (old != null) {
            name.setText(old.title)
            addr.setText(old.url)
        }
        box.addView(name)
        box.addView(addr)
        val d = AlertDialog.Builder(this)
            .setTitle(if (old == null) "Tambah situs" else "Ubah situs")
            .setView(box)
            .setPositiveButton("Simpan", null)
            .setNegativeButton("Batal", null)
            .create()
        d.setOnShowListener {
            d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                var u = addr.text.toString().trim()
                if (u.isEmpty()) {
                    toast("Isi alamat situs")
                    return@setOnClickListener
                }
                if (!u.contains("://")) u = "https://$u"
                val low = u.lowercase(Locale.US)
                val host = Uri.parse(u).host
                if (!(low.startsWith("http://") || low.startsWith("https://")) || host.isNullOrEmpty()) {
                    toast("Alamat tidak valid")
                    return@setOnClickListener
                }
                if (store.shortcuts.withIndex().any { (k, e) -> k != index && sameUrl(e.url, u) }) {
                    toast("Situs sudah ada")
                    return@setOnClickListener
                }
                val title = name.text.toString().trim().ifEmpty { host.removePrefix("www.") }
                if (old == null) store.addShortcut(title, u) else store.updateShortcut(index, title, u)
                d.dismiss()
                shortcutsChanged()
            }
        }
        d.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE)
        d.show()
        name.requestFocus()
    }

    private fun linkMenu(link: String?, img: String?) {
        val items = ArrayList<String>()
        val acts = ArrayList<() -> Unit>()
        if (link != null) {
            items.add("Buka di tab baru"); acts.add { newTab(link) }
            items.add("Salin tautan"); acts.add { copy(link) }
        }
        if (img != null && img.startsWith("http")) {
            items.add("Unduh gambar"); acts.add { startDownload(img, baseUa, null, null) }
        }
        if (items.isEmpty()) return
        AlertDialog.Builder(this)
            .setTitle(link ?: img)
            .setItems(items.toTypedArray()) { _, i -> acts[i]() }
            .show()
    }

    // =========================================================== unduhan

    private fun startDownload(url: String, ua: String?, cd: String?, mime: String?) {
        if (!url.startsWith("http")) {
            toast("Jenis unduhan ini belum didukung")
            return
        }
        if (Build.VERSION.SDK_INT <= 28 &&
            ContextCompat.checkSelfPermission(this, android.Manifest.permission.WRITE_EXTERNAL_STORAGE)
            != PackageManager.PERMISSION_GRANTED
        ) {
            pendingDl = arrayOf(url, ua, cd, mime)
            storagePerm.launch(android.Manifest.permission.WRITE_EXTERNAL_STORAGE)
            return
        }
        try {
            val name = URLUtil.guessFileName(url, cd, mime)
            val req = DownloadManager.Request(Uri.parse(url))
            if (!mime.isNullOrEmpty()) req.setMimeType(mime)
            CookieManager.getInstance().getCookie(url)?.let { req.addRequestHeader("Cookie", it) }
            if (!ua.isNullOrEmpty()) req.addRequestHeader("User-Agent", ua)
            req.setTitle(name)
            req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            req.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name)
            (getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(req)
            toast("Mengunduh $name")
        } catch (e: Exception) {
            toast("Unduhan gagal: ${e.message}")
        }
    }

    // =========================================================== halaman bawaan

    private fun hex(c: Int) = String.format(Locale.US, "#%06X", 0xFFFFFF and c)

    private fun esc(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
        .replace("\"", "&quot;").replace("'", "&#39;")

    private fun css(): String {
        val bg = hex(attrColor(R.attr.pageBg))
        val fg = hex(attrColor(R.attr.barFg))
        val dim = hex(attrColor(R.attr.barDim))
        val fld = hex(attrColor(R.attr.fieldBg))
        val acc = hex(attrColor(R.attr.brand))
        return """
            body{margin:0;padding:0 20px 40px;background:$bg;color:$fg;font-family:sans-serif;text-align:center}
            body{padding-top:22px}
            .grid{display:grid;grid-template-columns:repeat(4,1fr);gap:22px 10px;max-width:520px;margin:0 auto}
            .tile{display:block;text-decoration:none;color:$fg;font-size:12px;overflow:hidden;-webkit-touch-callout:none;-webkit-tap-highlight-color:transparent}
            .w{position:relative;width:58px;height:58px;margin:0 auto 7px}
            .ic{position:relative;width:58px;height:58px;border-radius:18px;color:#fff;font-size:24px;font-weight:700;line-height:58px;overflow:hidden;box-shadow:0 2px 6px rgba(0,0,0,.18)}
            .ic img{position:absolute;left:0;top:0;width:100%;height:100%;box-sizing:border-box;padding:13px;background:#fff}
            .ic.add{background:$fld;color:$acc;font-size:30px;font-weight:400;box-shadow:none}
            .x{display:none;position:absolute;top:-7px;right:-7px;width:24px;height:24px;border-radius:50%;background:#E5384B;color:#fff;font-size:14px;line-height:24px;font-weight:700;box-shadow:0 1px 4px rgba(0,0,0,.4)}
            .edit .x{display:block}
            .edit .addt{display:none}
            .edit .ic{animation:sh .3s infinite alternate}
            @keyframes sh{from{transform:rotate(-2deg)}to{transform:rotate(2deg)}}
            .btn{display:inline-block;padding:12px 22px;border-radius:24px;background:$acc;color:$bg;text-decoration:none;font-weight:700;font-size:15px}
            .tile span{display:block;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
            .note{color:$dim;font-size:14px;max-width:420px;margin:20px auto;line-height:1.5}
            h2{margin-top:18vh;font-size:22px}
            .url{color:$dim;font-size:13px;word-break:break-all}
        """.trimIndent()
    }

    private fun loadNewTab(t: Tab, w: WebView) {
        t.ntVer = shortVer
        w.loadDataWithBaseURL(null, newTabHtml(), "text/html", "utf-8", NEWTAB)
    }

    private fun newTabHtml(): String {
        val edit = homeEdit
        homeEdit = false
        val body = if (isPrivate) {
            "<h2>Mode pribadi</h2><p class=\"note\">Riwayat, cookie, dan data situs dihapus saat jendela pribadi ditutup. " +
                "File yang Anda unduh tetap tersimpan di perangkat.</p>"
        } else {
            val tiles = store.shortcuts.withIndex().joinToString("") { (k, b) ->
                val label = b.title.ifBlank { b.url }
                val host = Uri.parse(b.url).host.orEmpty()
                val hue = (label.hashCode() and 0x7fffffff) % 360
                val icon = if (host.isEmpty()) "" else
                    "<img src=\"https://www.google.com/s2/favicons?domain=${esc(host)}&amp;sz=128\" alt=\"\" onerror=\"this.remove()\">"
                "<a class=\"tile\" href=\"${esc(b.url)}\" data-e=\"kilat://edit?i=$k\" data-d=\"kilat://del?i=$k\">" +
                    "<div class=\"w\"><div class=\"ic\" style=\"background:hsl($hue,55%,46%)\">" +
                    esc(label.trim().take(1).uppercase(Locale.getDefault())) + icon +
                    "</div><b class=\"x\">&#10005;</b></div><span>${esc(label)}</span></a>"
            }
            val plus = "<a class=\"tile addt\" href=\"kilat://add\"><div class=\"w\"><div class=\"ic add\">+</div></div><span>Tambah</span></a>"
            "<div class=\"grid\">$tiles$plus</div>" + SCRIPT
        }
        return "<!doctype html><html><head><meta charset=\"utf-8\">" +
            "<meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">" +
            "<style>${css()}</style></head><body" + (if (edit) " class=\"edit\"" else "") + ">" +
            body + "</body></html>"
    }

    private fun errorHtml(url: String, desc: String, sv: Saved?): String =
        "<!doctype html><html><head><meta charset=\"utf-8\">" +
            "<meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">" +
            "<style>${css()}</style></head><body>" +
            "<h2>Halaman tidak dapat dibuka</h2>" +
            "<p class=\"note\">${esc(desc)}</p>" +
            "<p class=\"url\">${esc(url)}</p>" +
            (if (sv != null) "<p><a class=\"btn\" href=\"kilat://offline?f=${esc(sv.file)}\">Buka salinan offline</a></p>" else "") +
            "<p class=\"note\">Periksa koneksi internet, lalu ketuk tombol muat ulang.</p>" +
            "</body></html>"

    companion object {
        private const val NEWTAB = "about:newtab"
        /** Mode ubah: ketuk tile = ubah URL, ketuk silang = hapus, ketuk area kosong = selesai. */
        private const val SCRIPT = "<script>document.addEventListener('click',function(e){" +
            "if(!document.body.classList.contains('edit'))return;" +
            "var a=e.target.closest('a.tile');e.preventDefault();" +
            "if(!a||a.dataset.e===undefined){document.body.classList.remove('edit');return}" +
            "location.href=e.target.closest('.x')?a.dataset.d:a.dataset.e},true)</script>"
        private const val MAX_LIVE = 3
        private const val P_NONE = 0
        private const val P_TABS = 1
        private const val P_HIST = 2
        private const val P_BOOK = 3
        private const val P_SAVED = 4
    }
}
