package com.example.pemutarmusik

import android.app.Service
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Canvas
import android.graphics.ColorFilter
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.SweepGradient
import android.graphics.drawable.Drawable
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.example.pemutarmusik.audio.AudioEngine
import com.example.pemutarmusik.audio.SpectrumAnalyzer

/**
 * Mini player melayang: tampil di atas semua aplikasi saat MP3 di-minimize.
 * Isi: judul berjalan, waktu, grafik audio spectrum berwarna, tombol sebelumnya / putar / jeda / henti / berikutnya,
 * tombol buka aplikasi dan tutup. Selalu di tengah layar, bisa digeser naik/turun lewat layar LCD-nya. Butuh izin "Tampil di atas aplikasi lain".
 */
class FloatingPlayerService : Service() {

    private lateinit var wm: WindowManager
    private var root: View? = null
    private var controller: MediaController? = null
    private val handler = Handler(Looper.getMainLooper())

    private lateinit var titleView: TextView
    private lateinit var timeView: TextView
    private lateinit var spectrum: SpectrumOverlayView
    private lateinit var playBtn: ImageButton
    private lateinit var modeSwitch: ModeSliderView
    private var spinBorder: SpinBorderDrawable? = null

    private val ticker = object : Runnable {
        override fun run() {
            refresh()
            handler.postDelayed(this, 500)
        }
    }

    private val frameTicker = object : Runnable {
        override fun run() {
            spectrum.step(DeckEngine.audioPlaying())
            spinBorder?.advance(4f)
            handler.postDelayed(this, 40)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }
        Skin.init(this)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        buildView()
        connectController()
        handler.post(ticker)
        handler.post(frameTicker)
    }

    private fun dp(v: Float): Int =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, resources.displayMetrics).toInt()

    private val ringColors = intArrayOf(0xFF22E5FF.toInt(), 0xFF8B5CFF.toInt(), 0xFF22E5FF.toInt())

    /**
     * Tombol bulat: border gradasi (biru -> ungu -> biru). Saat ditekan / aktif isinya hanya diwarnai transparan,
     * jadi ikon / tulisan tetap terlihat (ikon juga jadi putih).
     */
    private fun roundButton(litColor: Int, @Suppress("UNUSED_PARAMETER") size: Int): StateListDrawable {
        val litTop = (litColor and 0x00FFFFFF) or 0x77000000
        val litBottom = (litColor and 0x00FFFFFF) or 0x33000000
        fun lit() = RingDrawable(true, 0f, dp(1.8f).toFloat(), litTop, litBottom, ringColors)
        val normal = RingDrawable(true, 0f, dp(1.8f).toFloat(), 0xFF1F2A66.toInt(), 0xFF0E1438.toInt(), ringColors)
        return StateListDrawable().apply {
            addState(intArrayOf(android.R.attr.state_pressed), lit())
            addState(intArrayOf(android.R.attr.state_selected), lit())   // status aktif (play / pause / stop)
            addState(intArrayOf(), normal)
        }
    }

    /** Warna ikon / tulisan: biru normal, putih saat ditekan / aktif. */
    private fun iconTint(normal: Int) = ColorStateList(
        arrayOf(intArrayOf(android.R.attr.state_pressed), intArrayOf(android.R.attr.state_selected), intArrayOf()),
        intArrayOf(Color.WHITE, Color.WHITE, normal),
    )

    private fun buildView() {
        val lcd = 0xFF060A1E.toInt()
        val ink = 0xFF22E5FF.toInt()
        val accent = Skin.p.c3.toArgbInt()

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(7f), dp(6f), dp(7f), dp(6f))
            background = SpinBorderDrawable(dp(12f).toFloat(), dp(3.5f).toFloat()).also { spinBorder = it }
        }

        // ---- layar LCD: judul + waktu (kiri), spectrum (kanan). Area ini dipakai untuk menggeser. ----
        val lcdBox = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8f), dp(3f), dp(8f), dp(3f))
            background = RingDrawable(false, dp(8f).toFloat(), dp(1.5f).toFloat(), lcd, lcd, ringColors)
        }
        val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        titleView = TextView(this).apply {
            setTextColor(0xFFEAF2FF.toInt())
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f)
            typeface = Typeface.MONOSPACE
            setSingleLine(true)
            ellipsize = TextUtils.TruncateAt.MARQUEE
            marqueeRepeatLimit = -1
            isSelected = true
            text = "MP3"
        }
        timeView = TextView(this).apply {
            setTextColor(0xFFFFFFFF.toInt())
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
            text = "00:00"
        }
        info.addView(titleView, LinearLayout.LayoutParams(dp(150f), LinearLayout.LayoutParams.WRAP_CONTENT))
        info.addView(timeView)
        lcdBox.addView(info)

        spectrum = SpectrumOverlayView(this)
        lcdBox.addView(spectrum, LinearLayout.LayoutParams(dp(150f), dp(30f)).apply { leftMargin = dp(8f) })
        box.addView(lcdBox, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT))

        // ---- tombol ----
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        fun imgBtn(res: Int, desc: String, px: Int, color: Int, onClick: () -> Unit) = ImageButton(this).apply {
            setImageResource(res)
            imageTintList = iconTint(ink)
            contentDescription = desc
            background = roundButton(color, px)
            scaleType = android.widget.ImageView.ScaleType.CENTER_INSIDE
            setPadding(dp(6f), dp(6f), dp(6f), dp(6f))
            setOnClickListener { onClick() }
        }
        fun txtBtn(label: String, desc: String, px: Int, color: Int, size: Float = 13f, onClick: () -> Unit) = TextView(this).apply {
            text = label
            contentDescription = desc
            gravity = Gravity.CENTER
            setTextColor(iconTint(ink))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, size)
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
            background = roundButton(color, px)
            setOnClickListener { onClick() }
        }

        val btn = dp(32f)
        val big = dp(38f)
        fun lp(px: Int, left: Int = 4) = LinearLayout.LayoutParams(px, px).apply { leftMargin = dp(left.toFloat()) }
        val c = Skin.p.c3.toArgbInt()

        // 3 tombol: sebelumnya, PUTAR/JEDA (tengah, lebih besar), berikutnya. Sama untuk MP3 dan RADIO (lewat DeckEngine).
        row.addView(imgBtn(android.R.drawable.ic_media_previous, "Sebelumnya", btn, c) { DeckEngine.previous(); refresh() }, lp(btn, 0))
        playBtn = imgBtn(android.R.drawable.ic_media_play, "Putar", big, c) {
            if (playBtn.isSelected) DeckEngine.pause() else DeckEngine.play()
            refresh()
        }
        row.addView(playBtn, lp(big, 6))
        row.addView(imgBtn(android.R.drawable.ic_media_next, "Berikutnya", btn, c) { DeckEngine.next(); refresh() }, lp(btn, 6))
        row.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        // tombol geser MP3 / RADIO
        modeSwitch = ModeSliderView(this) { m -> DeckEngine.setMode(m); refresh() }
        row.addView(modeSwitch, LinearLayout.LayoutParams(dp(92f), dp(30f)).apply { leftMargin = dp(8f) })
        row.addView(txtBtn("□", "Buka aplikasi", btn, accent) { restoreApp() }, lp(btn, 8))
        row.addView(txtBtn("X", "Tutup", btn, accent) { stopSelf() }, lp(btn))
        box.addView(row, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(4f) })

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL   // selalu di tengah layar
            x = 0
            y = dp(120f)
        }

        // geser naik/turun dengan menyentuh layar LCD
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        lcdBox.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    startY = params.y
                    touchX = e.rawX; touchY = e.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    // hanya naik/turun; posisi horizontal tetap di tengah
                    params.y = (startY + (e.rawY - touchY).toInt()).coerceAtLeast(0)
                    root?.let { wm.updateViewLayout(it, params) }
                    true
                }
                MotionEvent.ACTION_UP -> true
                else -> false
            }
        }

        root = box
        wm.addView(box, params)
    }

    private fun androidx.compose.ui.graphics.Color.toArgbInt(): Int =
        Color.argb((alpha * 255).toInt(), (red * 255).toInt(), (green * 255).toInt(), (blue * 255).toInt())

    /** MediaController hanya menjaga PlaybackService tetap terhubung; semua perintah lewat DeckEngine (langsung, tanpa IPC). */
    private fun connectController() {
        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        val future = MediaController.Builder(this, token).buildAsync()
        future.addListener({
            try {
                controller = future.get()
            } catch (e: Exception) {
                // abaikan
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private var lastPlayIcon = -1

    private fun refresh() {
        val radioMode = DeckEngine.mode.value == AppMode.RADIO
        modeSwitch.sync(DeckEngine.mode.value)
        val p = (if (radioMode) DeckEngine.radio else DeckEngine.mp3) ?: return

        // judul: dari item yang dimuat player; kalau radio belum memuat apa pun, pakai stasiun terpilih
        val md = p.currentMediaItem?.mediaMetadata
        val title = md?.title?.toString()
        if (title != null) {
            titleView.text = "${md?.artist ?: ""} - $title    "
        } else if (radioMode) {
            val st = DeckEngine.currentStation()
            titleView.text = if (st != null) "FM ${st.freq} - ${st.name}    " else "RADIO    "
        }

        val connecting = radioMode &&
            (DeckEngine.radioConnecting.value || (p.playWhenReady && p.playbackState == Player.STATE_BUFFERING))
        val playing = p.isPlaying
        if (radioMode) {
            timeView.text = when {
                playing -> "LIVE"
                connecting -> "WAIT"
                else -> "--:--"
            }
        } else {
            val pos = p.currentPosition.coerceAtLeast(0L) / 1000
            timeView.text = "%02d:%02d".format(pos / 60, pos % 60)
        }
        val on = playing || connecting
        playBtn.isSelected = on
        val icon = if (on) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play
        if (icon != lastPlayIcon) {
            lastPlayIcon = icon
            playBtn.setImageResource(icon)
        }
    }

    private fun restoreApp() {
        val intent = Intent(this, MainActivity::class.java).addFlags(
            Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_SINGLE_TOP
        )
        startActivity(intent)
        stopSelf()
    }

    override fun onDestroy() {
        handler.removeCallbacks(ticker)
        handler.removeCallbacks(frameTicker)
        root?.let { runCatching { wm.removeView(it) } }
        root = null
        controller?.release()
        controller = null
        super.onDestroy()
    }
}

/** Grafik audio spectrum 19 bar bersegmen + penanda puncak, warna mengikuti palet LED yang dipilih. */
class SpectrumOverlayView(context: Context) : View(context) {

    private val analyzer = SpectrumAnalyzer { AudioEngine.processor }
    private val bars = FloatArray(SpectrumAnalyzer.BARS)
    private val peaks = FloatArray(SpectrumAnalyzer.BARS)
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var frame = 0

    fun step(playing: Boolean) {
        val idle = !playing && bars.all { it <= 0f } && peaks.all { it <= 0f }
        if (idle) return
        val fresh = if (playing) analyzer.compute() else FloatArray(bars.size)
        for (i in bars.indices) {
            bars[i] = maxOf(fresh[i], bars[i] - 0.07f)
            peaks[i] = maxOf(bars[i], maxOf(peaks[i] - 0.015f, 0f))
        }
        frame++
        invalidate()
    }

    private fun mix(a: androidx.compose.ui.graphics.Color, b: androidx.compose.ui.graphics.Color, t: Float): Int {
        fun ch(x: Float, y: Float) = ((x + (y - x) * t) * 255).toInt().coerceIn(0, 255)
        return Color.rgb(ch(a.red, b.red), ch(a.green, b.green), ch(a.blue, b.blue))
    }

    override fun onDraw(canvas: Canvas) {
        val n = bars.size
        val gap = 1.5f * resources.displayMetrics.density
        val w = (width - gap * (n - 1)) / n
        val segs = 12
        val segH = height.toFloat() / segs
        val low = Skin.p.specLow
        val high = Skin.p.specHigh
        for (i in 0 until n) {
            val x = i * (w + gap)
            val lit = (bars[i] * segs).toInt()
            for (s in 0 until lit) {
                paint.color = mix(low, high, s / (segs - 1f))
                val y = height - (s + 1) * segH
                canvas.drawRoundRect(x, y + 0.5f, x + w, y + segH - 0.5f, 1.5f, 1.5f, paint)
            }
            if (peaks[i] > 0.02f) {
                val pk = (peaks[i] * segs).toInt().coerceIn(0, segs - 1)
                paint.color = Color.WHITE
                val y = height - (pk + 1) * segH
                canvas.drawRoundRect(x, y + 0.5f, x + w, y + segH - 0.5f, 1.5f, 1.5f, paint)
            }
        }
    }
}


/** Bentuk bulat / kotak membulat dengan isi gradasi vertikal dan border gradasi sapuan (sweep). */
private class RingDrawable(
    private val oval: Boolean,
    private val radius: Float,
    private val stroke: Float,
    private val fillTop: Int,
    private val fillBottom: Int,
    private val ring: IntArray,
) : Drawable() {
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = stroke }
    private val rect = RectF()

    override fun onBoundsChange(b: Rect) {
        fillPaint.shader = LinearGradient(0f, b.top.toFloat(), 0f, b.bottom.toFloat(), fillTop, fillBottom, Shader.TileMode.CLAMP)
        ringPaint.shader = SweepGradient(b.exactCenterX(), b.exactCenterY(), ring, null)
    }

    override fun draw(canvas: Canvas) {
        rect.set(bounds)
        rect.inset(stroke / 2f, stroke / 2f)
        if (oval) {
            canvas.drawOval(rect, fillPaint)
            canvas.drawOval(rect, ringPaint)
        } else {
            canvas.drawRoundRect(rect, radius, radius, fillPaint)
            canvas.drawRoundRect(rect, radius, radius, ringPaint)
        }
    }

    override fun setAlpha(alpha: Int) {}
    override fun setColorFilter(colorFilter: ColorFilter?) {}
    @Deprecated("Deprecated in Java")
    override fun getOpacity(): Int = android.graphics.PixelFormat.TRANSLUCENT
}

/** Bingkai luar mini player: border biru tebal + sorot ungu bergradasi yang terus berputar mengelilingi bingkai. */
private class SpinBorderDrawable(private val radius: Float, private val stroke: Float) : Drawable() {
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val basePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = stroke; color = 0xFF2F8BFF.toInt()
    }
    private val spinPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = stroke }
    private val rect = RectF()
    private val matrix = Matrix()
    private var spinShader: SweepGradient? = null
    private var angle = 0f

    fun advance(deg: Float) {
        angle = (angle + deg) % 360f
        invalidateSelf()
    }

    override fun onBoundsChange(b: Rect) {
        fillPaint.shader = LinearGradient(0f, b.top.toFloat(), 0f, b.bottom.toFloat(), 0xFF1A2358.toInt(), 0xFF0A0F2A.toInt(), Shader.TileMode.CLAMP)
        val clear = 0x008B5CFF
        spinShader = SweepGradient(
            b.exactCenterX(), b.exactCenterY(),
            intArrayOf(clear, 0xFF8B5CFF.toInt(), 0xFFC77DFF.toInt(), clear, clear),
            floatArrayOf(0f, 0.2f, 0.35f, 0.55f, 1f),
        )
        spinPaint.shader = spinShader
    }

    override fun draw(canvas: Canvas) {
        rect.set(bounds)
        rect.inset(stroke / 2f, stroke / 2f)
        canvas.drawRoundRect(rect, radius, radius, fillPaint)
        canvas.drawRoundRect(rect, radius, radius, basePaint)
        spinShader?.let {
            matrix.setRotate(angle, bounds.exactCenterX(), bounds.exactCenterY())
            it.setLocalMatrix(matrix)
            canvas.drawRoundRect(rect, radius, radius, spinPaint)
        }
    }

    override fun setAlpha(alpha: Int) {}
    override fun setColorFilter(colorFilter: ColorFilter?) {}
    @Deprecated("Deprecated in Java")
    override fun getOpacity(): Int = android.graphics.PixelFormat.TRANSLUCENT
}


/** Tombol geser MP3 | RADIO: ketuk salah satu sisi atau seret tombolnya. */
private class ModeSliderView(context: Context, private val onChange: (AppMode) -> Unit) : View(context) {
    private var pos = 0f            // 0 = MP3, 1 = RADIO
    private var dragging = false
    private var moved = false
    private var anim: android.animation.ValueAnimator? = null
    private val dens = resources.displayMetrics.density
    private val track = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 1.8f * dens }
    private val thumb = Paint(Paint.ANTI_ALIAS_FLAG)
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        textSize = 10f * dens
    }
    private val rect = RectF()

    private fun animateTo(target: Float) {
        anim?.cancel()
        anim = android.animation.ValueAnimator.ofFloat(pos, target).apply {
            duration = 180
            addUpdateListener { pos = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    /** Samakan dengan mode aktif (tanpa memicu onChange). */
    fun sync(m: AppMode) {
        if (dragging) return
        val t = if (m == AppMode.RADIO) 1f else 0f
        if (pos != t && anim?.isRunning != true) animateTo(t)
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        track.shader = LinearGradient(0f, 0f, 0f, h.toFloat(), 0xFF1F2A66.toInt(), 0xFF0E1438.toInt(), Shader.TileMode.CLAMP)
        ring.shader = SweepGradient(w / 2f, h / 2f, intArrayOf(0xFF22E5FF.toInt(), 0xFF8B5CFF.toInt(), 0xFF22E5FF.toInt()), null)
        thumb.shader = LinearGradient(0f, 0f, w.toFloat(), 0f, 0xFF22E5FF.toInt(), 0xFF8B5CFF.toInt(), Shader.TileMode.CLAMP)
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val inset = ring.strokeWidth / 2f
        rect.set(inset, inset, w - inset, h - inset)
        canvas.drawRoundRect(rect, h / 2f, h / 2f, track)
        canvas.drawRoundRect(rect, h / 2f, h / 2f, ring)
        // tombol geser
        val pad = 3f * dens
        val tw = (w - 2 * pad) / 2f
        val left = pad + pos * tw
        rect.set(left, pad, left + tw, h - pad)
        thumb.alpha = 235
        canvas.drawRoundRect(rect, (h - 2 * pad) / 2f, (h - 2 * pad) / 2f, thumb)
        // label
        val base = h / 2f - (text.descent() + text.ascent()) / 2f
        text.color = if (pos < 0.5f) 0xFF05060F.toInt() else 0xFF9FB0D8.toInt()
        canvas.drawText("MP3", pad + tw / 2f, base, text)
        text.color = if (pos >= 0.5f) 0xFF05060F.toInt() else 0xFF9FB0D8.toInt()
        canvas.drawText("RADIO", pad + tw * 1.5f, base, text)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val tw = (width - 6f * dens) / 2f
        when (e.action) {
            MotionEvent.ACTION_DOWN -> {
                anim?.cancel()
                dragging = true
                moved = false
                parent?.requestDisallowInterceptTouchEvent(true)
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                moved = true
                pos = ((e.x - 3f * dens - tw / 2f) / tw).coerceIn(0f, 1f)
                invalidate()
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                dragging = false
                val m = if (moved) { if (pos >= 0.5f) AppMode.RADIO else AppMode.MP3 } else { if (e.x > width / 2f) AppMode.RADIO else AppMode.MP3 }
                animateTo(if (m == AppMode.RADIO) 1f else 0f)
                if (e.action == MotionEvent.ACTION_UP && m != DeckEngine.mode.value) onChange(m)
                return true
            }
        }
        return super.onTouchEvent(e)
    }
}
