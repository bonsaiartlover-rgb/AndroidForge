package com.example.pemutarmusik

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import kotlin.math.abs
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.VolumeOff
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.pemutarmusik.audio.AudioEngine
import com.example.pemutarmusik.audio.EqAudioProcessor
import kotlinx.coroutines.delay
import kotlin.math.roundToInt

private val FREQ_LABELS = listOf("31", "62", "125", "250", "500", "1K", "2K", "4K", "8K", "16K")

private fun half(v: Float): Float = (v * 2f).roundToInt() / 2f

/** Baris parameter ringkas satu garis: label | slider | nilai. */
@Composable
private fun ParamRow(
    label: String,
    valueText: String,
    value: Float,
    onChange: (Float) -> Unit,
    color: androidx.compose.ui.graphics.Color,
    centered: Boolean = false,
) {
    Row(Modifier.fillMaxWidth().height(28.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, style = hud(9.sp, TextDim, bold = true, spacing = 1.2.sp), modifier = Modifier.width(74.dp), maxLines = 1)
        NeonSlider(value, onChange, Modifier.weight(1f).fillMaxHeight(), centered = centered, color = color)
        Text(valueText, style = hud(11.sp, TextHi, mono = true, spacing = 0.sp), modifier = Modifier.width(62.dp), textAlign = TextAlign.End, maxLines = 1)
    }
}

/**
 * Fader vertikal untuk satu band EQ: jalur beralur, garis skala tiap 1/6, isian gradasi dari tengah (0 dB)
 * ke posisi tombol, dan tombol fader berkilau.
 */
@Composable
private fun EqFader(
    value: Float,
    onChange: (Float) -> Unit,
    enabled: Boolean,
    modifier: Modifier = Modifier,
) {
    val change by rememberUpdatedState(onChange)
    val pad = 13f
    Canvas(
        modifier
            .pointerInput(enabled) {
                if (enabled) detectTapGestures(onTap = {
                    change(1f - ((it.y - pad) / (size.height - 2 * pad).coerceAtLeast(1f)).coerceIn(0f, 1f))
                })
            }
            .pointerInput(enabled) {
                if (enabled) detectDragGestures(
                    onDragStart = { change(1f - ((it.y - pad) / (size.height - 2 * pad).coerceAtLeast(1f)).coerceIn(0f, 1f)) },
                    onDrag = { c, _ ->
                        c.consume()
                        change(1f - ((c.position.y - pad) / (size.height - 2 * pad).coerceAtLeast(1f)).coerceIn(0f, 1f))
                    },
                )
            }
    ) {
        val fade = if (enabled) 1f else 0.4f
        val cx = size.width / 2f
        val top = pad
        val bottom = size.height - pad
        val v = value.coerceIn(0f, 1f)
        val ty = bottom - (bottom - top) * v
        val my = (top + bottom) / 2f
        val groove = 6.dp.toPx()

        // garis skala (0, ±2, ±4, ±6 -> tiap 1/6 tinggi), tengah lebih tebal
        for (k in 0..6) {
            val y = bottom - (bottom - top) * k / 6f
            val mid = k == 3
            val half = if (mid) 11.dp.toPx() else 7.dp.toPx()
            drawLine(
                (if (mid) Magenta else Color.White).copy(alpha = (if (mid) 0.85f else 0.22f) * fade),
                Offset(cx - half, y), Offset(cx + half, y),
                strokeWidth = (if (mid) 1.6f else 1f).dp.toPx(),
            )
        }
        // alur jalur
        drawRoundRect(
            Color.Black.copy(alpha = 0.55f), topLeft = Offset(cx - groove / 2f, top), size = Size(groove, bottom - top),
            cornerRadius = CornerRadius(groove / 2f),
        )
        drawRoundRect(
            Color.White.copy(alpha = 0.16f * fade), topLeft = Offset(cx - groove / 2f, top), size = Size(groove, bottom - top),
            cornerRadius = CornerRadius(groove / 2f), style = Stroke(1.dp.toPx()),
        )
        // isian gradasi dari tengah ke tombol
        if (abs(ty - my) > 0.5f) {
            val up = ty < my
            val fillTop = minOf(ty, my)
            val h = abs(ty - my)
            val c1 = if (up) Cyan else Magenta
            val c2 = if (up) Violet else Violet
            drawRoundRect(
                c1.copy(alpha = 0.25f * fade), topLeft = Offset(cx - groove, fillTop), size = Size(groove * 2f, h),
                cornerRadius = CornerRadius(groove),
            )
            drawRoundRect(
                Brush.verticalGradient(
                    if (up) listOf(c1.copy(alpha = fade), c2.copy(alpha = fade)) else listOf(c2.copy(alpha = fade), c1.copy(alpha = fade)),
                    startY = fillTop, endY = fillTop + h,
                ),
                topLeft = Offset(cx - groove / 2f, fillTop), size = Size(groove, h), cornerRadius = CornerRadius(groove / 2f),
            )
        }
        // tombol fader
        val tw = 28.dp.toPx()
        val th = 15.dp.toPx()
        val accent = if (v >= 0.5f) Cyan else Magenta
        drawCircle(
            Brush.radialGradient(listOf(accent.copy(alpha = 0.45f * fade), Color.Transparent), center = Offset(cx, ty), radius = 22.dp.toPx()),
            radius = 22.dp.toPx(), center = Offset(cx, ty),
        )
        drawRoundRect(Color.Black.copy(alpha = 0.5f), topLeft = Offset(cx - tw / 2f, ty - th / 2f + 2.dp.toPx()), size = Size(tw, th), cornerRadius = CornerRadius(5.dp.toPx()))
        drawRoundRect(
            Brush.verticalGradient(
                listOf(Color(0xFFF4FAFF).copy(alpha = fade), Color(0xFF9FB4DC).copy(alpha = fade), Color(0xFF4A5A8E).copy(alpha = fade)),
                startY = ty - th / 2f, endY = ty + th / 2f,
            ),
            topLeft = Offset(cx - tw / 2f, ty - th / 2f), size = Size(tw, th), cornerRadius = CornerRadius(5.dp.toPx()),
        )
        drawRoundRect(
            accent.copy(alpha = 0.9f * fade), topLeft = Offset(cx - tw / 2f, ty - th / 2f), size = Size(tw, th),
            cornerRadius = CornerRadius(5.dp.toPx()), style = Stroke(1.2.dp.toPx()),
        )
        // alur garis di tengah tombol
        drawLine(accent.copy(alpha = fade), Offset(cx - tw / 2f + 5.dp.toPx(), ty), Offset(cx + tw / 2f - 5.dp.toPx(), ty), strokeWidth = 2.dp.toPx(), cap = StrokeCap.Round)
    }
}

/** Baris indikator pengaman: label | bar | nilai, ukuran sama dengan baris BASS BOOST / POWER AMP. */
@Composable
private fun GuardRow(label: String, db: Float) {
    val on = db > 0.1f
    val frac = (db / 12f).coerceIn(0f, 1f)
    Row(Modifier.fillMaxWidth().height(28.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, style = hud(9.sp, TextDim, bold = true, spacing = 1.2.sp), modifier = Modifier.width(74.dp), maxLines = 1)
        Canvas(Modifier.weight(1f).fillMaxHeight()) {
            val pad = 14f
            val y = size.height / 2f
            val th = 5.dp.toPx()
            drawLine(Color.White.copy(alpha = 0.10f), Offset(pad, y), Offset(size.width - pad, y), strokeWidth = th, cap = StrokeCap.Round)
            if (frac > 0.005f) {
                drawLine(Amber, Offset(pad, y), Offset(pad + (size.width - 2 * pad) * frac, y), strokeWidth = th, cap = StrokeCap.Round)
            }
        }
        Text(
            if (on) "-%.1f dB".format(db) else "AMAN",
            style = hud(11.sp, if (on) Amber else Lime, bold = true, mono = true, spacing = 0.sp),
            modifier = Modifier.width(62.dp), textAlign = TextAlign.End, maxLines = 1,
        )
    }
}

/** Tab EQ: equalizer 10 band + bass boost, power amp, pre amp, dan indikator pengaman. Satu layar, tanpa scroll. */
@Composable
fun StudioScreen(modifier: Modifier = Modifier) {
    val s by AudioEngine.settings.collectAsState()
    val maxG = EqAudioProcessor.MAX_GAIN_DB

    BoxWithConstraints(modifier.fillMaxSize()) {
        // tinggi fader = 70% dari sisa tinggi layar setelah panel lain
        val faderH = ((maxHeight - 300.dp) * 0.7f).coerceAtLeast(90.dp)

        Column(
            Modifier.fillMaxSize().padding(horizontal = 14.dp),
            verticalArrangement = Arrangement.SpaceEvenly,
        ) {
            // ---- equalizer
            Column(Modifier.fillMaxWidth().glass(22.dp).padding(horizontal = 8.dp, vertical = 8.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("EQ 10 BAND", style = hud(10.sp, Cyan, bold = true, spacing = 1.6.sp), modifier = Modifier.padding(start = 4.dp))
                    Spacer(Modifier.weight(1f))
                    NeonChip(if (s.enabled) "EQ ON" else "EQ OFF", s.enabled, { AudioEngine.update { it.copy(enabled = !it.enabled) } })
                    NeonChip("NOISE", s.noiseFilter, { AudioEngine.update { it.copy(noiseFilter = !it.noiseFilter) } }, color = Violet)
                    NeonChip(
                        "RESET", false,
                        { AudioEngine.update { it.copy(gains = List(EqAudioProcessor.BAND_COUNT) { 0f }) } },
                        color = Magenta,
                    )
                }
                Spacer(Modifier.height(4.dp))
                Row(Modifier.fillMaxWidth().height(faderH)) {
                    for (i in 0 until EqAudioProcessor.BAND_COUNT) {
                        val g = s.gains[i]
                        Column(Modifier.weight(1f).fillMaxHeight(), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                if (g > 0f) "+${g.roundToInt()}" else "${g.roundToInt()}",
                                style = hud(9.sp, if (s.enabled) Cyan else TextFaint, mono = true, spacing = 0.sp),
                                maxLines = 1,
                            )
                            EqFader(
                                value = (g + maxG) / (2f * maxG),
                                onChange = { v ->
                                    val gain = half(v * 2f * maxG - maxG)
                                    AudioEngine.update { st ->
                                        st.copy(gains = st.gains.toMutableList().also { it[i] = gain })
                                    }
                                },
                                enabled = s.enabled,
                                modifier = Modifier.weight(1f).fillMaxWidth(),
                            )
                            Text(FREQ_LABELS[i], style = hud(9.sp, TextDim, mono = true, spacing = 0.sp), maxLines = 1)
                        }
                    }
                }
            }

            // ---- DSP ringkas
            Column(Modifier.fillMaxWidth().glass(18.dp).padding(horizontal = 12.dp, vertical = 6.dp)) {
                ParamRow(
                    "BASS BOOST", "${(s.bassBoost * 100).roundToInt()}%", s.bassBoost,
                    { v -> AudioEngine.update { it.copy(bassBoost = v) } }, Violet,
                )
                ParamRow(
                    "POWER AMP", "+%.1f dB".format(s.ampDb), s.ampDb / 12f,
                    { v -> AudioEngine.update { it.copy(ampDb = half(v * 12f)) } }, Magenta,
                )
                ParamRow(
                    "PRE AMP", "%+.1f dB".format(s.preampDb), (s.preampDb + maxG) / (2f * maxG),
                    { v -> AudioEngine.update { it.copy(preampDb = half(v * 2f * maxG - maxG)) } }, Cyan,
                    centered = true,
                )
            }

            // ---- indikator pengaman audio (hidup), ukuran baris sama dengan panel DSP
            var guard by remember { mutableStateOf(0f) }
            var limiter by remember { mutableStateOf(0f) }
            var trim by remember { mutableStateOf(0f) }
            LaunchedEffect(Unit) {
                while (true) {
                    val p = AudioEngine.processor
                    guard = p.guardReductionDb
                    limiter = p.limiterReductionDb
                    trim = p.headroomTrimDb
                    delay(150)
                }
            }
            Column(Modifier.fillMaxWidth().glass(18.dp).padding(horizontal = 12.dp, vertical = 6.dp)) {
                GuardRow("BASS GUARD", guard)
                GuardRow("LIMITER", limiter)
                GuardRow("HEADROOM", trim)
            }
        }
    }
}

/** Tab VU: dua VU meter jarum, LED meter dua sisi, dan knob volume besar. */
@Composable
fun AmpScreen(vm: PlayerViewModel, modifier: Modifier = Modifier) {
    val ui by vm.ui.collectAsState()
    val levels by rememberStereoLevels(ui.audioPlaying, ui.volume)
    val muted = ui.volume <= 0.001f

    Column(
        modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Spacer(Modifier.height(2.dp))
        GlassPanel(Modifier.fillMaxWidth(), "VU METER") {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                NeonGauge("L", levels.first, Modifier.weight(1f))
                NeonGauge("R", levels.second, Modifier.weight(1f))
            }
            Spacer(Modifier.height(12.dp))
            MirrorLedMeter(levels.first, levels.second, Modifier.fillMaxWidth().height(22.dp))
            Spacer(Modifier.height(6.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("L", style = hud(10.sp, TextDim, bold = true))
                Text("LED METER", style = hud(10.sp, TextFaint, bold = true, spacing = 2.sp))
                Text("R", style = hud(10.sp, TextDim, bold = true))
            }
        }
        Spacer(Modifier.height(14.dp))
        GlassPanel(Modifier.fillMaxWidth(), "VOLUME") {
            Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                ArcKnob(
                    value = ui.volume,
                    onValueChange = vm::setVolume,
                    onTap = vm::toggleMute,
                    modifier = Modifier.size(190.dp),
                    muted = muted,
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            if (muted) Icons.Rounded.VolumeOff else Icons.Rounded.VolumeUp, null,
                            tint = if (muted) Danger else Cyan, modifier = Modifier.size(20.dp),
                        )
                        Text(
                            if (muted) "BISU" else "${(ui.volume * 100).roundToInt()}",
                            style = hud(if (muted) 20.sp else 28.sp, TextHi, bold = true, mono = true, spacing = 0.sp),
                        )
                    }
                }
                Spacer(Modifier.height(6.dp))
                Text(
                    "putar melingkar = volume  ·  ketuk = bisu",
                    style = hud(10.sp, TextFaint, spacing = 1.sp),
                    textAlign = TextAlign.Center,
                )
            }
        }
        Spacer(Modifier.height(10.dp))
    }
}
