package com.example.pemutarmusik

import android.app.Application
import android.content.ComponentName
import android.os.Build
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.C
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class PlayerUi(
    val mediaId: String? = null,
    val title: String? = null,
    val artist: String? = null,
    val isPlaying: Boolean = false,
    val positionMs: Long = 0,
    val durationMs: Long = 0,
    val shuffle: Boolean = false,
    val repeatMode: Int = Player.REPEAT_MODE_ALL,   // OFF / ALL / ONE
    val volume: Float = 1f,
    /** Kecepatan putar MP3 (1.0 = normal). */
    val speed: Float = 1f,
    val playbackState: Int = Player.STATE_IDLE,
    val playWhenReady: Boolean = false,
    /** Ada suara yang benar-benar keluar (dari MP3 ATAU radio). Dipakai VU meter. */
    val audioPlaying: Boolean = false,
) {
    /** Status transport: main (isPlaying) / jeda (posisi > 0) / henti (posisi 0). Dipakai untuk menyalakan ikon tombol. */
    val isPaused: Boolean get() = !isPlaying && positionMs > 0L
    val isStopped: Boolean get() = !isPlaying && positionMs <= 0L
}

class PlayerViewModel(app: Application) : AndroidViewModel(app) {

    init {
        DeckEngine.init(app)
    }

    private val _songs = MutableStateFlow<List<Song>>(emptyList())
    val songs: StateFlow<List<Song>> = _songs.asStateFlow()

    private val _loaded = MutableStateFlow(false)
    val loaded: StateFlow<Boolean> = _loaded.asStateFlow()

    private val _ui = MutableStateFlow(PlayerUi())
    val ui: StateFlow<PlayerUi> = _ui.asStateFlow()

    private val _albums = MutableStateFlow(AlbumStore.load(app))
    val albums: StateFlow<List<Album>> = _albums.asStateFlow()

    // ---- mode radio (status dipegang DeckEngine supaya mini player melayang ikut konsisten) ----
    val mode: StateFlow<AppMode> = DeckEngine.mode

    private val _stations = MutableStateFlow(RadioStore.load(app))
    val stations: StateFlow<List<RadioStation>> = _stations.asStateFlow()

    val stationId: StateFlow<Long?> = DeckEngine.stationId

    val radioError: StateFlow<String?> = DeckEngine.radioError

    /** Radio sedang menyambung di latar sementara MP3 masih berbunyi. */
    val radioConnecting: StateFlow<Boolean> = DeckEngine.radioConnecting

    // scan channel: putar tiap stasiun (urut frekuensi) beberapa detik, berputar terus sampai dihentikan
    private val _scanning = MutableStateFlow(false)
    val scanning: StateFlow<Boolean> = _scanning.asStateFlow()
    private var scanJob: Job? = null

    // timer tidur: sisa menit (0 = mati)
    private val _sleepLeft = MutableStateFlow(0)
    val sleepLeft: StateFlow<Int> = _sleepLeft.asStateFlow()
    private var sleepJob: Job? = null
    private var sleepIndex = 0
    private val sleepPresets = listOf(0, 15, 30, 60, 90)

    private var lastVolume = 1f

    // MediaController hanya dipakai untuk menyalakan / menyambung ke PlaybackService; perintah lewat DeckEngine.
    private var controller: MediaController? = null
    private var pendingDelete: Song? = null

    private var boundMp3: ExoPlayer? = null
    private var boundRadio: ExoPlayer? = null
    private val playerListener = object : Player.Listener {
        override fun onEvents(player: Player, events: Player.Events) = syncFromPlayer()
    }

    init {
        DeckEngine.onUserRadioAction = { stopScan() }
        connectToService()
        viewModelScope.launch { DeckEngine.mode.collect { syncFromPlayer() } }
        viewModelScope.launch { DeckEngine.audible.collect { syncFromPlayer() } }
        viewModelScope.launch {
            while (true) {
                delay(250)
                ensureBound()
                val c = modePlayer() ?: continue
                if (c.isPlaying) _ui.update { it.copy(positionMs = c.currentPosition) }
            }
        }
    }

    private fun connectToService() {
        val context = getApplication<Application>()
        val token = SessionToken(context, ComponentName(context, PlaybackService::class.java))
        val future = MediaController.Builder(context, token).buildAsync()
        future.addListener({
            try {
                controller = future.get()
                ensureBound()
            } catch (e: Exception) {
                // Gagal konek ke service: pemutar tidak tersedia
            }
        }, ContextCompat.getMainExecutor(context))
    }

    /** Pasang pendengar ke kedua player (sekali, atau lagi kalau service dibuat ulang). */
    private fun ensureBound() {
        val m = DeckEngine.mp3
        val r = DeckEngine.radio
        var changed = false
        if (m !== boundMp3) {
            m?.addListener(playerListener)
            boundMp3 = m
            changed = true
        }
        if (r !== boundRadio) {
            r?.addListener(playerListener)
            boundRadio = r
            changed = true
        }
        if (changed) syncFromPlayer()
    }

    /** Player milik tab yang sedang dibuka. */
    private fun modePlayer(): ExoPlayer? =
        if (DeckEngine.mode.value == AppMode.RADIO) DeckEngine.radio else DeckEngine.mp3

    private fun syncFromPlayer() {
        val c = modePlayer() ?: return
        val item = c.currentMediaItem
        _ui.value = PlayerUi(
            mediaId = item?.mediaId,
            title = item?.mediaMetadata?.title?.toString(),
            artist = item?.mediaMetadata?.artist?.toString(),
            isPlaying = c.isPlaying,
            positionMs = c.currentPosition.coerceAtLeast(0L),
            durationMs = c.duration.takeIf { it != C.TIME_UNSET } ?: 0L,
            shuffle = c.shuffleModeEnabled,
            repeatMode = DeckEngine.mp3?.repeatMode ?: Player.REPEAT_MODE_ALL,
            volume = c.volume,
            speed = DeckEngine.mp3?.playbackParameters?.speed ?: 1f,
            playbackState = c.playbackState,
            playWhenReady = c.playWhenReady,
            audioPlaying = DeckEngine.audioPlaying(),
        )
    }

    // ------------------------------------------------------------------ lagu

    fun loadSongs() {
        viewModelScope.launch {
            val list = try {
                withContext(Dispatchers.IO) { MusicRepository.loadMp3(getApplication()) }
            } catch (e: SecurityException) {
                emptyList()
            }
            _songs.value = list
            _loaded.value = true
        }
    }

    /** Putar [song] dengan antrean = [list] (urutan album atau semua lagu). */
    fun playList(list: List<Song>, song: Song) {
        val index = list.indexOfFirst { it.id == song.id }
        if (index < 0) return
        DeckEngine.mp3PlayList(list.map { it.toMediaItem() }, index)
    }

    fun play() {
        val m = DeckEngine.mp3 ?: return
        if (m.currentMediaItem == null) {
            val all = _songs.value
            all.firstOrNull()?.let { playList(all, it) }
        } else {
            DeckEngine.mp3Play()
        }
    }

    fun pause() = DeckEngine.mp3Pause()

    fun stop() = DeckEngine.mp3Stop()

    /** Tombol tutup aplikasi: hentikan MP3 dan radio. */
    fun stopAll() = DeckEngine.stopAll()

    fun next() = DeckEngine.mp3Next()

    fun previous() = DeckEngine.mp3Previous()

    fun seekTo(positionMs: Long) {
        DeckEngine.mp3?.seekTo(positionMs)
    }

    fun toggleShuffle() {
        val c = DeckEngine.mp3 ?: return
        c.shuffleModeEnabled = !c.shuffleModeEnabled
    }

    /** Siklus: OFF -> ULANG SEMUA -> ULANG 1 LAGU -> OFF. */
    fun toggleRepeat() {
        val c = DeckEngine.mp3 ?: return
        c.repeatMode = when (c.repeatMode) {
            Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
            Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
            else -> Player.REPEAT_MODE_OFF
        }
    }

    /** Atur kecepatan MP3 lalu segarkan tampilan. */
    fun setSpeed(speed: Float) {
        DeckEngine.setMp3Speed(speed)
        _ui.update { it.copy(speed = speed) }
    }

    fun setVolume(v: Float) {
        val x = v.coerceIn(0f, 1f)
        DeckEngine.setVolume(x)
        _ui.update { it.copy(volume = x) }
    }

    // ------------------------------------------------------------------ radio

    /**
     * Pindah tab MP3 <-> radio: hanya tampilan. Pemutaran yang sedang jalan TIDAK disentuh;
     * suara baru pindah saat pengguna menekan live / play di tab tujuan (lihat DeckEngine).
     */
    fun setMode(m: AppMode) {
        if (m == mode.value) return
        stopScan()
        setSleep(0)
        DeckEngine.setMode(m)
    }

    /** Putar stream [st] dari awal (menyambung ulang ke siaran langsung). Menghentikan scan kalau sedang jalan. */
    fun playStation(st: RadioStation) {
        stopScan()
        DeckEngine.startStation(st)
    }

    fun radioPlay() = DeckEngine.radioPlay()

    fun radioPause() = DeckEngine.radioPause()

    fun radioStop() = DeckEngine.radioStop()

    /** Pindah ke stasiun berikutnya (+1) / sebelumnya (-1) dan langsung diputar. */
    fun stepStation(delta: Int) = DeckEngine.stepStation(delta)

    fun stopScan() {
        scanJob?.cancel()
        scanJob = null
        _scanning.value = false
    }

    /** SCAN: loncat ke stasiun berikutnya (urut frekuensi) tiap ~5 detik; ketuk lagi untuk berhenti di stasiun itu. */
    fun toggleScan() {
        if (_scanning.value) {
            stopScan()
            return
        }
        if (_stations.value.isEmpty() || DeckEngine.radio == null) return
        _scanning.value = true
        scanJob = viewModelScope.launch {
            var i = _stations.value.indexOfFirst { it.id == stationId.value }
            while (true) {
                val list = _stations.value
                if (list.isEmpty()) break
                i = (i + 1).mod(list.size)
                DeckEngine.startStation(list[i])
                var waited = 0
                while (waited < 5000 && radioError.value == null) {
                    delay(250)
                    waited += 250
                }
                if (radioError.value != null) delay(800)   // stasiun gagal: tampilkan sebentar lalu lanjut
            }
            _scanning.value = false
        }
    }

    /** Timer tidur: siklus MATI -> 15 -> 30 -> 60 -> 90 menit; setelah habis siaran dihentikan. */
    fun cycleSleep() {
        sleepIndex = (sleepIndex + 1) % sleepPresets.size
        setSleep(sleepPresets[sleepIndex])
    }

    private fun setSleep(minutes: Int) {
        sleepJob?.cancel()
        sleepJob = null
        if (minutes == 0) sleepIndex = 0
        _sleepLeft.value = minutes
        if (minutes == 0) return
        sleepJob = viewModelScope.launch {
            var left = minutes
            while (left > 0) {
                _sleepLeft.value = left
                delay(60_000)
                left--
            }
            _sleepLeft.value = 0
            sleepIndex = 0
            if (mode.value == AppMode.RADIO) radioStop()
        }
    }

    fun toggleMute() {
        val cur = _ui.value.volume
        if (cur > 0.001f) {
            lastVolume = cur
            setVolume(0f)
        } else {
            setVolume(lastVolume.coerceIn(0.05f, 1f))
        }
    }

    private fun mutateStations(block: (List<RadioStation>) -> List<RadioStation>) {
        val next = sortByFreq(block(_stations.value))
        _stations.value = next
        RadioStore.save(getApplication(), next)
    }

    fun addStation(name: String, freq: String, url: String) {
        val id = System.currentTimeMillis()
        mutateStations { it + RadioStation(id, name, freq, url) }
    }

    fun updateStation(id: Long, name: String, freq: String, url: String) {
        val updated = RadioStation(id, name, freq, url)
        mutateStations { list -> list.map { if (it.id == id) updated else it } }
        // Kalau yang diedit sedang disiarkan, sambungkan ulang dengan alamat baru
        if (DeckEngine.isStationLoaded(id)) playStation(updated)
    }

    fun deleteStation(id: Long) {
        if (stationId.value == id) DeckEngine.clearStation()
        mutateStations { list -> list.filter { it.id != id } }
    }

    // ------------------------------------------------------------------ album

    private fun mutateAlbums(block: (List<Album>) -> List<Album>) {
        val next = block(_albums.value)
        _albums.value = next
        AlbumStore.save(getApplication(), next)
    }

    fun createAlbum(name: String, songIds: List<Long>): Long {
        val id = System.currentTimeMillis()
        mutateAlbums { it + Album(id, name.trim().ifBlank { "Album" }, songIds.distinct()) }
        return id
    }

    fun renameAlbum(id: Long, name: String) = mutateAlbums { list ->
        list.map { if (it.id == id) it.copy(name = name.trim().ifBlank { it.name }) else it }
    }

    fun deleteAlbum(id: Long) = mutateAlbums { list -> list.filter { it.id != id } }

    fun addToAlbum(id: Long, songIds: List<Long>) = mutateAlbums { list ->
        list.map { a ->
            if (a.id != id) a else a.copy(songIds = a.songIds + songIds.filter { it !in a.songIds }.distinct())
        }
    }

    fun removeFromAlbum(albumId: Long, songId: Long) = mutateAlbums { list ->
        list.map { a -> if (a.id == albumId) a.copy(songIds = a.songIds - songId) else a }
    }

    /** Geser lagu di dalam album: delta -1 = naik, +1 = turun. */
    fun moveInAlbum(albumId: Long, songId: Long, delta: Int) = mutateAlbums { list ->
        list.map { a ->
            if (a.id != albumId) return@map a
            val i = a.songIds.indexOf(songId)
            val j = i + delta
            if (i < 0 || j !in a.songIds.indices) return@map a
            val m = a.songIds.toMutableList()
            m[i] = m[j].also { m[j] = m[i] }
            a.copy(songIds = m)
        }
    }

    // ------------------------------------------------------------------ hapus lagu

    fun requestDelete(song: Song): DeleteOutcome {
        pendingDelete = song
        val outcome = MusicRepository.deleteSong(getApplication(), song)
        if (outcome is DeleteOutcome.Done) {
            pendingDelete = null
            finishDelete(song)
        }
        return outcome
    }

    fun onDeleteResult(ok: Boolean) {
        val song = pendingDelete
        pendingDelete = null
        if (!ok || song == null) return
        if (Build.VERSION.SDK_INT == 29) MusicRepository.deleteAgain(getApplication(), song)
        finishDelete(song)
    }

    private fun finishDelete(song: Song) {
        mutateAlbums { list -> list.map { it.copy(songIds = it.songIds - song.id) } }
        loadSongs()
    }

    override fun onCleared() {
        DeckEngine.onUserRadioAction = null
        boundMp3?.removeListener(playerListener)
        boundRadio?.removeListener(playerListener)
        boundMp3 = null
        boundRadio = null
        controller?.release()
        controller = null
        super.onCleared()
    }
}
