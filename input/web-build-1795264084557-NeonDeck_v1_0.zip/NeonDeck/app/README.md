NEON DECK - modul app. UI Jetpack Compose: Theme.kt (palet neon, kaca, latar aurora), Components.kt (tombol, slider, knob, VU, spektrum),
NowScreens.kt (MP3 + radio), StudioScreens.kt (EQ + VU), ListScreens.kt (playlist + stasiun), MainActivity.kt (cangkang + navigasi).
