package com.example.pemutarmusik

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.VolumeOff
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.pemutarmusik.audio.AudioEngine
import com.example.pemutarmusik.audio.EqAudioProcessor
import kotlinx.coroutines.delay
import kotlin.math.roundToInt

private val FREQ_LABELS = listOf("31", "62", "125", "250", "500", "1K", "2K", "4K", "8K", "16K")

private fun half(v: Float): Float = (v * 2f).roundToInt() / 2f

@Composable
private fun ParamRow(
    label: String,
    valueText: String,
    value: Float,
    onChange: (Float) -> Unit,
    color: androidx.compose.ui.graphics.Color,
    centered: Boolean = false,
) {
    Column(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(label, style = hud(11.sp, TextDim, bold = true, spacing = 1.8.sp), modifier = Modifier.weight(1f))
            Text(valueText, style = hud(12.sp, TextHi, mono = true, spacing = 0.sp))
        }
        NeonSlider(value, onChange, Modifier.fillMaxWidth().height(30.dp), centered = centered, color = color)
    }
}

/** Tab EQ: equalizer 10 band + bass boost, power amp, pre amp, dan indikator pengaman. */
@Composable
fun StudioScreen(modifier: Modifier = Modifier) {
    val s by AudioEngine.settings.collectAsState()
    val maxG = EqAudioProcessor.MAX_GAIN_DB

    Column(
        modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Spacer(Modifier.height(2.dp))
        GlassPanel(Modifier.fillMaxWidth(), "EQUALIZER 10 BAND") {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                NeonChip(if (s.enabled) "EQ ON" else "EQ OFF", s.enabled, { AudioEngine.update { it.copy(enabled = !it.enabled) } })
                NeonChip("NOISE", s.noiseFilter, { AudioEngine.update { it.copy(noiseFilter = !it.noiseFilter) } }, color = Violet)
                Spacer(Modifier.weight(1f))
                NeonChip(
                    "RESET", false,
                    { AudioEngine.update { it.copy(gains = List(EqAudioProcessor.BAND_COUNT) { 0f }) } },
                    color = Magenta,
                )
            }
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth().height(210.dp)) {
                for (i in 0 until EqAudioProcessor.BAND_COUNT) {
                    val g = s.gains[i]
                    Column(Modifier.weight(1f).fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            if (g > 0f) "+${g.roundToInt()}" else "${g.roundToInt()}",
                            style = hud(9.sp, if (s.enabled) Cyan else TextFaint, mono = true, spacing = 0.sp),
                            maxLines = 1,
                        )
                        NeonSlider(
                            value = (g + maxG) / (2f * maxG),
                            onValueChange = { v ->
                                val gain = half(v * 2f * maxG - maxG)
                                AudioEngine.update { st ->
                                    st.copy(gains = st.gains.toMutableList().also { it[i] = gain })
                                }
                            },
                            modifier = Modifier.weight(1f).fillMaxWidth(),
                            vertical = true,
                            centered = true,
                            enabled = s.enabled,
                        )
                        Text(FREQ_LABELS[i], style = hud(9.sp, TextDim, mono = true, spacing = 0.sp), maxLines = 1)
                    }
                }
            }
        }

        GlassPanel(Modifier.fillMaxWidth(), "DSP / AMPLIFIER") {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                ParamRow(
                    "BASS BOOST", "${(s.bassBoost * 100).roundToInt()}%", s.bassBoost,
                    { v -> AudioEngine.update { it.copy(bassBoost = v) } }, Violet,
                )
                ParamRow(
                    "POWER AMP", "+%.1f dB".format(s.ampDb), s.ampDb / 12f,
                    { v -> AudioEngine.update { it.copy(ampDb = half(v * 12f)) } }, Magenta,
                )
                ParamRow(
                    "PRE AMP", "%+.1f dB".format(s.preampDb), (s.preampDb + maxG) / (2f * maxG),
                    { v -> AudioEngine.update { it.copy(preampDb = half(v * 2f * maxG - maxG)) } }, Cyan,
                    centered = true,
                )
            }
        }

        // indikator pengaman audio (hidup)
        var guard by remember { mutableStateOf(0f) }
        var limiter by remember { mutableStateOf(0f) }
        var trim by remember { mutableStateOf(0f) }
        LaunchedEffect(Unit) {
            while (true) {
                val p = AudioEngine.processor
                guard = p.guardReductionDb
                limiter = p.limiterReductionDb
                trim = p.headroomTrimDb
                delay(150)
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            StatTile("BASS GUARD", guard, Modifier.weight(1f))
            StatTile("LIMITER", limiter, Modifier.weight(1f))
            StatTile("HEADROOM", trim, Modifier.weight(1f))
        }
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun StatTile(label: String, db: Float, modifier: Modifier = Modifier) {
    val on = db > 0.1f
    Column(
        modifier.glass(16.dp).padding(vertical = 10.dp, horizontal = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(label, style = hud(9.sp, TextDim, bold = true, spacing = 1.2.sp), maxLines = 1)
        Spacer(Modifier.height(4.dp))
        Text(
            if (on) "-%.1f dB".format(db) else "AMAN",
            style = hud(13.sp, if (on) Amber else Lime, bold = true, mono = true, spacing = 0.sp),
            maxLines = 1,
        )
    }
}

/** Tab VU: dua VU meter jarum, LED meter dua sisi, dan knob volume besar. */
@Composable
fun AmpScreen(vm: PlayerViewModel, modifier: Modifier = Modifier) {
    val ui by vm.ui.collectAsState()
    val levels by rememberStereoLevels(ui.isPlaying, ui.volume)
    val muted = ui.volume <= 0.001f

    Column(
        modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Spacer(Modifier.height(2.dp))
        GlassPanel(Modifier.fillMaxWidth(), "VU METER") {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                NeonGauge("L", levels.first, Modifier.weight(1f))
                NeonGauge("R", levels.second, Modifier.weight(1f))
            }
            Spacer(Modifier.height(12.dp))
            MirrorLedMeter(levels.first, levels.second, Modifier.fillMaxWidth().height(22.dp))
            Spacer(Modifier.height(6.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("L", style = hud(10.sp, TextDim, bold = true))
                Text("LED METER", style = hud(10.sp, TextFaint, bold = true, spacing = 2.sp))
                Text("R", style = hud(10.sp, TextDim, bold = true))
            }
        }
        Spacer(Modifier.height(14.dp))
        GlassPanel(Modifier.fillMaxWidth(), "VOLUME") {
            Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                ArcKnob(
                    value = ui.volume,
                    onValueChange = vm::setVolume,
                    onTap = vm::toggleMute,
                    modifier = Modifier.size(190.dp),
                    muted = muted,
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            if (muted) Icons.Rounded.VolumeOff else Icons.Rounded.VolumeUp, null,
                            tint = if (muted) Danger else Cyan, modifier = Modifier.size(20.dp),
                        )
                        Text(
                            if (muted) "BISU" else "${(ui.volume * 100).roundToInt()}",
                            style = hud(if (muted) 20.sp else 28.sp, TextHi, bold = true, mono = true, spacing = 0.sp),
                        )
                    }
                }
                Spacer(Modifier.height(6.dp))
                Text(
                    "putar melingkar = volume  ·  ketuk = bisu",
                    style = hud(10.sp, TextFaint, spacing = 1.sp),
                    textAlign = TextAlign.Center,
                )
            }
        }
        Spacer(Modifier.height(10.dp))
    }
}
