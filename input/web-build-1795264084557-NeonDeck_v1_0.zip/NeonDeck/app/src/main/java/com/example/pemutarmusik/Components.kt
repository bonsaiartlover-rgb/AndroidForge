package com.example.pemutarmusik

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.pemutarmusik.audio.AudioEngine
import com.example.pemutarmusik.audio.SpectrumAnalyzer
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

fun formatTime(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    return "%02d:%02d".format(s / 60, s % 60)
}

// ================================================================== TOMBOL

/** Tombol bulat kaca. [filled] = tombol utama (gradasi cyan-violet), [active] = menyala dengan cahaya neon. */
@Composable
fun NeonIconButton(
    icon: ImageVector,
    desc: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    size: Dp = 48.dp,
    active: Boolean = false,
    color: Color = Cyan,
    filled: Boolean = false,
    enabled: Boolean = true,
) {
    val lit = active || filled
    val bg = when {
        filled -> Brush.linearGradient(listOf(Cyan, Violet))
        active -> Brush.verticalGradient(listOf(color.copy(alpha = 0.32f), color.copy(alpha = 0.12f)))
        else -> Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.10f), Color.White.copy(alpha = 0.03f)))
    }
    val edge = if (lit) color.copy(alpha = 0.9f) else Color.White.copy(alpha = 0.18f)
    val tint = when {
        filled -> Bg0
        active -> color
        enabled -> TextHi.copy(alpha = 0.92f)
        else -> TextHi.copy(alpha = 0.30f)
    }
    Box(
        modifier
            .size(size)
            .then(if (lit) Modifier.neonGlow(if (filled) Violet else color, size / 2) else Modifier)
            .clip(CircleShape)
            .background(bg)
            .border(1.dp, edge, CircleShape)
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(icon, desc, tint = tint, modifier = Modifier.size(size * 0.46f))
    }
}

/** Tombol kapsul kecil dengan titik LED (EQ ON, NOISE, SCAN, SLEEP, dll). */
@Composable
fun NeonChip(
    text: String,
    active: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    color: Color = Cyan,
    leading: ImageVector? = null,
) {
    val shape = RoundedCornerShape(50)
    Row(
        modifier
            .height(34.dp)
            .clip(shape)
            .background(if (active) color.copy(alpha = 0.16f) else Color.White.copy(alpha = 0.05f))
            .border(1.dp, if (active) color.copy(alpha = 0.85f) else Color.White.copy(alpha = 0.16f), shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center,
    ) {
        if (leading != null) {
            Icon(leading, null, tint = if (active) color else TextDim, modifier = Modifier.size(15.dp))
            Spacer(Modifier.width(6.dp))
        } else {
            Box(
                Modifier
                    .size(7.dp)
                    .then(if (active) Modifier.neonGlow(color, 4.dp, 0.7f) else Modifier)
                    .clip(CircleShape)
                    .background(if (active) color else TextFaint)
            )
            Spacer(Modifier.width(7.dp))
        }
        Text(text, style = hud(11.sp, if (active) TextHi else TextDim, bold = true, spacing = 1.4.sp), maxLines = 1)
    }
}

// ================================================================== SLIDER NEON

/**
 * Slider neon (0..1). Horizontal atau vertikal. [centered] = isian mulai dari tengah (untuk gain +/-).
 */
@Composable
fun NeonSlider(
    value: Float,
    onValueChange: (Float) -> Unit,
    modifier: Modifier = Modifier,
    vertical: Boolean = false,
    centered: Boolean = false,
    enabled: Boolean = true,
    color: Color = Cyan,
    onFinished: () -> Unit = {},
) {
    var box by remember { mutableStateOf(IntSize.Zero) }
    val change by rememberUpdatedState(onValueChange)
    val fin by rememberUpdatedState(onFinished)
    val pad = 14f

    fun fracAt(o: Offset): Float {
        return if (vertical) {
            val span = (box.height - 2 * pad).coerceAtLeast(1f)
            1f - ((o.y - pad) / span).coerceIn(0f, 1f)
        } else {
            val span = (box.width - 2 * pad).coerceAtLeast(1f)
            ((o.x - pad) / span).coerceIn(0f, 1f)
        }
    }

    Canvas(
        modifier
            .onSizeChanged { box = it }
            .pointerInput(enabled, vertical) {
                if (enabled) detectTapGestures(onTap = { change(fracAt(it)); fin() })
            }
            .pointerInput(enabled, vertical) {
                if (enabled) detectDragGestures(
                    onDragStart = { change(fracAt(it)) },
                    onDragEnd = { fin() },
                    onDragCancel = { fin() },
                    onDrag = { c, _ ->
                        c.consume()
                        change(fracAt(c.position))
                    },
                )
            }
    ) {
        val a: Offset
        val b: Offset
        if (vertical) {
            a = Offset(size.width / 2f, size.height - pad)
            b = Offset(size.width / 2f, pad)
        } else {
            a = Offset(pad, size.height / 2f)
            b = Offset(size.width - pad, size.height / 2f)
        }
        val v = value.coerceIn(0f, 1f)
        val thumb = Offset(a.x + (b.x - a.x) * v, a.y + (b.y - a.y) * v)
        val mid = Offset(a.x + (b.x - a.x) * 0.5f, a.y + (b.y - a.y) * 0.5f)
        val from = if (centered) mid else a
        val fade = if (enabled) 1f else 0.35f
        val th = 5.dp.toPx()

        drawLine(Color.White.copy(alpha = 0.10f), a, b, strokeWidth = th, cap = StrokeCap.Round)
        if (centered) {
            drawLine(Color.White.copy(alpha = 0.25f), Offset(mid.x - if (vertical) 6.dp.toPx() else 0f, mid.y - if (vertical) 0f else 6.dp.toPx()),
                Offset(mid.x + if (vertical) 6.dp.toPx() else 0f, mid.y + if (vertical) 0f else 6.dp.toPx()), strokeWidth = 1.dp.toPx())
        }
        val fillBrush = Brush.linearGradient(listOf(color.copy(alpha = fade), Magenta.copy(alpha = fade)), start = from, end = thumb)
        if (from != thumb) {
            drawLine(color.copy(alpha = 0.22f * fade), from, thumb, strokeWidth = th * 2.6f, cap = StrokeCap.Round)
            drawLine(fillBrush, from, thumb, strokeWidth = th, cap = StrokeCap.Round)
        }
        drawCircle(
            Brush.radialGradient(listOf(color.copy(alpha = 0.55f * fade), Color.Transparent), center = thumb, radius = 18.dp.toPx()),
            radius = 18.dp.toPx(), center = thumb,
        )
        drawCircle(Color(0xFFF2FBFF).copy(alpha = fade), radius = 8.dp.toPx(), center = thumb)
        drawCircle(color.copy(alpha = fade), radius = 4.dp.toPx(), center = thumb)
    }
}

/** Bar seek lagu: ikut posisi saat diam, mengikuti jari saat digeser, seek saat dilepas. */
@Composable
fun SeekBar(positionMs: Long, durationMs: Long, onSeek: (Long) -> Unit, modifier: Modifier = Modifier) {
    var drag by remember { mutableStateOf<Float?>(null) }
    val frac = drag ?: if (durationMs > 0) (positionMs.toFloat() / durationMs).coerceIn(0f, 1f) else 0f
    val shown = if (drag != null) (frac * durationMs).toLong() else positionMs
    Column(modifier) {
        NeonSlider(
            value = frac,
            onValueChange = { drag = it },
            modifier = Modifier.fillMaxWidth().height(30.dp),
            enabled = durationMs > 0,
            onFinished = {
                drag?.let { onSeek((it * durationMs).toLong()) }
                drag = null
            },
        )
        Row(Modifier.fillMaxWidth().padding(horizontal = 6.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(formatTime(shown), style = hud(11.sp, Cyan, mono = true))
            Text(formatTime(durationMs), style = hud(11.sp, TextDim, mono = true))
        }
    }
}

// ================================================================== KNOB VOLUME

private fun knobFrac(o: Offset, size: IntSize): Float {
    val dx = o.x - size.width / 2f
    val dy = o.y - size.height / 2f
    var deg = Math.toDegrees(atan2(dy, dx).toDouble()).toFloat()
    if (deg < 0f) deg += 360f
    val rel = (deg - 135f + 360f) % 360f
    return when {
        rel <= 270f -> rel / 270f
        rel < 315f -> 1f
        else -> 0f
    }
}

/** Knob melingkar neon: putar = ubah nilai, ketuk = [onTap] (bisu). */
@Composable
fun ArcKnob(
    value: Float,
    onValueChange: (Float) -> Unit,
    onTap: () -> Unit,
    modifier: Modifier = Modifier,
    muted: Boolean = false,
    centerContent: @Composable BoxScope.() -> Unit = {},
) {
    var box by remember { mutableStateOf(IntSize.Zero) }
    val change by rememberUpdatedState(onValueChange)
    val tap by rememberUpdatedState(onTap)
    Box(
        modifier
            .onSizeChanged { box = it }
            .pointerInput(Unit) { detectTapGestures(onTap = { tap() }) }
            .pointerInput(Unit) {
                detectDragGestures(
                    onDragStart = { change(knobFrac(it, box)) },
                    onDrag = { c, _ ->
                        c.consume()
                        change(knobFrac(c.position, box))
                    },
                )
            },
        contentAlignment = Alignment.Center,
    ) {
        Canvas(Modifier.matchParentSize()) {
            val s = min(size.width, size.height)
            val c = Offset(size.width / 2f, size.height / 2f)
            val stroke = s * 0.065f
            val r = s / 2f - stroke * 1.4f
            val v = if (muted) 0f else value.coerceIn(0f, 1f)
            val tl = Offset(c.x - r, c.y - r)
            val sz = Size(r * 2, r * 2)

            // tick keliling
            val ticks = 31
            for (i in 0 until ticks) {
                val f = i / (ticks - 1f)
                val a = Math.toRadians((135f + 270f * f).toDouble())
                val r1 = r + stroke * 0.9f
                val r2 = r + stroke * 1.35f
                val lit = f <= v && v > 0f
                drawLine(
                    if (lit) lerp(Cyan, Magenta, f) else Color.White.copy(alpha = 0.10f),
                    Offset(c.x + r1 * cos(a).toFloat(), c.y + r1 * sin(a).toFloat()),
                    Offset(c.x + r2 * cos(a).toFloat(), c.y + r2 * sin(a).toFloat()),
                    strokeWidth = 1.6.dp.toPx(),
                    cap = StrokeCap.Round,
                )
            }
            drawArc(Color.White.copy(alpha = 0.08f), 135f, 270f, false, tl, sz, style = Stroke(stroke, cap = StrokeCap.Round))
            if (v > 0.003f) {
                rotate(135f, c) {
                    val brush = Brush.sweepGradient(0f to Cyan, 0.75f to Magenta, 1f to Magenta, center = c)
                    drawArc(brush, 0f, 270f * v, false, tl, sz, alpha = 0.28f, style = Stroke(stroke * 2.4f, cap = StrokeCap.Round))
                    drawArc(brush, 0f, 270f * v, false, tl, sz, style = Stroke(stroke, cap = StrokeCap.Round))
                }
            }
            // badan knob
            val body = r * 0.74f
            drawCircle(
                Brush.radialGradient(
                    listOf(Color(0xFF2A3560), Color(0xFF0C1230)),
                    center = Offset(c.x - body * 0.3f, c.y - body * 0.35f), radius = body * 1.6f,
                ),
                radius = body, center = c,
            )
            drawCircle(Color.White.copy(alpha = 0.18f), radius = body, center = c, style = Stroke(1.dp.toPx()))
            drawCircle(Color.White.copy(alpha = 0.06f), radius = body * 0.78f, center = c, style = Stroke(1.dp.toPx()))
            // penunjuk
            val pa = Math.toRadians((135f + 270f * v).toDouble())
            val p1 = Offset(c.x + body * 0.52f * cos(pa).toFloat(), c.y + body * 0.52f * sin(pa).toFloat())
            val p2 = Offset(c.x + body * 0.92f * cos(pa).toFloat(), c.y + body * 0.92f * sin(pa).toFloat())
            val pc = if (muted) Danger else lerp(Cyan, Magenta, v)
            drawLine(pc.copy(alpha = 0.35f), p1, p2, strokeWidth = 7.dp.toPx(), cap = StrokeCap.Round)
            drawLine(pc, p1, p2, strokeWidth = 3.dp.toPx(), cap = StrokeCap.Round)
        }
        centerContent()
    }
}

// ================================================================== LEVEL / VU

const val VU_DB_MIN = -36f
const val VU_DB_MAX = 3f

fun levelToFrac(lin: Float): Float {
    if (lin <= 0.00002f) return 0f
    return ((20f * log10(lin) - VU_DB_MIN) / (VU_DB_MAX - VU_DB_MIN)).coerceIn(0f, 1f)
}

fun dbToFrac(db: Float): Float = ((db - VU_DB_MIN) / (VU_DB_MAX - VU_DB_MIN)).coerceIn(0f, 1f)

/** Level kiri/kanan (0..1) yang dihaluskan: naik cepat, turun pelan. Dikalikan volume supaya ikut knob. */
@Composable
fun rememberStereoLevels(playing: Boolean, volume: Float): State<Pair<Float, Float>> {
    val playingNow by rememberUpdatedState(playing)
    val volumeNow by rememberUpdatedState(volume)
    val levels = remember { mutableStateOf(0f to 0f) }
    LaunchedEffect(Unit) {
        var last = 0L
        while (true) {
            val now = withFrameNanos { it }
            if (now - last < 33_000_000L) continue
            last = now
            val (oldL, oldR) = levels.value
            if (!playingNow && oldL <= 0.002f && oldR <= 0.002f) {
                if (oldL != 0f || oldR != 0f) levels.value = 0f to 0f
                continue
            }
            val pr = AudioEngine.processor
            val tL = if (playingNow) levelToFrac(pr.levelL * volumeNow) else 0f
            val tR = if (playingNow) levelToFrac(pr.levelR * volumeNow) else 0f
            val nL = oldL + (tL - oldL) * (if (tL > oldL) 0.6f else 0.12f)
            val nR = oldR + (tR - oldR) * (if (tR > oldR) 0.6f else 0.12f)
            levels.value = nL to nR
        }
    }
    return levels
}

/** VU meter busur neon dengan jarum bercahaya. [label] = "L" / "R". */
@Composable
fun NeonGauge(label: String, frac: Float, modifier: Modifier = Modifier) {
    val tm = rememberTextMeasurer(cacheSize = 64)
    val db = VU_DB_MIN + frac * (VU_DB_MAX - VU_DB_MIN)
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Canvas(Modifier.fillMaxWidth().aspectRatio(1.4f)) {
            val w = size.width
            val h = size.height
            val c = Offset(w / 2f, h * 0.90f)
            val r = min(w * 0.46f, h * 0.80f)
            val a0 = 200f
            val sw = 140f
            val stroke = r * 0.07f
            val zero = dbToFrac(0f)

            fun pt(f: Float, rr: Float): Offset {
                val a = Math.toRadians((a0 + sw * f).toDouble())
                return Offset(c.x + rr * cos(a).toFloat(), c.y + rr * sin(a).toFloat())
            }

            val tl = Offset(c.x - r, c.y - r)
            val sz = Size(r * 2, r * 2)
            drawArc(Cyan.copy(alpha = 0.14f), a0, sw * zero, false, tl, sz, style = Stroke(stroke))
            drawArc(Danger.copy(alpha = 0.26f), a0 + sw * zero, sw * (1f - zero), false, tl, sz, style = Stroke(stroke))
            if (frac > 0.004f) {
                val cy = min(frac, zero)
                drawArc(Cyan.copy(alpha = 0.22f), a0, sw * cy, false, tl, sz, style = Stroke(stroke * 2.4f))
                drawArc(Cyan, a0, sw * cy, false, tl, sz, style = Stroke(stroke))
                if (frac > zero) {
                    drawArc(Danger, a0 + sw * zero, sw * (frac - zero), false, tl, sz, style = Stroke(stroke))
                }
            }
            val marks = listOf(-36f, -30f, -24f, -18f, -12f, -6f, 0f, 3f)
            for (m in marks) {
                val f = dbToFrac(m)
                val hot = m >= 0f
                drawLine(
                    if (hot) Danger else TextDim,
                    pt(f, r - stroke * 1.2f), pt(f, r - stroke * 2.6f),
                    strokeWidth = 1.5.dp.toPx(), cap = StrokeCap.Round,
                )
                val txt = if (m > 0f) "+${m.toInt()}" else "${m.toInt()}"
                val lay = tm.measure(txt, hud(8.sp, if (hot) Danger else TextDim, mono = true, spacing = 0.sp))
                val p = pt(f, r - stroke * 4.6f)
                drawText(lay, topLeft = Offset(p.x - lay.size.width / 2f, p.y - lay.size.height / 2f))
            }
            // jarum
            val tip = pt(frac, r * 0.93f)
            drawLine(Cyan.copy(alpha = 0.25f), c, tip, strokeWidth = 7.dp.toPx(), cap = StrokeCap.Round)
            drawLine(Color(0xFFF2FBFF), c, tip, strokeWidth = 2.2.dp.toPx(), cap = StrokeCap.Round)
            drawCircle(Bg0, radius = r * 0.09f, center = c)
            drawCircle(Cyan, radius = r * 0.09f, center = c, style = Stroke(1.5.dp.toPx()))
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(label, style = hud(15.sp, Cyan, bold = true, spacing = 2.sp))
            Spacer(Modifier.width(8.dp))
            val txt = if (frac <= 0.004f) "-∞ dB" else "%+.1f dB".format(db)
            Text(txt, style = hud(11.sp, if (db > 0f) Danger else TextHi, mono = true))
        }
    }
}

/** LED meter dua sisi dari tengah: kiri (L) menyala ke kiri, kanan (R) menyala ke kanan. */
@Composable
fun MirrorLedMeter(l: Float, r: Float, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val n = 22
        val gap = 3.dp.toPx()
        val mid = 6.dp.toPx()
        val segW = ((size.width - mid) / 2f - gap * (n - 1)) / n
        val corner = CornerRadius(2.dp.toPx())
        fun segColor(i: Int): Color {
            val f = i / (n - 1f)
            return when {
                f > 0.88f -> Danger
                f > 0.72f -> Magenta
                else -> lerp(Cyan, Violet, f / 0.72f)
            }
        }
        for (i in 0 until n) {
            val dx = mid / 2f + i * (segW + gap)
            val xl = size.width / 2f - dx - segW
            val xr = size.width / 2f + dx
            val litL = l * n > i
            val litR = r * n > i
            val col = segColor(i)
            drawRoundRect(if (litL) col else Color.White.copy(alpha = 0.07f), Offset(xl, 0f), Size(segW, size.height), corner)
            drawRoundRect(if (litR) col else Color.White.copy(alpha = 0.07f), Offset(xr, 0f), Size(segW, size.height), corner)
        }
    }
}

// ================================================================== SPECTRUM

class SpecState(val bars: FloatArray, val peaks: FloatArray)

@Composable
fun rememberSpectrum(playing: Boolean): State<SpecState> {
    val analyzer = remember { SpectrumAnalyzer(AudioEngine.processor) }
    val n = SpectrumAnalyzer.BARS
    val state = remember { mutableStateOf(SpecState(FloatArray(n), FloatArray(n))) }
    val playingNow by rememberUpdatedState(playing)
    LaunchedEffect(Unit) {
        var last = 0L
        while (true) {
            val now = withFrameNanos { it }
            if (now - last < 33_000_000L) continue
            last = now
            val old = state.value
            val idle = !playingNow && old.bars.all { it <= 0f } && old.peaks.all { it <= 0f }
            if (idle) continue
            val fresh = if (playingNow) analyzer.compute() else FloatArray(n)
            val bars = FloatArray(n) { max(fresh[it], old.bars[it] - 0.06f) }
            val peaks = FloatArray(n) { max(bars[it], max(old.peaks[it] - 0.012f, 0f)) }
            state.value = SpecState(bars, peaks)
        }
    }
    return state
}

/** Spektrum batang kapsul bergradasi cyan -> violet -> magenta dengan titik puncak. */
@Composable
fun SpectrumBars(playing: Boolean, modifier: Modifier = Modifier) {
    val spec by rememberSpectrum(playing)
    Canvas(modifier) {
        val b = spec.bars
        val p = spec.peaks
        val n = b.size
        val gap = 4.dp.toPx()
        val w = (size.width - gap * (n - 1)) / n
        val brush = Brush.verticalGradient(listOf(Magenta, Violet, Cyan), startY = 0f, endY = size.height)
        val minH = 3.dp.toPx()
        for (i in 0 until n) {
            val x = i * (w + gap)
            val hh = max(minH, b[i] * size.height)
            drawRoundRect(brush, Offset(x, size.height - hh), Size(w, hh), CornerRadius(w / 2f), alpha = 0.95f)
            if (p[i] > 0.03f) {
                val py = size.height - max(minH, p[i] * size.height) - 5.dp.toPx()
                drawRoundRect(Color(0xFFF2FBFF), Offset(x, py), Size(w, 2.dp.toPx()), CornerRadius(1.dp.toPx()))
            }
        }
    }
}

/**
 * Visualizer utama: cakram berputar (hanya saat memutar) dikelilingi spektrum melingkar simetris.
 * [center] = isi di tengah cakram.
 */
@Composable
fun HeroVisualizer(playing: Boolean, modifier: Modifier = Modifier, center: @Composable BoxScope.() -> Unit = {}) {
    val spec by rememberSpectrum(playing)
    val playingNow by rememberUpdatedState(playing)
    var angle by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(Unit) {
        var last = 0L
        while (true) {
            val now = withFrameNanos { it }
            if (last != 0L && playingNow) angle = (angle + (now - last) / 1_000_000_000f * 42f) % 360f
            last = now
        }
    }
    Box(modifier.aspectRatio(1f), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxWidth().aspectRatio(1f)) {
            val c = Offset(size.width / 2f, size.height / 2f)
            val R = min(size.width, size.height) / 2f
            val bars = spec.bars
            val n = bars.size
            val total = n * 2
            val r0 = R * 0.66f
            val maxLen = R * 0.30f
            for (i in 0 until total) {
                val idx = if (i < n) i else total - 1 - i
                val a = Math.toRadians((-90.0 + 360.0 * i / total))
                val len = 3.dp.toPx() + bars[idx] * maxLen
                val col = lerp(Cyan, Magenta, idx / (n - 1f))
                val p1 = Offset(c.x + r0 * cos(a).toFloat(), c.y + r0 * sin(a).toFloat())
                val p2 = Offset(c.x + (r0 + len) * cos(a).toFloat(), c.y + (r0 + len) * sin(a).toFloat())
                drawLine(col.copy(alpha = 0.30f), p1, p2, strokeWidth = 8.dp.toPx(), cap = StrokeCap.Round)
                drawLine(col, p1, p2, strokeWidth = 3.5.dp.toPx(), cap = StrokeCap.Round)
            }
            // halo
            drawCircle(
                Brush.radialGradient(listOf(Violet.copy(alpha = 0.30f), Color.Transparent), center = c, radius = R),
                radius = R, center = c,
            )
            drawCircle(Color.White.copy(alpha = 0.10f), radius = r0 - 6.dp.toPx(), center = c, style = Stroke(1.dp.toPx()))
            // cakram berputar
            rotate(angle, c) {
                drawCircle(
                    Brush.sweepGradient(
                        listOf(
                            Violet.copy(alpha = 0.85f), Bg0, Cyan.copy(alpha = 0.85f), Bg0,
                            Magenta.copy(alpha = 0.85f), Bg0, Violet.copy(alpha = 0.85f),
                        ),
                        center = c,
                    ),
                    radius = R * 0.56f, center = c,
                )
                for (k in 1..4) {
                    drawCircle(Color.White.copy(alpha = 0.05f), radius = R * (0.56f - k * 0.07f), center = c, style = Stroke(1.dp.toPx()))
                }
            }
            drawCircle(
                Brush.radialGradient(listOf(Color(0xFF111A44), Bg0), center = c, radius = R * 0.30f),
                radius = R * 0.30f, center = c,
            )
            drawCircle(Cyan.copy(alpha = 0.55f), radius = R * 0.30f, center = c, style = Stroke(1.5.dp.toPx()))
        }
        center()
    }
}

/** Panel kaca berjudul kecil. */
@Composable
fun GlassPanel(modifier: Modifier = Modifier, title: String? = null, content: @Composable () -> Unit) {
    Column(modifier.glass().padding(14.dp)) {
        if (title != null) {
            Text(title, style = hud(11.sp, Cyan, bold = true, spacing = 2.2.sp))
            Spacer(Modifier.height(10.dp))
        }
        content()
    }
}
