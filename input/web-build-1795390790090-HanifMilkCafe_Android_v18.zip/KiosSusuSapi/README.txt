HANIF MILK CAFE - proyek Android (Gradle)

Proyek WebView sederhana. Aplikasinya ada di app/src/main/assets/index.html (satu file).

Build:  gradle assembleDebug   atau   gradle assembleRelease   atau   gradle bundleDebug
Persyaratan: JDK 17, Android SDK platform 34, Gradle 8.7 atau lebih baru.
APK release memakai kunci debug agar bisa langsung dipasang.

Catatan Samsung Galaxy J2 Prime (Android 6.0 Marshmallow):
- minSdk sudah diturunkan ke 23 sehingga APK bisa dipasang di Android 6.0.
- Tampilan memakai WebView sistem. Disarankan perbarui "Android System WebView" lewat Play Store.
- Pasang: aktifkan "Sumber tidak dikenal" di Pengaturan > Keamanan, lalu buka file app-release.apk atau app-debug.apk.
- Hasil build: app/build/outputs/apk/release/app-release.apk (atau .../debug/app-debug.apk)
