package com.example.pemutarmusik.audio

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class EqSettings(
    val enabled: Boolean = true,
    val gains: List<Float> = List(EqAudioProcessor.BAND_COUNT) { 0f },
    val preampDb: Float = 0f,
    val noiseFilter: Boolean = true,
    val bassBoost: Float = 0f,   // 0..1
    val width: Float = 1f,       // 0..2
    val ampDb: Float = 3f,       // 0..12
    val eqL: List<Float> = List(EqAudioProcessor.EQ7_COUNT) { 0f },   // equalizer 7 band kiri (dB)
    val eqR: List<Float> = List(EqAudioProcessor.EQ7_COUNT) { 0f },   // equalizer 7 band kanan (dB)
    val bassDb: Int = 0,         // -10..+10 (tombol + / -)
    val trebleDb: Int = 0,       // -10..+10 (tombol + / -)
)

/**
 * Pemegang tunggal pengaturan audio: dipakai bersama oleh PlaybackService (memutar)
 * dan UI (mengubah). Pengaturan disimpan otomatis.
 * Bass Guard tidak punya pengaturan: selalu aktif dan otomatis.
 */
object AudioEngine {
    val processor = EqAudioProcessor()

    private val _settings = MutableStateFlow(EqSettings())
    val settings: StateFlow<EqSettings> = _settings.asStateFlow()

    private var prefs: SharedPreferences? = null

    @Synchronized
    fun init(context: Context) {
        if (prefs != null) return
        val p = context.applicationContext.getSharedPreferences("dsp2", Context.MODE_PRIVATE)
        prefs = p

        val saved = p.getString("gains", null)
            ?.split(",")
            ?.mapNotNull { it.toFloatOrNull() }
            ?.takeIf { it.size == EqAudioProcessor.BAND_COUNT }
        val loaded = EqSettings(
            enabled = p.getBoolean("enabled", true),
            gains = saved ?: List(EqAudioProcessor.BAND_COUNT) { 0f },
            preampDb = p.getFloat("preamp", 0f),
            noiseFilter = p.getBoolean("noise", true),
            bassBoost = p.getFloat("boost", 0f),
            width = 1f, // stereo width dihapus dari UI: selalu normal (abaikan nilai lama)
            ampDb = p.getFloat("amp", 3f),
            eqL = readList(p.getString("eqL", null)),
            eqR = readList(p.getString("eqR", null)),
            bassDb = p.getInt("bass", 0).coerceIn(-EqAudioProcessor.TONE_MAX_DB, EqAudioProcessor.TONE_MAX_DB),
            trebleDb = p.getInt("treble", 0).coerceIn(-EqAudioProcessor.TONE_MAX_DB, EqAudioProcessor.TONE_MAX_DB),
        )
        _settings.value = loaded
        apply(loaded)
    }

    private fun readList(raw: String?): List<Float> =
        raw?.split(",")?.mapNotNull { it.toFloatOrNull() }
            ?.takeIf { it.size == EqAudioProcessor.EQ7_COUNT }
            ?: List(EqAudioProcessor.EQ7_COUNT) { 0f }

    fun update(block: (EqSettings) -> EqSettings) {
        val next = block(_settings.value)
        _settings.value = next
        apply(next)
        save(next)
    }

    private fun apply(s: EqSettings) {
        processor.setParams(
            DspParams(
                eqEnabled = s.enabled,
                // equalizer 10 band lama diganti equalizer 7 band kiri/kanan: jalur lama dibiarkan datar
                gains = FloatArray(EqAudioProcessor.BAND_COUNT),
                eqL = s.eqL.toFloatArray(),
                eqR = s.eqR.toFloatArray(),
                bassDb = s.bassDb.toFloat(),
                trebleDb = s.trebleDb.toFloat(),
                preampDb = s.preampDb,
                noiseFilter = s.noiseFilter,
                bassBoost = s.bassBoost,
                width = s.width,
                ampDb = s.ampDb,
            )
        )
    }

    private fun save(s: EqSettings) {
        prefs?.edit()
            ?.putBoolean("enabled", s.enabled)
            ?.putString("gains", s.gains.joinToString(","))
            ?.putFloat("preamp", s.preampDb)
            ?.putBoolean("noise", s.noiseFilter)
            ?.putFloat("boost", s.bassBoost)
            ?.putFloat("width", s.width)
            ?.putFloat("amp", s.ampDb)
            ?.putString("eqL", s.eqL.joinToString(","))
            ?.putString("eqR", s.eqR.joinToString(","))
            ?.putInt("bass", s.bassDb)
            ?.putInt("treble", s.trebleDb)
            ?.apply()
    }
}
