package com.example.pemutarmusik

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.drag
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.pemutarmusik.audio.AudioEngine
import com.example.pemutarmusik.audio.SpectrumAnalyzer
import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

// ================================================================== WARNA (bodi hitam ala hi-fi klasik)

internal val RkSilk = Color(0xFFC7CAD0)
internal val RkDim = Color(0xFF7E828A)
internal val RkGreen = Color(0xFF58F06E)
internal val RkAmber = Color(0xFFFFB02E)
internal val RkRed = Color(0xFFFF3B30)

/** Pelat depan hitam: gradasi gelap, tepi abu-abu tua, garis kilap tipis di atas. */
internal fun Modifier.faceplate(): Modifier = this.drawBehind {
    val r = CornerRadius(5.dp.toPx())
    drawRoundRect(
        Brush.verticalGradient(listOf(Color(0xFF28282C), Color(0xFF151518), Color(0xFF0B0B0D))),
        cornerRadius = r,
    )
    drawRoundRect(Color(0xFF3C3C42), cornerRadius = r, style = Stroke(1.dp.toPx()))
    drawLine(
        Color(0x33FFFFFF),
        Offset(r.x, 1.5.dp.toPx()), Offset(size.width - r.x, 1.5.dp.toPx()), 1.dp.toPx(),
    )
}

/** Jendela cekung gelap (layar, kaset, equalizer). */
internal fun Modifier.recess(): Modifier = this.drawBehind {
    val r = CornerRadius(4.dp.toPx())
    drawRoundRect(Brush.verticalGradient(listOf(Color(0xFF020203), Color(0xFF0C0D0F))), cornerRadius = r)
    drawRoundRect(Color(0xFF34343A), cornerRadius = r, style = Stroke(1.dp.toPx()))
    drawLine(Color(0xAA000000), Offset(r.x, 1.dp.toPx()), Offset(size.width - r.x, 1.dp.toPx()), 2.dp.toPx())
}

/** Tulisan sablon kecil di pelat depan. */
@Composable
internal fun RkLabel(
    text: String,
    modifier: Modifier = Modifier,
    color: Color = RkSilk,
    size: TextUnit = 8.sp,
    textAlign: TextAlign? = null,
) {
    Text(
        text,
        modifier = modifier,
        color = color,
        fontSize = size,
        lineHeight = size,
        fontWeight = FontWeight.Medium,
        textAlign = textAlign,
        maxLines = 1,
        softWrap = false,
    )
}

// ================================================================== TOMBOL

/**
 * Tombol tekan hitam. [led] != null = ada strip LED kecil di tepi atas tombol, menyala kalau [lit].
 */
@Composable
internal fun RkKey(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    led: Color? = null,
    lit: Boolean = false,
    height: Dp = 38.dp,
    content: @Composable BoxScope.() -> Unit,
) {
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    Box(
        modifier
            .height(height)
            .drawBehind {
                val r = CornerRadius(4.dp.toPx())
                val top = if (pressed) Color(0xFF111113) else Color(0xFF3B3C41)
                val bot = if (pressed) Color(0xFF1C1D20) else Color(0xFF1A1B1E)
                drawRoundRect(Brush.verticalGradient(listOf(top, bot)), cornerRadius = r)
                drawRoundRect(Color(0xFF050506), cornerRadius = r, style = Stroke(1.dp.toPx()))
                if (!pressed) {
                    drawLine(
                        Color(0x33FFFFFF),
                        Offset(r.x, 1.5.dp.toPx()), Offset(size.width - r.x, 1.5.dp.toPx()), 1.dp.toPx(),
                    )
                }
                if (led != null) {
                    val lw = size.width * 0.44f
                    val lh = 3.dp.toPx()
                    val lx = (size.width - lw) / 2f
                    val ly = 4.dp.toPx()
                    if (lit) {
                        drawRoundRect(
                            led.copy(alpha = 0.35f),
                            Offset(lx - 2.dp.toPx(), ly - 2.dp.toPx()),
                            Size(lw + 4.dp.toPx(), lh + 4.dp.toPx()),
                            CornerRadius(3.dp.toPx()),
                        )
                    }
                    drawRoundRect(
                        if (lit) led else Color(0xFF2A2C2F),
                        Offset(lx, ly), Size(lw, lh), CornerRadius(lh / 2f),
                    )
                }
            }
            .clickable(interactionSource = source, indication = null, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Box(Modifier.padding(top = if (led != null) 5.dp else 0.dp), contentAlignment = Alignment.Center) {
            content()
        }
    }
}

// ================================================================== KNOB (volume / bass / treble)

/**
 * Knob hitam dengan cincin perak, penunjuk merah dan cincin LED melingkar di sekelilingnya.
 * [frac] 0..1 = posisi knob (sapuan 270 derajat). LED menyala dari [litFrom] sampai [frac]:
 * litFrom = 0 -> menyala dari kiri (volume); litFrom = 0.5 -> menyala dari tengah (bass/treble +/-).
 * [onTurn] (opsional) menerima perubahan pecahan tiap gerakan jari melingkar; [onTap] opsional.
 */
@Composable
internal fun RkKnob(
    frac: Float,
    knobSize: Dp,
    description: String,
    modifier: Modifier = Modifier,
    litFrom: Float = 0f,
    ledColor: Color = RkAmber,
    onTurn: ((Float) -> Unit)? = null,
    onTap: (() -> Unit)? = null,
) {
    val turn by rememberUpdatedState(onTurn)
    val tap by rememberUpdatedState(onTap)
    val sweep = 270f * PI.toFloat() / 180f

    Canvas(
        modifier
            .size(knobSize)
            .semantics { contentDescription = description }
            .pointerInput(Unit) { detectTapGestures(onTap = { tap?.invoke() }) }
            .then(
                if (onTurn == null) Modifier else Modifier.pointerInput(Unit) {
                    detectDragGestures { change, _ ->
                        change.consume()
                        val c = Offset(size.width / 2f, size.height / 2f)
                        val a = change.previousPosition - c
                        val b = change.position - c
                        if (a.getDistance() > 4f && b.getDistance() > 4f) {
                            val cross = a.x * b.y - a.y * b.x
                            val dot = a.x * b.x + a.y * b.y
                            turn?.invoke(atan2(cross, dot) / sweep)
                        }
                    }
                }
            )
    ) {
        val cx = size.width / 2f
        val cy = size.height / 2f
        val c = Offset(cx, cy)
        val r = size.minDimension / 2f
        val f = frac.coerceIn(0f, 1f)
        val knobDeg = -135f + f * 270f
        fun pt(deg: Float, rad: Float): Offset {
            val a = Math.toRadians((deg - 90f).toDouble())
            return Offset(cx + (rad * cos(a)).toFloat(), cy + (rad * sin(a)).toFloat())
        }
        val dp1 = 1.dp.toPx()

        // ---- cincin LED melingkar (21 titik) mengikuti posisi knob
        val lo = min(litFrom, f)
        val hi = max(litFrom, f)
        for (i in 0..20) {
            val t = i / 20f
            val deg = -135f + t * 270f
            val lit = t >= lo - 0.001f && t <= hi + 0.001f
            val p = pt(deg, r * 0.92f)
            if (lit) {
                drawCircle(ledColor.copy(alpha = 0.30f), 3.6.dp.toPx(), p)
                drawCircle(ledColor, 1.9.dp.toPx(), p)
            } else {
                drawCircle(Color(0xFF3A2F1C), 1.6.dp.toPx(), p)
            }
        }

        // ---- badan knob
        val rb = r * 0.70f
        drawCircle(
            Brush.radialGradient(listOf(Color(0x99000000), Color(0x00000000)), c + Offset(0f, rb * 0.10f), rb * 1.3f),
            rb * 1.3f, c + Offset(0f, rb * 0.10f),
        )
        drawCircle(Brush.radialGradient(listOf(Color(0xFF3A3B40), Color(0xFF0E0E10)), c, rb), rb, c)
        // gerigi yang ikut berputar
        for (i in 0 until 40) {
            val deg = knobDeg + i * 9f
            drawLine(Color(0xAA000000), pt(deg, rb * 0.86f), pt(deg, rb * 0.99f), 1.2.dp.toPx())
            drawLine(Color(0x33FFFFFF), pt(deg + 2.5f, rb * 0.86f), pt(deg + 2.5f, rb * 0.99f), 0.7.dp.toPx())
        }
        // cincin perak
        drawCircle(
            Brush.verticalGradient(listOf(Color(0xFFE2E4E8), Color(0xFF5E6168)), cy - rb, cy + rb),
            rb, c, style = Stroke(1.6.dp.toPx()),
        )
        // tutup tengah
        val rc = rb * 0.72f
        drawCircle(Brush.radialGradient(listOf(Color(0xFF2E2F33), Color(0xFF121214)), c - Offset(rc * 0.2f, rc * 0.25f), rc * 1.3f), rc, c)
        drawCircle(Color(0x55FFFFFF), rc, c, style = Stroke(0.8.dp.toPx()))
        // penunjuk merah
        drawLine(RkRed, pt(knobDeg, rb * 0.30f), pt(knobDeg, rb * 0.96f), 2.4.dp.toPx(), StrokeCap.Round)
        drawCircle(Color(0x33FFFFFF), rc * 0.92f, c - Offset(0f, dp1), style = Stroke(dp1))
    }
}

// ================================================================== VU METER AMBER (lampu belakang oranye)

private const val RK_VU_MIN = -20f
private const val RK_VU_MAX = 3f

/** Level linear (0..1) -> posisi jarum 0..1 pada skala -20..+3 dB. */
internal fun rkVuFrac(lin: Float): Float {
    if (lin <= 0.00002f) return 0f
    return ((20f * log10(lin) - RK_VU_MIN) / (RK_VU_MAX - RK_VU_MIN)).coerceIn(0f, 1f)
}

/** Level linear (0..1) -> 0..1 pada skala -40..0 dB, untuk LED meter. */
internal fun rkLedFrac(lin: Float): Float {
    if (lin <= 0.00002f) return 0f
    return ((20f * log10(lin) + 40f) / 40f).coerceIn(0f, 1f)
}

/**
 * Level kiri/kanan linear (0..1) yang dihaluskan: naik cepat, turun pelan. Dikalikan volume pemutar
 * supaya meter ikut bergerak saat knob volume diputar.
 */
@Composable
internal fun rkStereoLevels(playing: Boolean, volume: Float): Pair<Float, Float> {
    val playingNow by rememberUpdatedState(playing)
    val volumeNow by rememberUpdatedState(volume)
    var levels by remember { mutableStateOf(0f to 0f) }
    LaunchedEffect(Unit) {
        var last = 0L
        while (true) {
            val now = androidx.compose.runtime.withFrameNanos { it }
            if (now - last < 33_000_000L) continue
            last = now
            val (oldL, oldR) = levels
            if (!playingNow && oldL <= 0.0005f && oldR <= 0.0005f) {
                if (oldL != 0f || oldR != 0f) levels = 0f to 0f
                continue
            }
            val pr = AudioEngine.processor
            val tl = if (playingNow) pr.levelL * volumeNow else 0f
            val tr = if (playingNow) pr.levelR * volumeNow else 0f
            levels = (oldL + (tl - oldL) * (if (tl > oldL) 0.6f else 0.12f)) to
                (oldR + (tr - oldR) * (if (tr > oldR) 0.6f else 0.12f))
        }
    }
    return levels
}

/**
 * VU meter berlampu belakang oranye, bingkai hitam, jarum tipis. [tuner] = true: skala 0..10 tanpa zona merah
 * (dipakai meter SIGNAL / TUNING di mode radio). [frac] = posisi jarum 0..1.
 */
@Composable
internal fun AmberVu(
    label: String,
    frac: Float,
    modifier: Modifier = Modifier,
    tuner: Boolean = false,
    tag: String = "VU",
) {
    val paint = remember {
        android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
            typeface = android.graphics.Typeface.create(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD)
            textAlign = android.graphics.Paint.Align.CENTER
        }
    }
    val ink = Color(0xFF2A1604)
    val red = Color(0xFFC62812)
    Box(modifier) {
        Canvas(Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            val f = frac.coerceIn(0f, 1f)

            // bingkai hitam
            val outer = CornerRadius(5.dp.toPx())
            drawRoundRect(Brush.verticalGradient(listOf(Color(0xFF2A2A2E), Color(0xFF050506))), cornerRadius = outer)
            drawRoundRect(Color(0xFF4A4A50), cornerRadius = outer, style = Stroke(1.dp.toPx()))
            val bz = 3.dp.toPx()
            val fx = bz
            val fy = bz
            val fw = w - 2 * bz
            val fh = h - 2 * bz
            val faceR = CornerRadius(3.dp.toPx())
            val faceTL = Offset(fx, fy)
            val faceSz = Size(fw, fh)

            // muka oranye menyala dari belakang
            drawRoundRect(
                Brush.verticalGradient(listOf(Color(0xFFFFE3A3), Color(0xFFFFC45A), Color(0xFFE88E1C)), fy, fy + fh),
                faceTL, faceSz, faceR,
            )
            drawRoundRect(
                Brush.radialGradient(listOf(Color(0x66FFFFFF), Color(0x00FFFFFF)), Offset(w / 2f, fy + fh * 0.45f), fw * 0.6f),
                faceTL, faceSz, faceR,
            )
            drawRoundRect(
                Brush.horizontalGradient(listOf(Color(0x77000000), Color(0x00000000), Color(0x00000000), Color(0x77000000))),
                faceTL, faceSz, faceR,
            )
            drawRoundRect(
                Brush.verticalGradient(listOf(Color(0x88000000), Color(0x00000000)), fy, fy + 8.dp.toPx()),
                faceTL, faceSz, faceR,
            )

            // geometri busur (pivot di bawah muka)
            val maxDeg = 42f
            val sinM = sin(Math.toRadians(maxDeg.toDouble())).toFloat()
            val cosM = cos(Math.toRadians(maxDeg.toDouble())).toFloat()
            val topMargin = 9.dp.toPx() + bz
            val rs = min(fw * 0.47f / sinM, (h - 18.dp.toPx() - bz) / (1f - cosM)).coerceAtLeast(20.dp.toPx())
            val pivot = Offset(w / 2f, topMargin + rs)
            fun angOf(fr: Float) = -maxDeg + fr * maxDeg * 2f
            fun pt(deg: Float, rad: Float): Offset {
                val a = Math.toRadians(deg.toDouble())
                return Offset(pivot.x + rad * sin(a).toFloat(), pivot.y - rad * cos(a).toFloat())
            }

            // posisi garis skala: (pecahan 0..1, garis besar?)
            val ticks: List<Pair<Float, Boolean>>
            val labels: List<Pair<Float, String>>
            val redFrom: Float
            if (tuner) {
                ticks = (0..10).map { it / 10f to (it % 5 == 0) }
                labels = emptyList()
                redFrom = 2f
            } else {
                val dbs = listOf(-20f, -15f, -10f, -9f, -8f, -7f, -6f, -5f, -4f, -3f, -2f, -1f, 0f, 1f, 2f, 3f)
                val majors = setOf(-20f, -10f, -7f, -5f, -3f, 0f, 3f)
                fun fr(db: Float) = (db - RK_VU_MIN) / (RK_VU_MAX - RK_VU_MIN)
                ticks = dbs.map { fr(it) to (it in majors) }
                labels = listOf(-20f to "20", -10f to "10", -7f to "7", -5f to "5", -3f to "3", 0f to "0", 3f to "+3")
                    .map { fr(it.first) to it.second }
                redFrom = fr(0f)
            }

            clipRect(fx, fy, fx + fw, fy + fh) {
                val arcTL = Offset(pivot.x - rs, pivot.y - rs)
                val arcSz = Size(rs * 2f, rs * 2f)
                drawArc(ink, -90f + angOf(0f), maxDeg * 2f, false, arcTL, arcSz, style = Stroke(1.8.dp.toPx()))
                if (redFrom < 1f) {
                    val rs0 = angOf(redFrom)
                    drawArc(red, -90f + rs0, maxDeg - rs0, false, arcTL, arcSz, style = Stroke(3.6.dp.toPx()))
                }
                for ((fr, major) in ticks) {
                    val inRed = fr >= redFrom
                    drawLine(
                        if (inRed) red else ink,
                        pt(angOf(fr), rs * (if (major) 0.86f else 0.92f)), pt(angOf(fr), rs),
                        if (major) 1.5.dp.toPx() else 0.8.dp.toPx(),
                    )
                }
                paint.textSize = 6.sp.toPx()
                for ((fr, txt) in labels) {
                    paint.color = (if (fr >= redFrom) red else ink).toArgb()
                    val p = pt(angOf(fr), rs * 0.74f)
                    drawContext.canvas.nativeCanvas.drawText(txt, p.x, p.y + 2.dp.toPx(), paint)
                }

                // jarum: bayangan lalu badan
                val needleDeg = angOf(f)
                val tip = pt(needleDeg, rs * 0.99f)
                val shadowOff = Offset(1.8.dp.toPx(), 1.6.dp.toPx())
                drawLine(Color(0x44000000), pivot + shadowOff, tip + shadowOff, 1.6.dp.toPx(), StrokeCap.Round)
                drawLine(Color(0xFF120A02), pivot, tip, 1.5.dp.toPx(), StrokeCap.Round)
                drawRect(
                    Brush.verticalGradient(listOf(Color(0x00000000), Color(0x66000000)), fy + fh - 9.dp.toPx(), fy + fh),
                    Offset(fx, fy + fh - 9.dp.toPx()), Size(fw, 9.dp.toPx()),
                )
            }

            // kaca
            drawRoundRect(
                Brush.verticalGradient(listOf(Color(0x25FFFFFF), Color(0x05FFFFFF)), fy, fy + fh * 0.5f),
                faceTL, Size(fw, fh * 0.5f), faceR,
            )
            drawRoundRect(Color(0xAA000000), faceTL, faceSz, faceR, style = Stroke(1.dp.toPx()))
        }
        Text(
            label,
            color = ink,
            fontSize = 9.sp,
            lineHeight = 10.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.align(Alignment.BottomStart).padding(start = 7.dp, bottom = 4.dp),
        )
        Text(
            tag,
            color = ink,
            fontSize = 8.sp,
            lineHeight = 9.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.align(Alignment.BottomEnd).padding(end = 7.dp, bottom = 4.dp),
        )
    }
}

// ================================================================== LED METER + SPECTRUM LED

/** LED meter berdiri (menyala dari bawah): hijau -> kuning -> merah. [frac] 0..1. */
@Composable
internal fun RkLedBar(frac: Float, modifier: Modifier = Modifier, segs: Int = 16) {
    Canvas(modifier) {
        val gap = 1.2.dp.toPx()
        val sh = ((size.height - gap * (segs - 1)) / segs).coerceAtLeast(1f)
        val lit = (frac.coerceIn(0f, 1f) * segs + 0.5f).toInt()
        for (i in 0 until segs) {
            val y = size.height - (i + 1) * sh - i * gap
            val t = i / (segs - 1f)
            val col = if (t < 0.6f) RkGreen else if (t < 0.85f) RkAmber else RkRed
            if (i < lit) drawRoundRect(col.copy(alpha = 0.28f), Offset(-1.dp.toPx(), y - 1.dp.toPx()), Size(size.width + 2.dp.toPx(), sh + 2.dp.toPx()), CornerRadius(2.dp.toPx()))
            drawRoundRect(
                if (i < lit) col else col.copy(alpha = 0.13f),
                Offset(0f, y), Size(size.width, sh), CornerRadius(1.dp.toPx()),
            )
        }
    }
}

/** Diagram LED spectrum 19 bar: tiap bar tersusun dari kotak LED hijau -> kuning -> merah, plus penanda puncak. */
@Composable
internal fun RkLedSpectrum(playing: Boolean, modifier: Modifier = Modifier) {
    val analyzer = remember { SpectrumAnalyzer(AudioEngine.processor) }
    val n = SpectrumAnalyzer.BARS
    var bars by remember { mutableStateOf(FloatArray(n)) }
    val peaks = remember { FloatArray(n) }
    val playingNow by rememberUpdatedState(playing)

    LaunchedEffect(Unit) {
        var last = 0L
        while (true) {
            val now = androidx.compose.runtime.withFrameNanos { it }
            if (now - last < 30_000_000L) continue
            last = now
            val old = bars
            val idle = !playingNow && old.all { it <= 0f } && peaks.all { it <= 0f }
            if (idle) continue
            val fresh = if (playingNow) analyzer.compute() else FloatArray(n)
            val next = FloatArray(n) { i -> max(fresh[i], old[i] - 0.07f) }
            for (i in 0 until n) peaks[i] = max(next[i], max(peaks[i] - 0.015f, 0f))
            bars = next
        }
    }

    Canvas(modifier) {
        val b = bars
        val gap = 2.dp.toPx()
        val bw = (size.width - gap * (n - 1)) / n
        val segs = 12
        val sg = 1.2.dp.toPx()
        val sh = (size.height - sg * (segs - 1)) / segs
        fun colorOf(s: Int): Color {
            val t = s / (segs - 1f)
            return if (t < 0.58f) RkGreen else if (t < 0.84f) RkAmber else RkRed
        }
        for (i in 0 until n) {
            val x = i * (bw + gap)
            val lit = (b[i] * segs).toInt()
            val pk = (peaks[i] * segs).toInt().coerceIn(0, segs - 1)
            for (s in 0 until segs) {
                val y = size.height - (s + 1) * sh - s * sg
                val col = colorOf(s)
                val on = s < lit || (s == pk && peaks[i] > 0.02f)
                drawRect(if (on) col else col.copy(alpha = 0.10f), Offset(x, y), Size(bw, sh))
            }
        }
    }
}

// ================================================================== SEEK BAR

/** Bar posisi lagu: alur gelap, isi hijau, gagang bulat perak. */
@Composable
internal fun RkSeek(
    value: Float,
    onChange: (Float) -> Unit,
    onDone: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val change by rememberUpdatedState(onChange)
    val done by rememberUpdatedState(onDone)
    Canvas(
        modifier.pointerInput(Unit) {
            val pad = 7.dp.toPx()
            val len = size.width.toFloat()
            fun upd(p: Offset) = change(((p.x - pad) / max(len - 2 * pad, 1f)).coerceIn(0f, 1f))
            awaitEachGesture {
                val down = awaitFirstDown()
                upd(down.position)
                down.consume()
                drag(down.id) {
                    upd(it.position)
                    it.consume()
                }
                done()
            }
        }
    ) {
        val pad = 7.dp.toPx()
        val v = value.coerceIn(0f, 1f)
        val gy = size.height / 2f
        val gh = 4.dp.toPx()
        val track = size.width - 2 * pad
        val x = pad + v * track
        drawRoundRect(Color(0xFF020203), Offset(pad, gy - gh / 2f), Size(track, gh), CornerRadius(gh / 2f))
        drawRoundRect(Color(0xFF3A3A40), Offset(pad, gy - gh / 2f), Size(track, gh), CornerRadius(gh / 2f), style = Stroke(0.8.dp.toPx()))
        if (x > pad) drawRoundRect(RkGreen, Offset(pad, gy - gh / 2f), Size(x - pad, gh), CornerRadius(gh / 2f))
        drawCircle(Brush.verticalGradient(listOf(Color(0xFFE6E8EC), Color(0xFF6A6D74)), gy - 6.dp.toPx(), gy + 6.dp.toPx()), 6.dp.toPx(), Offset(x, gy))
        drawCircle(Color(0xFF050506), 6.dp.toPx(), Offset(x, gy), style = Stroke(1.dp.toPx()))
    }
}
