package com.example.pemutarmusik

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.drag
import androidx.compose.foundation.gestures.waitForUpOrCancellation
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.displayCutoutPadding
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.RepeatOne
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.Player
import com.example.pemutarmusik.audio.AudioEngine
import com.example.pemutarmusik.audio.EqAudioProcessor
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.Locale
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * Tampilan PORTRAIT: rak hi-fi hitam bertumpuk, dari atas:
 *   1. Pemutar MP3 / Radio (selektor MP3 | RADIO, panel berganti)
 *   2. Equalizer 7 band, kiri dan kanan terpisah, LED meter L/R kecil di tengah
 *   3. Amplifier: 2 VU meter, knob volume, knob bass dan treble (tombol + / - dan LED melingkar)
 * Semua fungsi (daftar lagu, album, stasiun, scan, sleep, EQ, bisu) memakai PlayerViewModel / AudioEngine yang sama.
 */
@Composable
fun RackScreen(
    vm: PlayerViewModel,
    granted: Boolean,
    onRequestPermission: () -> Unit,
    onDeleteSong: (Song) -> Unit,
    onMinimize: () -> Unit,
    onClose: () -> Unit,
) {
    val mode by vm.mode.collectAsState()
    var showList by rememberSaveable { mutableStateOf(false) }
    val appContext = LocalContext.current
    val version = remember { rackVersion(appContext) }
    BackHandler(enabled = showList) { showList = false }

    Box(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF111114), Color(0xFF030304))))
            .displayCutoutPadding()
            .navigationBarsPadding()
    ) {
        Column(Modifier.fillMaxSize()) {
            RackTopBar(version, onMinimize, onClose)
            Column(
                Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 6.dp, vertical = 4.dp),
                verticalArrangement = Arrangement.spacedBy(5.dp),
            ) {
                SourceUnit(vm, mode, onList = { showList = true })
                EqUnit(vm)
                AmpUnit(vm)
            }
        }

        // Daftar lagu / stasiun: menutupi rak sampai ditutup dengan tombol × (atau tombol kembali)
        if (showList) {
            Box(
                Modifier
                    .fillMaxSize()
                    .background(Color(0xEE000000))
                    .pointerInput(Unit) { detectTapGestures { } }
                    .padding(6.dp)
                    .imePadding()
            ) {
                if (mode == AppMode.MP3) {
                    PlaylistWindow(
                        vm = vm,
                        granted = granted,
                        onRequestPermission = onRequestPermission,
                        onDeleteSong = onDeleteSong,
                        onMinimize = { showList = false; onMinimize() },
                        onClose = { showList = false },
                        modifier = Modifier.fillMaxSize(),
                    )
                } else {
                    RadioListWindow(
                        vm = vm,
                        onMinimize = { showList = false; onMinimize() },
                        onClose = { showList = false },
                        modifier = Modifier.fillMaxSize(),
                    )
                }
            }
        }
    }
}

private fun rackVersion(context: android.content.Context): String = try {
    "v.${context.packageManager.getPackageInfo(context.packageName, 0).versionName}"
} catch (e: Exception) {
    ""
}

@Composable
private fun RackTopBar(version: String, onMinimize: () -> Unit, onClose: () -> Unit) {
    val h = 30.dp
    Row(
        Modifier.fillMaxWidth().height(h).padding(start = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            "mod by aries $version",
            color = RkDim,
            fontSize = 10.sp,
            fontStyle = FontStyle.Italic,
            fontFamily = FontFamily.Monospace,
            maxLines = 1,
            modifier = Modifier.weight(1f),
        )
        WaTitleButton(false, "Kecilkan ke mini player", h) { onMinimize() }
        WaTitleButton(true, "Tutup aplikasi", h) { onClose() }
    }
}

// ================================================================== UNIT 1: PEMUTAR MP3 / RADIO

@Composable
private fun SourceUnit(vm: PlayerViewModel, mode: AppMode, onList: () -> Unit) {
    val ui by vm.ui.collectAsState()
    Column(
        Modifier.fillMaxWidth().faceplate().padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(7.dp),
    ) {
        // selektor sumber: MP3 | RADIO (panel di bawahnya berganti) + tombol daftar
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            RkKey({ vm.setMode(AppMode.MP3) }, Modifier.weight(1f), led = RkGreen, lit = mode == AppMode.MP3, height = 34.dp) {
                RkLabel("MP3", color = Color.White, size = 11.sp)
            }
            RkKey({ vm.setMode(AppMode.RADIO) }, Modifier.weight(1f), led = RkGreen, lit = mode == AppMode.RADIO, height = 34.dp) {
                RkLabel("RADIO", color = Color.White, size = 11.sp)
            }
            RkKey(onList, Modifier.weight(1f), height = 34.dp) {
                RkLabel(if (mode == AppMode.MP3) "PLAYLIST" else "STASIUN", color = Color.White, size = 10.sp)
            }
        }
        if (mode == AppMode.MP3) Mp3Panel(vm, ui) else RadioPanel(vm, ui)
    }
}

@Composable
private fun KeyIcon(icon: ImageVector, description: String, tint: Color = RkSilk) {
    Icon(imageVector = icon, contentDescription = description, tint = tint, modifier = Modifier.size(22.dp))
}

@Composable
private fun Digits(text: String, color: Color = RkGreen, size: Int = 12) {
    Text(text, color = color, fontSize = size.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, maxLines = 1)
}

// ---------------------------------------------------------------- panel MP3

@Composable
private fun Mp3Panel(vm: PlayerViewModel, ui: PlayerUi) {
    var drag by remember { mutableStateOf<Float?>(null) }
    val fraction = if (ui.durationMs > 0) (ui.positionMs.toFloat() / ui.durationMs).coerceIn(0f, 1f) else 0f
    val shown = drag ?: fraction
    val shownMs = if (drag != null) (shown * ui.durationMs).toLong() else ui.positionMs

    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        // gambar kaset deck
        CassetteDeck(
            title = ui.title,
            artist = ui.artist,
            playing = ui.isPlaying,
            progress = shown,
            modifier = Modifier.fillMaxWidth().aspectRatio(2.3f),
        )

        // posisi lagu
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            Digits(formatTime(shownMs))
            RkSeek(
                value = shown,
                onChange = { drag = it },
                onDone = {
                    drag?.let { vm.seekTo((it * ui.durationMs).toLong()) }
                    drag = null
                },
                modifier = Modifier.weight(1f).height(18.dp),
            )
            Digits(formatTime(ui.durationMs), color = RkDim)
        }

        // tombol: sebelumnya, jeda, putar, henti, berikutnya | acak, ulang
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            RkKey(vm::previous, Modifier.weight(1f)) { KeyIcon(Icons.Filled.SkipPrevious, "Sebelumnya") }
            RkKey(vm::pause, Modifier.weight(1f), led = RkAmber, lit = ui.isPaused) { KeyIcon(Icons.Filled.Pause, "Jeda") }
            RkKey(vm::play, Modifier.weight(1f), led = RkGreen, lit = ui.isPlaying) { KeyIcon(Icons.Filled.PlayArrow, "Putar") }
            RkKey(vm::stop, Modifier.weight(1f), led = RkRed, lit = ui.isStopped) { KeyIcon(Icons.Filled.Stop, "Henti") }
            RkKey(vm::next, Modifier.weight(1f)) { KeyIcon(Icons.Filled.SkipNext, "Berikutnya") }
            Spacer(Modifier.width(4.dp))
            RkKey(vm::toggleShuffle, Modifier.weight(1f), led = RkGreen, lit = ui.shuffle) { KeyIcon(Icons.Filled.Shuffle, "Acak") }
            RkKey(
                vm::toggleRepeat, Modifier.weight(1f),
                led = if (ui.repeatMode == Player.REPEAT_MODE_ONE) RkAmber else RkGreen,
                lit = ui.repeatMode != Player.REPEAT_MODE_OFF,
            ) {
                KeyIcon(
                    if (ui.repeatMode == Player.REPEAT_MODE_ONE) Icons.Filled.RepeatOne else Icons.Filled.Repeat,
                    when (ui.repeatMode) {
                        Player.REPEAT_MODE_ONE -> "Ulang 1 lagu"
                        Player.REPEAT_MODE_ALL -> "Ulang semua"
                        else -> "Ulang mati"
                    },
                )
            }
        }

        // diagram LED (spectrum)
        Box(Modifier.fillMaxWidth().height(60.dp).recess().padding(6.dp)) {
            RkLedSpectrum(ui.isPlaying, Modifier.fillMaxSize())
        }
    }
}

/** Gambar kaset: badan kaset, label bertulis judul lagu, dua roda pita yang berputar saat lagu diputar. */
@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun CassetteDeck(
    title: String?,
    artist: String?,
    playing: Boolean,
    progress: Float,
    modifier: Modifier = Modifier,
) {
    var angle by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(playing) {
        if (!playing) return@LaunchedEffect
        var last = 0L
        while (true) {
            val t = androidx.compose.runtime.withFrameNanos { it }
            if (last != 0L) angle = (angle + (t - last) / 1_000_000_000f * 200f) % 360f
            last = t
        }
    }
    val p = progress.coerceIn(0f, 1f)

    BoxWithConstraints(modifier.recess()) {
        val mw = maxWidth
        val mh = maxHeight
        Canvas(Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            val cl = w * 0.08f
            val cr = w * 0.92f
            val ct = h * 0.08f
            val cb = h * 0.94f
            val cw = cr - cl
            val ch = cb - ct
            val body = CornerRadius(8.dp.toPx())

            // badan kaset
            drawRoundRect(
                Brush.verticalGradient(listOf(Color(0xFF5A5C62), Color(0xFF2C2D31)), ct, cb),
                Offset(cl, ct), Size(cw, ch), body,
            )
            drawRoundRect(Color(0xFF0A0A0B), Offset(cl, ct), Size(cw, ch), body, style = Stroke(1.5.dp.toPx()))
            // sekrup di empat sudut
            for (sx in listOf(cl + 8.dp.toPx(), cr - 8.dp.toPx())) {
                for (sy in listOf(ct + 8.dp.toPx(), cb - 8.dp.toPx())) {
                    drawCircle(Color(0xFF16161A), 2.6.dp.toPx(), Offset(sx, sy))
                    drawCircle(Color(0xFF8A8D94), 2.dp.toPx(), Offset(sx, sy), style = Stroke(0.8.dp.toPx()))
                }
            }

            // label kertas
            val ll = cl + cw * 0.10f
            val lr = cr - cw * 0.10f
            val lt = ct + ch * 0.10f
            val lb = ct + ch * 0.46f
            drawRoundRect(
                Brush.verticalGradient(listOf(Color(0xFFF3EEDA), Color(0xFFD8D1B6)), lt, lb),
                Offset(ll, lt), Size(lr - ll, lb - lt), CornerRadius(3.dp.toPx()),
            )
            drawRect(Color(0xFFD9412F), Offset(ll + 3.dp.toPx(), lt + 2.dp.toPx()), Size(lr - ll - 6.dp.toPx(), (lb - lt) * 0.12f))
            for (k in 1..2) {
                val ly = lt + (lb - lt) * (0.44f + k * 0.22f)
                drawLine(Color(0x33000000), Offset(ll + 6.dp.toPx(), ly), Offset(lr - 6.dp.toPx(), ly), 0.8.dp.toPx())
            }

            // jendela pita (kapsul gelap) + dua roda
            val wl = cl + cw * 0.20f
            val wr = cr - cw * 0.20f
            val wt = ct + ch * 0.54f
            val wb = ct + ch * 0.88f
            val rc = (wb - wt) / 2f
            val cy = (wt + wb) / 2f
            drawRoundRect(Color(0xFF0B0B0C), Offset(wl, wt), Size(wr - wl, wb - wt), CornerRadius(rc))
            drawRoundRect(Color(0xFF55575D), Offset(wl, wt), Size(wr - wl, wb - wt), CornerRadius(rc), style = Stroke(1.dp.toPx()))
            val hub = rc * 0.52f
            val lx = wl + rc
            val rx = wr - rc
            val packL = rc * 0.96f + (hub * 1.1f - rc * 0.96f) * p
            val packR = hub * 1.1f + (rc * 0.96f - hub * 1.1f) * p
            val tape = Color(0xFF3A2A1B)
            drawCircle(tape, packL, Offset(lx, cy))
            drawCircle(Color(0xFF5A4330), packL, Offset(lx, cy), style = Stroke(0.8.dp.toPx()))
            drawCircle(tape, packR, Offset(rx, cy))
            drawCircle(Color(0xFF5A4330), packR, Offset(rx, cy), style = Stroke(0.8.dp.toPx()))
            for ((hx, hy) in listOf(lx to cy, rx to cy)) {
                val hc = Offset(hx, hy)
                drawCircle(Color(0xFFE9E9EC), hub, hc)
                drawCircle(Color(0xFF111113), hub * 0.62f, hc)
                for (k in 0 until 6) {
                    val a = Math.toRadians((angle + k * 60f).toDouble())
                    val dx = kotlin.math.cos(a).toFloat()
                    val dy = kotlin.math.sin(a).toFloat()
                    drawLine(
                        Color(0xFFE9E9EC),
                        Offset(hx + dx * hub * 0.50f, hy + dy * hub * 0.50f),
                        Offset(hx + dx * hub * 0.90f, hy + dy * hub * 0.90f),
                        1.6.dp.toPx(),
                    )
                }
            }
            // pita antar roda
            drawLine(tape, Offset(lx, cy + packL), Offset(rx, cy + packR), 1.2.dp.toPx())
        }

        // tulisan di label kaset
        Column(
            Modifier
                .offset(x = mw * 0.18f, y = mh * 0.17f)
                .width(mw * 0.64f),
        ) {
            Text(
                if (title != null) title else "MP3 PLAYER",
                color = Color(0xFF2A2A2A),
                fontSize = 13.sp,
                lineHeight = 15.sp,
                fontFamily = FontFamily.Cursive,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                softWrap = false,
                modifier = Modifier.fillMaxWidth().basicMarquee(iterations = Int.MAX_VALUE),
            )
            Text(
                if (title != null) (artist ?: "") else "pilih lagu di PLAYLIST",
                color = Color(0xFF55524A),
                fontSize = 9.sp,
                lineHeight = 11.sp,
                maxLines = 1,
                softWrap = false,
                modifier = Modifier.fillMaxWidth(),
            )
        }
    }
}

// ---------------------------------------------------------------- panel RADIO

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun RadioPanel(vm: PlayerViewModel, ui: PlayerUi) {
    val stations by vm.stations.collectAsState()
    val stationId by vm.stationId.collectAsState()
    val error by vm.radioError.collectAsState()
    val scanning by vm.scanning.collectAsState()
    val sleepLeft by vm.sleepLeft.collectAsState()
    val station = stations.firstOrNull { it.id == stationId }

    val stopped = ui.playbackState == Player.STATE_IDLE || ui.playbackState == Player.STATE_ENDED
    val connecting = !stopped && ui.playWhenReady && ui.playbackState == Player.STATE_BUFFERING
    val playing = ui.isPlaying
    val paused = !stopped && !playing && !connecting

    val freq = station?.freqValue
    val freqText = freq?.let { String.format(Locale.US, "%.1f", it) } ?: "--.-"
    val onAir = if (station != null && ui.mediaId == "radio:${station.id}") ui.title?.takeIf { it != station.name } else null
    val (lvL, lvR) = rkStereoLevels(playing, ui.volume)

    val signal by animateFloatAsState(
        targetValue = when {
            playing -> 0.72f + 0.22f * rkLedFrac(max(lvL, lvR))
            connecting -> 0.30f
            else -> 0f
        },
        animationSpec = tween(450), label = "signal",
    )
    val tuning by animateFloatAsState(
        targetValue = when {
            playing -> 0.5f
            connecting || scanning -> 0.3f
            else -> 0f
        },
        animationSpec = tween(450), label = "tuning",
    )
    val red = Color(0xFFFF4A3D)

    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(Modifier.fillMaxWidth().height(92.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            AmberVu("SIGNAL", signal, Modifier.width(76.dp).fillMaxHeight(), tuner = true, tag = "")
            AmberVu("TUNING", tuning, Modifier.width(76.dp).fillMaxHeight(), tuner = true, tag = "")
            // layar LCD merah
            Column(
                Modifier.weight(1f).fillMaxHeight().recess().padding(horizontal = 8.dp, vertical = 5.dp),
                verticalArrangement = Arrangement.SpaceBetween,
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("STEREO", color = if (playing) red else red.copy(alpha = 0.18f), fontSize = 8.sp, lineHeight = 9.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                    val status = when {
                        error != null -> "ERROR"
                        scanning -> "SCAN"
                        connecting -> "WAIT"
                        playing -> "ON AIR"
                        paused -> "PAUSE"
                        else -> "STOP"
                    }
                    Text(status, color = red, fontSize = 8.sp, lineHeight = 9.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                }
                Row(verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.End, modifier = Modifier.fillMaxWidth()) {
                    Text("FM", color = red, fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 4.dp))
                    Spacer(Modifier.width(6.dp))
                    Box(contentAlignment = Alignment.CenterEnd) {
                        Text("888.8", color = red.copy(alpha = 0.10f), fontSize = 30.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, maxLines = 1)
                        Text(freqText, color = red, fontSize = 30.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, maxLines = 1)
                    }
                    Spacer(Modifier.width(4.dp))
                    Text("MHz", color = red, fontSize = 9.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.padding(bottom = 5.dp))
                }
                val label = when {
                    error != null -> "! $error   "
                    station == null -> "PILIH STASIUN   ***   "
                    onAir != null -> "${station.name} - $onAir   ***   "
                    else -> "${station.name}   ***   "
                }
                Text(
                    label,
                    color = if (error != null) Color(0xFFFF9E94) else Color(0xFFFFD2CC),
                    fontSize = 11.sp, lineHeight = 13.sp,
                    fontFamily = FontFamily.Monospace,
                    maxLines = 1, softWrap = false,
                    modifier = Modifier.fillMaxWidth().basicMarquee(iterations = Int.MAX_VALUE),
                )
            }
        }

        // preset 1..8 = 8 stasiun pertama (urut frekuensi)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(3.dp), verticalAlignment = Alignment.CenterVertically) {
            for (i in 0 until 8) {
                val st = stations.getOrNull(i)
                RkKey(
                    onClick = { st?.let { vm.playStation(it) } },
                    modifier = Modifier.weight(1f),
                    led = RkAmber, lit = st != null && st.id == stationId,
                    height = 32.dp,
                ) {
                    RkLabel("${i + 1}", color = if (st != null) Color.White else RkDim, size = 11.sp)
                }
            }
        }

        // DOWN, jeda, putar, henti, UP | SCAN, SLEEP
        val on = playing || connecting
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            RkKey({ vm.stepStation(-1) }, Modifier.weight(1f)) { KeyIcon(Icons.Filled.SkipPrevious, "Stasiun sebelumnya") }
            RkKey(vm::radioPause, Modifier.weight(1f), led = RkAmber, lit = paused) { KeyIcon(Icons.Filled.Pause, "Jeda") }
            RkKey(vm::radioPlay, Modifier.weight(1f), led = RkGreen, lit = on) { KeyIcon(Icons.Filled.PlayArrow, "Putar") }
            RkKey(vm::radioStop, Modifier.weight(1f), led = RkRed, lit = stopped) { KeyIcon(Icons.Filled.Stop, "Henti") }
            RkKey({ vm.stepStation(+1) }, Modifier.weight(1f)) { KeyIcon(Icons.Filled.SkipNext, "Stasiun berikutnya") }
            Spacer(Modifier.width(4.dp))
            RkKey(vm::toggleScan, Modifier.weight(1f), led = RkGreen, lit = scanning) { RkLabel("SCAN", color = Color.White, size = 9.sp) }
            RkKey(vm::cycleSleep, Modifier.weight(1f), led = RkAmber, lit = sleepLeft > 0) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    RkLabel("SLEEP", color = Color.White, size = 8.sp)
                    if (sleepLeft > 0) RkLabel("${sleepLeft}M", color = RkAmber, size = 8.sp)
                }
            }
        }
    }
}

// ================================================================== UNIT 2: EQUALIZER 7 BAND (KIRI / KANAN)

private val EQ_LABELS = listOf("63", "160", "400", "1K", "2.5K", "6.3K", "16K")
private const val EQ_RANGE_DB = 12f

@Composable
private fun EqUnit(vm: PlayerViewModel) {
    val s by AudioEngine.settings.collectAsState()
    val ui by vm.ui.collectAsState()
    val (lvL, lvR) = rkStereoLevels(ui.isPlaying, ui.volume)

    Column(
        Modifier.fillMaxWidth().faceplate().padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Column(Modifier.weight(1f)) {
                RkLabel("GRAPHIC EQUALIZER", color = Color.White, size = 10.sp)
                Spacer(Modifier.height(2.dp))
                RkLabel("7 BAND  KIRI / KANAN  +/-12 dB")
            }
            RkKey(
                {
                    AudioEngine.update {
                        it.copy(eqL = List(EqAudioProcessor.EQ7_COUNT) { 0f }, eqR = List(EqAudioProcessor.EQ7_COUNT) { 0f })
                    }
                },
                Modifier.width(52.dp), height = 28.dp,
            ) { RkLabel("FLAT", color = Color.White, size = 9.sp) }
            RkKey(
                { AudioEngine.update { it.copy(enabled = !it.enabled) } },
                Modifier.width(52.dp), led = RkGreen, lit = s.enabled, height = 28.dp,
            ) { RkLabel(if (s.enabled) "ON" else "OFF", color = Color.White, size = 9.sp) }
        }

        Row(
            Modifier.fillMaxWidth().height(138.dp).recess().padding(horizontal = 6.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            EqGroup("LEFT", s.eqL, s.enabled, Modifier.weight(1f)) { i, v ->
                AudioEngine.update { st -> st.copy(eqL = st.eqL.toMutableList().also { l -> l[i] = v }) }
            }
            // LED meter L / R kecil di tengah
            Column(Modifier.width(34.dp).fillMaxHeight(), horizontalAlignment = Alignment.CenterHorizontally) {
                Row(Modifier.weight(1f).fillMaxWidth().padding(bottom = 4.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    RkLedBar(rkLedFrac(lvL), Modifier.weight(1f).fillMaxHeight(), segs = 18)
                    RkLedBar(rkLedFrac(lvR), Modifier.weight(1f).fillMaxHeight(), segs = 18)
                }
                Row(Modifier.fillMaxWidth()) {
                    RkLabel("L", Modifier.weight(1f), size = 9.sp, textAlign = TextAlign.Center)
                    RkLabel("R", Modifier.weight(1f), size = 9.sp, textAlign = TextAlign.Center)
                }
                Spacer(Modifier.height(11.dp))
            }
            EqGroup("RIGHT", s.eqR, s.enabled, Modifier.weight(1f)) { i, v ->
                AudioEngine.update { st -> st.copy(eqR = st.eqR.toMutableList().also { l -> l[i] = v }) }
            }
        }
    }
}

@Composable
private fun EqGroup(
    caption: String,
    gains: List<Float>,
    enabled: Boolean,
    modifier: Modifier = Modifier,
    onGain: (Int, Float) -> Unit,
) {
    Column(modifier.fillMaxHeight()) {
        Row(Modifier.fillMaxWidth().weight(1f)) {
            for (i in 0 until EqAudioProcessor.EQ7_COUNT) {
                EqFader(gains.getOrElse(i) { 0f }, enabled, { v -> onGain(i, v) }, Modifier.weight(1f).fillMaxHeight())
            }
        }
        Row(Modifier.fillMaxWidth()) {
            for (i in 0 until EqAudioProcessor.EQ7_COUNT) {
                RkLabel(EQ_LABELS[i], Modifier.weight(1f), size = 7.sp, textAlign = TextAlign.Center)
            }
        }
        RkLabel(caption, Modifier.fillMaxWidth(), size = 8.sp, textAlign = TextAlign.Center, color = RkDim)
    }
}

/** Satu fader vertikal: kolom LED hijau di kiri, alur gelap, tutup fader abu-abu bergaris putih. Ketuk dua kali = 0 dB. */
@Composable
private fun EqFader(value: Float, enabled: Boolean, onChange: (Float) -> Unit, modifier: Modifier = Modifier) {
    val change by rememberUpdatedState(onChange)
    val lastDown = remember { longArrayOf(0L) }

    Canvas(
        modifier.pointerInput(Unit) {
            val capH = 11.dp.toPx()
            val pad = capH / 2f
            fun upd(p: Offset) {
                val track = size.height - 2 * pad
                val fr = 1f - ((p.y - pad) / max(track, 1f)).coerceIn(0f, 1f)
                change(((fr * 2f - 1f) * EQ_RANGE_DB).roundToInt().toFloat())
            }
            awaitEachGesture {
                val down = awaitFirstDown()
                val isDouble = down.uptimeMillis - lastDown[0] < 280L
                lastDown[0] = down.uptimeMillis
                down.consume()
                if (isDouble) {
                    change(0f)
                    waitForUpOrCancellation()
                    return@awaitEachGesture
                }
                upd(down.position)
                drag(down.id) {
                    upd(it.position)
                    it.consume()
                }
            }
        }
    ) {
        val w = size.width
        val h = size.height
        val capH = 11.dp.toPx()
        val capW = 13.dp.toPx()
        val pad = capH / 2f
        val track = h - 2 * pad
        val v = value.coerceIn(-EQ_RANGE_DB, EQ_RANGE_DB)
        val fr = (v + EQ_RANGE_DB) / (2f * EQ_RANGE_DB)
        val y = pad + (1f - fr) * track
        val gx = w * 0.62f
        val ledX = w * 0.18f

        // alur
        drawRoundRect(Color(0xFF020203), Offset(gx - 1.5.dp.toPx(), pad), Size(3.dp.toPx(), track), CornerRadius(1.5.dp.toPx()))
        drawLine(Color(0x55FFFFFF), Offset(gx - 6.dp.toPx(), pad + track / 2f), Offset(gx + 6.dp.toPx(), pad + track / 2f), 1.dp.toPx())

        // 13 LED (tiap 2 dB), menyala dari tengah (0 dB) sampai posisi fader
        for (k in 0..12) {
            val db = (EQ_RANGE_DB - 2f * k)
            val ly = pad + (k / 12f) * track
            val lit = if (v >= 0f) db >= 0f && db <= v + 0.001f else db <= 0f && db >= v - 0.001f
            val on = enabled && lit
            val p = Offset(ledX, ly)
            if (on) drawCircle(RkGreen.copy(alpha = 0.30f), 3.4.dp.toPx(), p)
            drawCircle(
                if (on) RkGreen else if (db == 0f) Color(0xFF2E6B3A) else Color(0xFF16261A),
                1.7.dp.toPx(), p,
            )
        }

        // tutup fader
        val tl = Offset(gx - capW / 2f, y - capH / 2f)
        val sz = Size(capW, capH)
        val cr = CornerRadius(2.dp.toPx())
        drawRoundRect(Color(0x99000000), tl + Offset(1.dp.toPx(), 1.5.dp.toPx()), sz, cr)
        drawRoundRect(Brush.verticalGradient(listOf(Color(0xFF8A8C93), Color(0xFF2F3034)), tl.y, tl.y + capH), tl, sz, cr)
        drawRoundRect(Color(0xFF050506), tl, sz, cr, style = Stroke(1.dp.toPx()))
        drawLine(Color.White, Offset(tl.x + 2.dp.toPx(), y), Offset(tl.x + capW - 2.dp.toPx(), y), 1.4.dp.toPx())
    }
}

// ================================================================== UNIT 3: AMPLIFIER

@Composable
private fun AmpUnit(vm: PlayerViewModel) {
    val ui by vm.ui.collectAsState()
    val s by AudioEngine.settings.collectAsState()
    val (lvL, lvR) = rkStereoLevels(ui.isPlaying, ui.volume)
    val muted = ui.volume <= 0.001f

    Column(
        Modifier.fillMaxWidth().faceplate().padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Box(
                Modifier.size(7.dp).drawBehind {
                    drawCircle(RkRed.copy(alpha = 0.35f), 5.dp.toPx())
                    drawCircle(RkRed, 3.dp.toPx())
                }
            )
            RkLabel("INTEGRATED AMPLIFIER", color = Color.White, size = 10.sp)
        }

        // dua VU meter + knob volume
        Row(
            Modifier.fillMaxWidth().height(104.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            AmberVu("L", rkVuFrac(lvL), Modifier.weight(1f).fillMaxHeight())
            AmberVu("R", rkVuFrac(lvR), Modifier.weight(1f).fillMaxHeight())
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(2.dp)) {
                RkKnob(
                    frac = ui.volume,
                    knobSize = 86.dp,
                    description = if (muted) "Bisu" else "Volume",
                    litFrom = 0f,
                    onTurn = { d -> vm.setVolume(vm.ui.value.volume + d) },
                    onTap = vm::toggleMute,
                )
                RkLabel(if (muted) "MUTE" else "VOLUME", color = if (muted) RkRed else RkSilk, size = 9.sp)
            }
        }

        // bass dan treble: knob + tombol - / + di bawahnya, LED melingkar mengikuti
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            ToneBlock(
                label = "BASS",
                value = s.bassDb,
                onStep = { d -> AudioEngine.update { it.copy(bassDb = (it.bassDb + d).coerceIn(-EqAudioProcessor.TONE_MAX_DB, EqAudioProcessor.TONE_MAX_DB)) } },
                onReset = { AudioEngine.update { it.copy(bassDb = 0) } },
            )
            ToneBlock(
                label = "TREBLE",
                value = s.trebleDb,
                onStep = { d -> AudioEngine.update { it.copy(trebleDb = (it.trebleDb + d).coerceIn(-EqAudioProcessor.TONE_MAX_DB, EqAudioProcessor.TONE_MAX_DB)) } },
                onReset = { AudioEngine.update { it.copy(trebleDb = 0) } },
            )
        }
    }
}

@Composable
private fun ToneBlock(label: String, value: Int, onStep: (Int) -> Unit, onReset: () -> Unit) {
    val max = EqAudioProcessor.TONE_MAX_DB
    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(4.dp)) {
        RkLabel(label, color = Color.White, size = 10.sp)
        RkKnob(
            frac = (value + max) / (2f * max),
            knobSize = 84.dp,
            description = "$label $value dB",
            litFrom = 0.5f,
            onTap = onReset,
        )
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            StepKey("\u2212", { onStep(-1) })
            Box(Modifier.width(40.dp), contentAlignment = Alignment.Center) {
                Digits(if (value > 0) "+$value" else "$value", color = RkAmber, size = 13)
            }
            StepKey("+", { onStep(+1) })
        }
        RkLabel("dB", color = RkDim, size = 8.sp)
    }
}

/** Tombol - / +: sekali tekan = 1 langkah; ditahan = berulang. */
@Composable
private fun StepKey(sign: String, onStep: () -> Unit) {
    val step by rememberUpdatedState(onStep)
    var pressed by remember { mutableStateOf(false) }
    Box(
        Modifier
            .width(44.dp)
            .height(32.dp)
            .drawBehind {
                val r = CornerRadius(4.dp.toPx())
                val top = if (pressed) Color(0xFF111113) else Color(0xFF3B3C41)
                val bot = if (pressed) Color(0xFF1C1D20) else Color(0xFF1A1B1E)
                drawRoundRect(Brush.verticalGradient(listOf(top, bot)), cornerRadius = r)
                drawRoundRect(Color(0xFF050506), cornerRadius = r, style = Stroke(1.dp.toPx()))
                if (!pressed) {
                    drawLine(Color(0x33FFFFFF), Offset(r.x, 1.5.dp.toPx()), Offset(size.width - r.x, 1.5.dp.toPx()), 1.dp.toPx())
                }
            }
            .pointerInput(Unit) {
                detectTapGestures(onPress = {
                    pressed = true
                    step()
                    coroutineScope {
                        val job = launch {
                            delay(450)
                            while (true) {
                                step()
                                delay(110)
                            }
                        }
                        tryAwaitRelease()
                        job.cancel()
                    }
                    pressed = false
                })
            },
        contentAlignment = Alignment.Center,
    ) {
        Text(sign, color = Color.White, fontSize = 18.sp, lineHeight = 18.sp, fontWeight = FontWeight.Bold)
    }
}
