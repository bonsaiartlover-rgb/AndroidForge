package id.sejukjiwa.kilat

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import androidx.core.app.NotificationCompat

/**
 * Layanan latar depan: menjaga proses CromeAja tetap hidup saat aplikasi dibuka di belakang
 * layar / berpindah ke aplikasi lain, sehingga halaman, audio, dan unduhan tetap berjalan.
 */
class KeepAliveService : Service() {

    private var wl: PowerManager.WakeLock? = null
    private val h = Handler(Looper.getMainLooper())
    private val check = object : Runnable {
        override fun run() {
            updateWake()
            h.postDelayed(this, 20000)
        }
    }

    /** CPU dijaga tetap menyala hanya selama ada audio yang diputar (layar mati pun lanjut); selebihnya dilepas agar hemat baterai. */
    private fun updateWake() {
        try {
            val active = (getSystemService(Context.AUDIO_SERVICE) as AudioManager).isMusicActive
            val l = wl ?: (getSystemService(Context.POWER_SERVICE) as PowerManager)
                .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "cromeaja:bg").also { it.setReferenceCounted(false); wl = it }
            if (active) { if (!l.isHeld) l.acquire(60 * 60 * 1000L) } else if (l.isHeld) l.release()
        } catch (e: Exception) {
            // abaikan
        }
    }

    override fun onDestroy() {
        h.removeCallbacks(check)
        try { wl?.let { if (it.isHeld) it.release() } } catch (e: Exception) { /* abaikan */ }
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(
                NotificationChannel(CH, "CromeAja di latar belakang", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val open = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n: Notification = NotificationCompat.Builder(this, CH)
            .setSmallIcon(R.drawable.ic_launcher_mono)
            .setContentTitle("CromeAja")
            .setContentText("Halaman tetap berjalan di latar belakang")
            .setContentIntent(open)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        } else {
            startForeground(ID, n)
        }
        h.removeCallbacks(check)
        h.post(check)
        return START_NOT_STICKY
    }

    companion object {
        private const val CH = "crom_bg"
        private const val ID = 1001
    }
}
