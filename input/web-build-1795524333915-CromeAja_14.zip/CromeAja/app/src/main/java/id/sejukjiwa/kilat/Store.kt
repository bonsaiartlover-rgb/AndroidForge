package id.sejukjiwa.kilat

import android.content.Context
import java.io.File
import org.json.JSONArray
import org.json.JSONObject

data class Entry(var title: String, val url: String, val time: Long)
data class Saved(val title: String, val url: String, val file: String, val time: Long)
data class Engine(val name: String, val search: String, val action: String)

/** Penyimpanan ringan: riwayat, bookmark, pintasan situs, halaman offline, sesi tab, mesin pencari. */
class Store(ctx: Context, load: Boolean = true) {

    companion object {
        val ENGINES = listOf(
            Engine("Google", "https://www.google.com/search?q=", "https://www.google.com/search"),
            Engine("DuckDuckGo", "https://duckduckgo.com/?q=", "https://duckduckgo.com/"),
            Engine("Bing", "https://www.bing.com/search?q=", "https://www.bing.com/search")
        )
        private const val MAX_HISTORY = 1000

        /** Pintasan awal di halaman tab baru. */
        val DEFAULT_SHORTCUTS = listOf(
            "Google" to "https://www.google.com/",
            "YouTube" to "https://m.youtube.com/",
            "Facebook" to "https://m.facebook.com/",
            "Instagram" to "https://www.instagram.com/",
            "X" to "https://x.com/",
            "Wikipedia" to "https://id.wikipedia.org/",
            "Tokopedia" to "https://www.tokopedia.com/",
            "Detik" to "https://www.detik.com/"
        )
    }

    private val app = ctx.applicationContext
    private val p = ctx.getSharedPreferences("kilat", Context.MODE_PRIVATE)
    val history = ArrayList<Entry>()
    val bookmarks = ArrayList<Entry>()
    val shortcuts = ArrayList<Entry>()
    val saved = ArrayList<Saved>()
    private var dirty = false

    var engine: Int
        get() = p.getInt("engine", 0).coerceIn(0, ENGINES.size - 1)
        set(v) { p.edit().putInt("engine", v).apply() }

    init {
        if (load) {
            history.addAll(read("history"))
            bookmarks.addAll(read("bookmarks"))
            if (p.contains("shortcuts")) {
                shortcuts.addAll(read("shortcuts"))
            } else {
                val now = System.currentTimeMillis()
                DEFAULT_SHORTCUTS.forEach { shortcuts.add(Entry(it.first, it.second, now)) }
                dirty = true
                save()
            }
            saved.addAll(readSaved())
        }
    }

    private fun read(key: String): List<Entry> {
        val out = ArrayList<Entry>()
        try {
            val a = JSONArray(p.getString(key, "[]"))
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                out.add(Entry(o.optString("t"), o.getString("u"), o.optLong("d")))
            }
        } catch (e: Exception) {
            // data rusak: abaikan
        }
        return out
    }

    private fun write(list: List<Entry>): String {
        val a = JSONArray()
        for (e in list) a.put(JSONObject().put("t", e.title).put("u", e.url).put("d", e.time))
        return a.toString()
    }

    fun save() {
        if (!dirty) return
        dirty = false
        p.edit()
            .putString("history", write(history))
            .putString("bookmarks", write(bookmarks))
            .putString("shortcuts", write(shortcuts))
            .putString("saved", writeSaved())
            .apply()
    }

    // ---- pintasan situs (thumbnail di tab baru) ----
    fun addShortcut(title: String, url: String) {
        shortcuts.add(Entry(title, url, System.currentTimeMillis()))
        dirty = true
        save()
    }

    fun updateShortcut(i: Int, title: String, url: String) {
        if (i !in shortcuts.indices) return
        shortcuts[i] = Entry(title, url, shortcuts[i].time)
        dirty = true
        save()
    }

    fun removeShortcut(i: Int) {
        if (i in shortcuts.indices) { shortcuts.removeAt(i); dirty = true; save() }
    }

    // ---- halaman tersimpan (baca offline) ----
    fun offlineDir(): File = File(app.filesDir, "offline")

    fun fileOf(s: Saved): File = File(offlineDir(), s.file)

    private fun readSaved(): List<Saved> {
        val out = ArrayList<Saved>()
        try {
            val a = JSONArray(p.getString("saved", "[]"))
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                out.add(Saved(o.optString("t"), o.getString("u"), o.getString("f"), o.optLong("d")))
            }
        } catch (e: Exception) {
            // data rusak: abaikan
        }
        return out
    }

    private fun writeSaved(): String {
        val a = JSONArray()
        for (e in saved) a.put(JSONObject().put("t", e.title).put("u", e.url).put("f", e.file).put("d", e.time))
        return a.toString()
    }

    private fun sameUrl(a: String, b: String) = a.trimEnd('/') == b.trimEnd('/')

    fun findSaved(url: String): Saved? = saved.firstOrNull { sameUrl(it.url, url) }

    /** Menyimpan entri baru; salinan lama untuk URL yang sama diganti. */
    fun addSaved(s: Saved) {
        val iter = saved.iterator()
        while (iter.hasNext()) {
            val o = iter.next()
            if (sameUrl(o.url, s.url)) {
                if (o.file != s.file) fileOf(o).delete()
                iter.remove()
            }
        }
        saved.add(0, s)
        dirty = true
        save()
    }

    fun removeSaved(i: Int) {
        if (i !in saved.indices) return
        fileOf(saved[i]).delete()
        saved.removeAt(i)
        dirty = true
        save()
    }

    // ---- riwayat ----
    fun addHistory(title: String, url: String) {
        val first = history.firstOrNull()
        if (first != null && first.url == url) {
            if (title.isNotEmpty()) first.title = title
        } else {
            history.add(0, Entry(title, url, System.currentTimeMillis()))
            while (history.size > MAX_HISTORY) history.removeAt(history.size - 1)
        }
        dirty = true
    }

    fun setTitle(url: String?, title: String?) {
        if (url == null || title.isNullOrEmpty()) return
        val e = history.firstOrNull { it.url == url } ?: return
        if (e.title != title) {
            e.title = title
            dirty = true
        }
    }

    fun removeHistory(i: Int) {
        if (i in history.indices) { history.removeAt(i); dirty = true; save() }
    }

    fun clearHistory() {
        history.clear()
        dirty = true
        save()
    }

    // ---- bookmark ----
    fun hasBookmark(url: String) = bookmarks.any { it.url == url }

    /** @return true bila ditambahkan, false bila dihapus */
    fun toggleBookmark(title: String, url: String): Boolean {
        val i = bookmarks.indexOfFirst { it.url == url }
        val added = i < 0
        if (added) bookmarks.add(0, Entry(title, url, System.currentTimeMillis()))
        else bookmarks.removeAt(i)
        dirty = true
        save()
        return added
    }

    fun removeBookmark(i: Int) {
        if (i in bookmarks.indices) { bookmarks.removeAt(i); dirty = true; save() }
    }

    // ---- sesi tab ----
    fun saveSession(urls: List<String>, cur: Int) {
        val a = JSONArray()
        urls.forEach { a.put(it) }
        p.edit().putString("session", a.toString()).putInt("sessionCur", cur).apply()
    }

    fun loadSession(): Pair<List<String>, Int> {
        val urls = ArrayList<String>()
        try {
            val a = JSONArray(p.getString("session", "[]"))
            for (i in 0 until a.length()) urls.add(a.getString(i))
        } catch (e: Exception) {
            urls.clear()
        }
        return Pair(urls, p.getInt("sessionCur", 0))
    }
}
