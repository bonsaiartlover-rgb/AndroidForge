package id.sejukjiwa.kilat

import android.app.DownloadManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.MediaStore
import android.webkit.CookieManager
import android.webkit.MimeTypeMap
import androidx.core.app.NotificationCompat
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.io.RandomAccessFile
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicReference

/** Satu unduhan. Semua perubahan status terjadi di thread utama; thread unduh hanya menulis [done]/[total]. */
class DlItem(
    val id: Long,
    var name: String,
    val url: String,
    val ua: String?,
    var mime: String?,
    var state: Int,
    @Volatile var done: Long,
    @Volatile var total: Long,
    var time: Long
) {
    @Volatile var gen = 0          // naik tiap mulai/jeda/batal; thread lama berhenti jika tidak cocok
    @Volatile var speed = 0L       // byte per detik (dihaluskan)
    var error: String? = null
    var uri: String? = null        // lokasi hasil akhir (content://)
    var lastDone = 0L
    var lastTick = 0L
    var thread: Thread? = null
    var segPos: LongArray? = null  // unduhan bertahap: posisi byte berikutnya tiap potongan
    var segEnd: LongArray? = null  // byte terakhir (inklusif) tiap potongan

    val running get() = state == DlManager.RUNNING
    val active get() = state == DlManager.RUNNING || state == DlManager.PAUSED
}

/**
 * Mesin unduhan sendiri (HttpURLConnection + header Range) agar bisa dijeda, dilanjutkan, dan
 * menampilkan kecepatan. Data ditulis ke file sementara lalu dipindah ke folder Unduhan.
 */
class DlManager private constructor(private val app: Context, private val persist: Boolean) {

    val items = ArrayList<DlItem>()              // terbaru di atas
    var onChange: (() -> Unit)? = null
    var onFinished: ((DlItem) -> Unit)? = null

    private val ui = Handler(Looper.getMainLooper())
    private val partDir = File(app.getExternalFilesDir(null) ?: app.filesDir, if (persist) "parts" else "parts_private")
    private var ticking = false
    private var channelMade = false

    init {
        if (!persist) partDir.deleteRecursively()
        partDir.mkdirs()
        if (persist) load()
    }

    // ------------------------------------------------------------ aksi (thread utama)

    fun add(url: String, ua: String?, mime: String?, name: String): DlItem {
        val d = DlItem(newId(), name, url, ua, mime, RUNNING, 0L, -1L, System.currentTimeMillis())
        items.add(0, d)
        trim()
        start(d)
        return d
    }

    fun pause(d: DlItem) {
        if (d.state != RUNNING) return
        d.gen++                       // thread lama berhenti pada iterasi berikutnya
        d.state = PAUSED
        d.speed = 0
        changed(true)
    }

    fun resume(d: DlItem) {
        if (d.state != PAUSED && d.state != FAILED) return
        d.error = null
        d.state = RUNNING
        start(d)
    }

    /** Batalkan unduhan yang berjalan/dijeda: file sementara dihapus dan dikeluarkan dari daftar. */
    fun cancel(d: DlItem) {
        d.gen++
        val old = d.thread
        d.state = FAILED
        items.remove(d)
        cancelNotification(d)
        Thread {
            try { old?.join(3000) } catch (e: InterruptedException) { /* abaikan */ }
            part(d).delete()
        }.start()
        changed(true)
    }

    /** Hapus dari riwayat (file hasil unduhan tidak dihapus). */
    fun remove(d: DlItem) {
        if (d.active) { cancel(d); return }
        if (d.state == FAILED) part(d).delete()
        items.remove(d)
        cancelNotification(d)
        changed(true)
    }

    fun clearFinished() {
        val gone = items.filter { !it.active }
        for (d in gone) { if (d.state == FAILED) part(d).delete(); cancelNotification(d) }
        items.removeAll(gone.toSet())
        changed(true)
    }

    // ------------------------------------------------------------ internal

    private fun newId(): Long {
        var id = System.currentTimeMillis()
        while (items.any { it.id == id }) id++
        return id
    }

    private fun part(d: DlItem) = File(partDir, "${d.id}.part")

    private fun start(d: DlItem) {
        val gen = ++d.gen
        val prev = d.thread
        d.speed = 0
        d.lastTick = 0
        val t = Thread { work(d, gen, prev) }
        d.thread = t
        t.start()
        changed(true)
        ensureTick()
    }

    private fun trim() {
        while (items.size > 500) {
            val i = items.indexOfLast { !it.active }
            if (i < 0) break
            items.removeAt(i)
        }
    }

    private fun changed(save: Boolean) {
        if (save) save()
        onChange?.invoke()
    }

    private fun ensureTick() {
        if (!ticking) {
            ticking = true
            ui.postDelayed(tick, 500)
        }
    }

    private val tick: Runnable = object : Runnable {
        override fun run() {
            val now = SystemClock.elapsedRealtime()
            var any = false
            for (d in items) {
                if (d.state == RUNNING) {
                    any = true
                    if (d.lastTick != 0L && now > d.lastTick) {
                        val inst = (d.done - d.lastDone) * 1000L / (now - d.lastTick)
                        d.speed = if (d.speed == 0L) inst else (d.speed * 0.6 + inst * 0.4).toLong()
                    }
                    d.lastDone = d.done
                    d.lastTick = now
                    notifyItem(d)
                }
            }
            ticking = false
            onChange?.invoke()
            if (any) {
                ticking = true
                ui.postDelayed(this, 500)
            }
        }
    }

    // ------------------------------------------------------------ thread unduh

    private class NoRange : IOException("Server tidak mendukung unduhan bertahap")
    private class Changed : IOException("Berkas di server berubah, coba lagi")

    private fun work(d: DlItem, gen: Int, prev: Thread?) {
        try { prev?.join() } catch (e: InterruptedException) { return }
        if (d.gen != gen) return
        try {
            val part = part(d)
            if (!fetch(d, gen, part)) return
            if (d.gen != gen) return
            d.segPos = null
            d.segEnd = null
            d.total = d.done
            val uri = publish(d, part)
            ui.post { if (d.gen == gen) finish(d, uri, null) }
        } catch (e: Exception) {
            if (e is Changed && d.gen == gen) resetSegs(d, part(d))
            if (d.gen == gen) ui.post { if (d.gen == gen) finish(d, null, e.message ?: "Kesalahan jaringan") }
        }
    }

    /** true = berkas lengkap di [part]; false = dijeda/dibatalkan. */
    private fun fetch(d: DlItem, gen: Int, part: File): Boolean {
        if (d.segPos != null) {
            if (part.exists()) {
                try { return runSegments(d, gen, part) } catch (e: NoRange) { resetSegs(d, part) }
            } else resetSegs(d, part)
        }
        return single(d, gen, part, true)
    }

    /** Unduhan satu koneksi. Bila server mendukung Range dan berkas cukup besar, beralih ke unduhan bertahap (multi koneksi). */
    private fun single(d: DlItem, gen: Int, part: File, allowSeg: Boolean): Boolean {
        var conn: HttpURLConnection? = null
        try {
            var start = if (part.exists()) part.length() else 0L
            val fresh = start == 0L
            val c = connect(d, start, -1L, fresh)
            conn = c
            val code = c.responseCode
            if (code == 416) { part.delete(); throw IOException("Berkas berubah, coba lagi") }
            if (code == 200 && start > 0) { start = 0; part.delete() }
            else if (code != 200 && code != 206) throw IOException("Server menjawab $code")
            val len = c.contentLengthLong
            val total = if (code == 206) {
                c.getHeaderField("Content-Range")?.substringAfterLast('/')?.trim()?.toLongOrNull()
                    ?: (if (len > 0) start + len else -1L)
            } else if (len > 0) len else -1L
            if (d.mime.isNullOrEmpty()) d.mime = c.contentType?.substringBefore(';')?.trim()
            if (allowSeg && fresh && code == 206 && total >= SEG_MIN) {
                c.disconnect()
                d.total = total
                d.done = 0
                makeSegs(d, part, total)
                try { return runSegments(d, gen, part) } catch (e: NoRange) { resetSegs(d, part) }
                return single(d, gen, part, false)
            }
            d.total = total
            d.done = start
            val buf = ByteArray(32 * 1024)
            c.inputStream.use { inp ->
                FileOutputStream(part, start > 0).use { out ->
                    while (true) {
                        if (d.gen != gen) return false
                        val n = inp.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        d.done += n
                    }
                }
            }
            if (d.gen != gen) return false
            if (d.total > 0 && d.done < d.total) throw IOException("Koneksi terputus")
            d.total = d.done
            return true
        } finally {
            try { conn?.disconnect() } catch (e: Exception) { /* abaikan */ }
        }
    }

    private fun makeSegs(d: DlItem, part: File, total: Long) {
        val n = ((total + SEG_CHUNK - 1) / SEG_CHUNK).toInt().coerceIn(2, 48)
        val size = (total + n - 1) / n
        val pos = LongArray(n)
        val end = LongArray(n)
        for (i in 0 until n) {
            pos[i] = i * size
            end[i] = minOf(total - 1, (i + 1) * size - 1)
        }
        RandomAccessFile(part, "rw").use { it.setLength(total) }
        d.segPos = pos
        d.segEnd = end
    }

    private fun resetSegs(d: DlItem, part: File) {
        d.segPos = null
        d.segEnd = null
        d.done = 0
        part.delete()
    }

    private fun segDone(d: DlItem): Long {
        val p = d.segPos ?: return d.done
        val e = d.segEnd ?: return d.done
        var rem = 0L
        for (i in p.indices) if (p[i] <= e[i]) rem += e[i] + 1 - p[i]
        return (d.total - rem).coerceAtLeast(0L)
    }

    /** Mengunduh potongan-potongan berkas secara paralel (gaya IDM). true = semua potongan selesai. */
    private fun runSegments(d: DlItem, gen: Int, part: File): Boolean {
        val pos = d.segPos ?: throw IOException("Data bagian hilang")
        val end = d.segEnd ?: throw IOException("Data bagian hilang")
        val n = pos.size
        d.done = segDone(d)
        val next = AtomicInteger(0)
        val err = AtomicReference<Exception?>(null)
        val workers = ArrayList<Thread>()
        for (k in 0 until minOf(THREADS, n)) {
            val t = Thread {
                while (d.gen == gen && err.get() == null) {
                    val i = next.getAndIncrement()
                    if (i >= n) break
                    if (pos[i] > end[i]) continue
                    try {
                        chunk(d, gen, part, pos, end, i, err)
                    } catch (e: Exception) {
                        err.compareAndSet(null, e)
                    }
                }
            }
            workers.add(t)
            t.start()
        }
        for (t in workers) {
            try { t.join() } catch (e: InterruptedException) { return false }
        }
        if (d.gen != gen) return false
        val e = err.get()
        if (e != null) throw e
        for (i in 0 until n) if (pos[i] <= end[i]) throw IOException("Koneksi terputus")
        d.done = d.total
        return true
    }

    private fun chunk(d: DlItem, gen: Int, part: File, pos: LongArray, end: LongArray, i: Int, err: AtomicReference<Exception?>) {
        var tries = 0
        val buf = ByteArray(32 * 1024)
        while (d.gen == gen && err.get() == null && pos[i] <= end[i]) {
            var conn: HttpURLConnection? = null
            try {
                val c = connect(d, pos[i], end[i], true)
                conn = c
                val code = c.responseCode
                if (code != 206) {
                    if (code == 200 || (d.done == 0L && (code == 403 || code == 429 || code == 503))) throw NoRange()
                    throw IOException("Server menjawab $code")
                }
                val rt = c.getHeaderField("Content-Range")?.substringAfterLast('/')?.trim()?.toLongOrNull()
                if (rt != null && d.total > 0 && rt != d.total) throw Changed()
                RandomAccessFile(part, "rw").use { raf ->
                    raf.seek(pos[i])
                    c.inputStream.use { inp ->
                        while (d.gen == gen && pos[i] <= end[i]) {
                            val want = minOf(buf.size.toLong(), end[i] - pos[i] + 1).toInt()
                            val r = inp.read(buf, 0, want)
                            if (r < 0) break
                            raf.write(buf, 0, r)
                            pos[i] += r.toLong()
                            synchronized(d) { d.done += r }
                        }
                    }
                }
                if (d.gen != gen) return
                if (pos[i] <= end[i]) throw IOException("Koneksi terputus")
            } catch (e: NoRange) {
                throw e
            } catch (e: Changed) {
                throw e
            } catch (e: Exception) {
                if (d.gen != gen) return
                tries++
                if (tries > 5) throw e
                try { Thread.sleep(600L * tries) } catch (x: InterruptedException) { return }
            } finally {
                try { conn?.disconnect() } catch (x: Exception) { /* abaikan */ }
            }
        }
    }

    /**
     * Membuka koneksi dan mengikuti pengalihan (redirect) secara manual. Cookie diambil dari WebView
     * untuk tiap host sendiri-sendiri, sehingga cookie sesi situs asal (mis. login GitHub) tidak ikut
     * terkirim ke host tujuan (mis. penyimpanan file bertanda tangan) yang bisa menolaknya.
     */
    private fun connect(d: DlItem, start: Long, end: Long = -1L, ranged: Boolean = false): HttpURLConnection {
        var url = d.url
        for (hop in 0..8) {
            if (!url.startsWith("http")) throw IOException("Alamat tidak didukung")
            val c = URL(url).openConnection() as HttpURLConnection
            c.connectTimeout = 15000
            c.readTimeout = 20000
            c.instanceFollowRedirects = false
            c.setRequestProperty("Accept-Encoding", "identity")
            if (!d.ua.isNullOrEmpty()) c.setRequestProperty("User-Agent", d.ua)
            val cookie = try { CookieManager.getInstance().getCookie(url) } catch (e: Exception) { null }
            if (!cookie.isNullOrEmpty()) c.setRequestProperty("Cookie", cookie)
            if (end >= 0) c.setRequestProperty("Range", "bytes=$start-$end")
            else if (start > 0 || ranged) c.setRequestProperty("Range", "bytes=$start-")
            val code = c.responseCode
            if (code == 301 || code == 302 || code == 303 || code == 307 || code == 308) {
                val loc = c.getHeaderField("Location")
                c.disconnect()
                if (loc.isNullOrEmpty()) throw IOException("Pengalihan tanpa tujuan")
                url = URL(URL(url), loc).toString()
                continue
            }
            return c
        }
        throw IOException("Terlalu banyak pengalihan")
    }

    private fun finish(d: DlItem, uri: String?, error: String?) {
        d.speed = 0
        d.time = System.currentTimeMillis()
        if (error == null) {
            d.state = DONE
            d.uri = uri
        } else {
            d.state = FAILED
            d.error = error
        }
        notifyItem(d)
        changed(true)
        onFinished?.invoke(d)
    }

    /** Memindahkan file sementara ke folder Unduhan publik. Mengembalikan content:// atau null. */
    private fun publish(d: DlItem, part: File): String? {
        val mime = d.mime?.takeIf { it.isNotEmpty() && it != "application/octet-stream" }
            ?: MimeTypeMap.getSingleton().getMimeTypeFromExtension(d.name.substringAfterLast('.', "").lowercase())
            ?: "application/octet-stream"
        if (Build.VERSION.SDK_INT >= 29) {
            val r = app.contentResolver
            val cv = ContentValues()
            cv.put(MediaStore.MediaColumns.DISPLAY_NAME, d.name)
            cv.put(MediaStore.MediaColumns.MIME_TYPE, mime)
            cv.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
            cv.put(MediaStore.MediaColumns.IS_PENDING, 1)
            val uri = r.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv)
                ?: throw IOException("Tidak bisa menyimpan ke folder Unduhan")
            try {
                val out = r.openOutputStream(uri) ?: throw IOException("Tidak bisa menulis file")
                out.use { o -> part.inputStream().use { it.copyTo(o, 64 * 1024) } }
            } catch (e: Exception) {
                try { r.delete(uri, null, null) } catch (x: Exception) { /* abaikan */ }
                throw e
            }
            val done = ContentValues()
            done.put(MediaStore.MediaColumns.IS_PENDING, 0)
            r.update(uri, done, null, null)
            try {
                r.query(uri, arrayOf(MediaStore.MediaColumns.DISPLAY_NAME), null, null, null)?.use {
                    if (it.moveToFirst()) d.name = it.getString(0) ?: d.name
                }
            } catch (e: Exception) { /* abaikan */ }
            part.delete()
            return uri.toString()
        }
        val dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
        dir.mkdirs()
        var target = File(dir, d.name)
        if (target.exists()) {
            val dot = d.name.lastIndexOf('.')
            val base = if (dot > 0) d.name.substring(0, dot) else d.name
            val ext = if (dot > 0) d.name.substring(dot) else ""
            var i = 1
            while (File(dir, "$base ($i)$ext").exists() && i < 999) i++
            target = File(dir, "$base ($i)$ext")
        }
        if (!part.renameTo(target)) {
            part.copyTo(target, true)
            part.delete()
        }
        d.name = target.name
        try {
            @Suppress("DEPRECATION")
            val id = (app.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager)
                .addCompletedDownload(target.name, target.name, true, mime, target.absolutePath, target.length(), false)
            return (app.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager)
                .getUriForDownloadedFile(id)?.toString()
        } catch (e: Exception) {
            MediaScannerConnection.scanFile(app, arrayOf(target.path), null, null)
            return null
        }
    }

    // ------------------------------------------------------------ notifikasi

    private fun nid(d: DlItem) = 2000 + (d.id % 100000L).toInt()

    private fun cancelNotification(d: DlItem) {
        try { (app.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).cancel(nid(d)) } catch (e: Exception) { /* abaikan */ }
    }

    private fun notifyItem(d: DlItem) {
        try {
            val nm = app.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (Build.VERSION.SDK_INT >= 26 && !channelMade) {
                nm.createNotificationChannel(NotificationChannel(CH, "Unduhan", NotificationManager.IMPORTANCE_LOW))
                channelMade = true
            }
            val b = NotificationCompat.Builder(app, CH)
                .setSmallIcon(R.drawable.ic_launcher_mono)
                .setContentTitle(if (persist) d.name else "Unduhan pribadi")
                .setOnlyAlertOnce(true)
            val pct = if (d.total > 0) (d.done * 100 / d.total).toInt().coerceIn(0, 100) else 0
            when (d.state) {
                RUNNING -> b.setOngoing(true).setProgress(100, pct, d.total <= 0)
                    .setContentText(if (d.total > 0) "$pct% · ${speedText(d.speed)}" else speedText(d.speed))
                DONE -> {
                    b.setContentText("Unduhan selesai").setAutoCancel(true)
                    val u = d.uri
                    if (u != null && persist) {
                        val i = Intent(Intent.ACTION_VIEW).setDataAndType(Uri.parse(u), d.mime ?: "*/*")
                            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
                        b.setContentIntent(PendingIntent.getActivity(app, nid(d), i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT))
                    }
                }
                FAILED -> b.setContentText("Unduhan gagal").setAutoCancel(true)
                else -> return
            }
            nm.notify(nid(d), b.build())
        } catch (e: Exception) {
            // izin notifikasi ditolak: abaikan
        }
    }

    private fun speedText(bps: Long): String =
        if (bps <= 0) "…" else android.text.format.Formatter.formatShortFileSize(app, bps) + "/dtk"

    // ------------------------------------------------------------ simpan / muat

    private fun prefs() = app.getSharedPreferences("crom_dl2", Context.MODE_PRIVATE)

    private fun save() {
        if (!persist) return
        val arr = JSONArray()
        for (d in items) {
            val o = JSONObject().put("id", d.id).put("name", d.name).put("url", d.url).put("ua", d.ua ?: "")
                .put("mime", d.mime ?: "").put("state", d.state).put("total", d.total).put("done", d.done)
                .put("time", d.time).put("uri", d.uri ?: "")
            val sp = d.segPos
            val se = d.segEnd
            if (sp != null && se != null && d.state != DONE) {
                val a1 = JSONArray()
                val a2 = JSONArray()
                for (v in sp) a1.put(v)
                for (v in se) a2.put(v)
                o.put("sp", a1).put("se", a2)
            }
            arr.put(o)
        }
        prefs().edit().putString("items", arr.toString()).apply()
    }

    private fun load() {
        try {
            val arr = JSONArray(prefs().getString("items", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                var st = o.getInt("state")
                val d = DlItem(o.getLong("id"), o.getString("name"), o.getString("url"),
                    o.optString("ua").ifEmpty { null }, o.optString("mime").ifEmpty { null },
                    st, o.optLong("done"), o.optLong("total", -1L), o.optLong("time"))
                d.uri = o.optString("uri").ifEmpty { null }
                val sa = o.optJSONArray("sp")
                val ea = o.optJSONArray("se")
                if (sa != null && ea != null && sa.length() > 0 && sa.length() == ea.length()) {
                    d.segPos = LongArray(sa.length()) { sa.getLong(it) }
                    d.segEnd = LongArray(ea.length()) { ea.getLong(it) }
                }
                if (st == RUNNING || st == PAUSED) {
                    // proses sempat mati: tampilkan sebagai dijeda, lanjut dari file sementara
                    val p = part(d)
                    if (p.exists()) { d.state = PAUSED; d.done = if (d.segPos != null) segDone(d) else p.length() } else { d.state = FAILED; d.error = "File sementara hilang" }
                }
                items.add(d)
            }
        } catch (e: Exception) {
            items.clear()
        }
    }

    companion object {
        private const val THREADS = 8                    // koneksi paralel per unduhan
        private const val SEG_MIN = 2L * 1024 * 1024     // di bawah ini: satu koneksi saja
        private const val SEG_CHUNK = 1L * 1024 * 1024   // ukuran target potongan
        const val RUNNING = 1
        const val PAUSED = 2
        const val DONE = 3
        const val FAILED = 4
        private const val CH = "crom_dl"
        private var inst: DlManager? = null

        @Synchronized
        fun get(ctx: Context, persist: Boolean): DlManager =
            inst ?: DlManager(ctx.applicationContext, persist).also { inst = it }
    }
}
