package id.sejukjiwa.microscope

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.VelocityTracker
import android.view.View
import android.view.animation.DecelerateInterpolator
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/** Roda zoom vertikal ramping: geser ke atas = zoom in, ke bawah = zoom out. */
class ZoomRoller @JvmOverloads constructor(ctx: Context, attrs: AttributeSet? = null) :
    View(ctx, attrs) {

    var minValue = 1f
    var maxValue = 25f
    var onChange: ((Float) -> Unit)? = null
    var value = 1f
        set(v) {
            field = v.coerceIn(minValue, maxValue)
            invalidate()
        }

    private val dp = resources.displayMetrics.density
    private val sp = resources.displayMetrics.scaledDensity
    private val ppu = 16f * dp                         // piksel per 1x (kecil = zoom lebih cepat)
    private val thetaMax = (Math.PI / 2 * 0.92).toFloat()

    private val bgP = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#66101820") }
    private val edgeP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#442DE2C9"); style = Paint.Style.STROKE; strokeWidth = 1f * dp
    }
    private val tickP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; strokeCap = Paint.Cap.ROUND
    }
    private val labelP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textAlign = Paint.Align.RIGHT
    }
    private val accentP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#2DE2C9"); strokeCap = Paint.Cap.ROUND
    }
    private val path = Path()

    private var lastY = 0f
    private var vt: VelocityTracker? = null
    private var anim: ValueAnimator? = null

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        c.drawRoundRect(0f, 0f, w, h, w / 2, w / 2, bgP)
        c.drawRoundRect(0.5f * dp, 0.5f * dp, w - 0.5f * dp, h - 0.5f * dp, w / 2, w / 2, edgeP)

        val cy = h / 2
        val half = h / 2 - 16 * dp
        val r = half / thetaMax
        val sinMax = sin(thetaMax)
        val span = half / ppu
        val lo = max(minValue, value - span)
        val hi = min(maxValue, value + span)
        var i = ceil(lo * 2 - 0.001f).toInt()
        val end = floor(hi * 2 + 0.001f).toInt()
        val x2 = w - 8 * dp

        while (i <= end) {
            val v = i / 2f
            val th = (v - value) * ppu / r
            val k = max(0f, cos(th))
            val y = cy - half * sin(th) / sinMax
            val whole = i % 2 == 0
            val n = i / 2
            val major = whole && (n % 5 == 0 || n == 1)
            val len = (if (major) 14 else if (whole) 10 else 6) * dp * (0.45f + 0.55f * k)
            tickP.strokeWidth = (if (major) 2f else 1.2f) * dp
            tickP.alpha = (255 * k * k).toInt().coerceIn(0, 255)
            c.drawLine(x2 - len, y, x2, y, tickP)
            if (major) {
                labelP.alpha = (255 * k * k).toInt().coerceIn(0, 255)
                labelP.textSize = 10 * sp * (0.6f + 0.4f * k)
                c.drawText("$n", x2 - len - 3 * dp, y + labelP.textSize / 3, labelP)
            }
            i++
        }

        // penanda tengah
        accentP.strokeWidth = 2.5f * dp
        c.drawLine(8 * dp, cy, w - 4 * dp, cy, accentP)
        path.reset()
        path.moveTo(1 * dp, cy - 5 * dp)
        path.lineTo(8 * dp, cy)
        path.lineTo(1 * dp, cy + 5 * dp)
        path.close()
        c.drawPath(path, accentP)
    }

    private fun move(nv: Float) {
        val x = nv.coerceIn(minValue, maxValue)
        if (x != value) {
            value = x
            onChange?.invoke(x)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                anim?.cancel()
                lastY = e.y
                vt?.recycle()
                vt = VelocityTracker.obtain().also { it.addMovement(e) }
                parent?.requestDisallowInterceptTouchEvent(true)
            }
            MotionEvent.ACTION_MOVE -> {
                vt?.addMovement(e)
                val dy = e.y - lastY
                lastY = e.y
                move(value - dy / ppu)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                vt?.addMovement(e)
                vt?.computeCurrentVelocity(1000)
                val vy = vt?.yVelocity ?: 0f
                vt?.recycle()
                vt = null
                if (e.actionMasked == MotionEvent.ACTION_UP) fling(vy)
            }
        }
        return true
    }

    private fun fling(vy: Float) {
        val target = (value - vy * 0.12f / ppu).coerceIn(minValue, maxValue)
        if (kotlin.math.abs(target - value) < 0.05f) return
        anim = ValueAnimator.ofFloat(value, target).apply {
            duration = 550
            interpolator = DecelerateInterpolator(2f)
            addUpdateListener { move(it.animatedValue as Float) }
            start()
        }
    }
}
