package id.sejukjiwa.microscope

import android.Manifest
import android.content.ContentValues
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.util.LruCache
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.GridView
import android.widget.ImageView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.AspectRatio
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

class MainActivity : AppCompatActivity() {

    private lateinit var root: FrameLayout
    private lateinit var previewBox: FrameLayout
    private lateinit var previewView: PreviewView
    private lateinit var roller: ZoomRoller
    private lateinit var txtZoom: TextView
    private lateinit var seekBright: SeekBar
    private lateinit var txtBright: TextView
    private lateinit var btnFlash: TextView
    private lateinit var btnLock: TextView
    private lateinit var btnFolder: TextView
    private lateinit var btnShot: View
    private lateinit var focusRing: View
    private lateinit var txtHold: TextView
    private lateinit var tabCam: TextView
    private lateinit var tabGal: TextView
    private lateinit var galleryLayer: View
    private lateinit var grid: GridView
    private lateinit var txtEmpty: TextView
    private lateinit var viewer: View
    private lateinit var viewerImg: ZoomImageView

    private var camera: Camera? = null
    private var imageCapture: ImageCapture? = null
    private var hwMax = 1f      // zoom maksimum kamera (hardware)
    private var zoom = 1f       // total zoom 1..20
    private var extra = 1f      // sisa zoom digital di atas hwMax
    private var lastHw = 0f
    private var torchOn = false
    private var focusLocked = false
    private var shooting = false
    private var lastPt: Pair<Float, Float>? = null
    private val ui = Handler(Looper.getMainLooper())
    private var photos: List<Uri> = emptyList()
    private val thumbIo = Executors.newFixedThreadPool(3)
    private val thumbs = object : LruCache<String, Bitmap>(
        (Runtime.getRuntime().maxMemory() / 8).toInt().coerceAtLeast(4 shl 20)
    ) {
        override fun sizeOf(k: String, v: Bitmap) = v.byteCount
    }
    private val backCb = object : OnBackPressedCallback(false) {
        override fun handleOnBackPressed() {
            if (viewer.visibility == View.VISIBLE) closeViewer() else showTab(false)
        }
    }
    private val io = Executors.newSingleThreadExecutor()
    private val prefs by lazy { getSharedPreferences("mic", MODE_PRIVATE) }

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            if (hasPerms()) startCamera()
            else Toast.makeText(this, "Izin kamera diperlukan", Toast.LENGTH_LONG).show()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        root = findViewById(R.id.root)
        previewBox = findViewById(R.id.previewBox)
        previewView = findViewById(R.id.preview)
        previewView.implementationMode = PreviewView.ImplementationMode.COMPATIBLE
        previewView.scaleType = PreviewView.ScaleType.FIT_CENTER
        roller = findViewById(R.id.roller)
        txtZoom = findViewById(R.id.txtZoom)
        seekBright = findViewById(R.id.seekBright)
        txtBright = findViewById(R.id.txtBright)
        btnFlash = findViewById(R.id.btnFlash)
        btnLock = findViewById(R.id.btnLock)
        btnFolder = findViewById(R.id.btnFolder)
        btnShot = findViewById(R.id.btnShot)
        focusRing = findViewById(R.id.focusRing)
        txtHold = findViewById(R.id.txtHold)
        tabCam = findViewById(R.id.tabCam)
        tabGal = findViewById(R.id.tabGal)
        galleryLayer = findViewById(R.id.galleryLayer)
        grid = findViewById(R.id.grid)
        txtEmpty = findViewById(R.id.txtEmpty)
        viewer = findViewById(R.id.viewer)
        viewerImg = findViewById(R.id.viewerImg)
        onBackPressedDispatcher.addCallback(this, backCb)
        tabCam.isSelected = true
        tabCam.setOnClickListener { showTab(false) }
        tabGal.setOnClickListener { showTab(true) }
        findViewById<View>(R.id.btnClose).setOnClickListener { closeViewer() }
        grid.adapter = galleryAdapter
        grid.setOnItemClickListener { _, _, pos, _ -> openViewer(photos[pos]) }

        roller.value = 1f
        roller.onChange = { z ->
            zoom = z
            applyZoom()
        }

        seekBright.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, user: Boolean) {
                txtBright.text = "$p%"
                val r = camera?.cameraInfo?.exposureState?.exposureCompensationRange ?: return
                val idx = r.lower + ((r.upper - r.lower) * p / 100f).toInt()
                camera?.cameraControl?.setExposureCompensationIndex(idx)
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })

        btnFlash.setOnClickListener {
            torchOn = !torchOn
            camera?.cameraControl?.enableTorch(torchOn)
            btnFlash.isSelected = torchOn
        }
        btnShot.setOnClickListener { onShutter() }
        btnFolder.setOnClickListener { askFolder() }
        btnLock.setOnClickListener { toggleFocusLock() }

        // ketuk layar = fokus di titik itu
        val dens = resources.displayMetrics.density
        var downX = 0f
        var downY = 0f
        var downT = 0L
        previewView.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { downX = e.x; downY = e.y; downT = e.eventTime }
                MotionEvent.ACTION_UP -> {
                    if (abs(e.x - downX) < 24 * dens && abs(e.y - downY) < 24 * dens &&
                        e.eventTime - downT < 400
                    ) {
                        focusAt(e.x, e.y, e.rawX, e.rawY)
                        v.performClick()
                    }
                }
            }
            true
        }

        if (hasPerms()) startCamera() else permLauncher.launch(neededPerms())
    }

    private fun neededPerms(): Array<String> =
        if (Build.VERSION.SDK_INT <= 28)
            arrayOf(
                Manifest.permission.CAMERA,
                Manifest.permission.WRITE_EXTERNAL_STORAGE,
                Manifest.permission.READ_EXTERNAL_STORAGE
            )
        else arrayOf(Manifest.permission.CAMERA)

    private fun hasPerms() = neededPerms().all {
        ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED
    }

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            val provider = future.get()
            val preview = Preview.Builder()
                .setTargetAspectRatio(AspectRatio.RATIO_4_3).build()
                .also { it.setSurfaceProvider(previewView.surfaceProvider) }
            imageCapture = ImageCapture.Builder()
                .setTargetAspectRatio(AspectRatio.RATIO_4_3)
                .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
                .build()
            provider.unbindAll()
            val cam = try {
                provider.bindToLifecycle(
                    this, CameraSelector.DEFAULT_BACK_CAMERA, preview, imageCapture
                )
            } catch (e: Exception) {
                Toast.makeText(this, "Kamera gagal: ${e.message}", Toast.LENGTH_LONG).show()
                return@addListener
            }
            camera = cam
            cam.cameraInfo.zoomState.observe(this) {
                val m = max(1f, it.maxZoomRatio)
                if (m != hwMax) {
                    hwMax = m
                    applyZoom()
                }
            }
            val hasFlash = cam.cameraInfo.hasFlashUnit()
            btnFlash.isEnabled = hasFlash
            btnFlash.alpha = if (hasFlash) 1f else 0.35f
            val r = cam.cameraInfo.exposureState.exposureCompensationRange
            if (r.upper == r.lower) {
                seekBright.isEnabled = false
                seekBright.alpha = 0.4f
                txtBright.text = "-"
            } else {
                val p = ((0 - r.lower) * 100f / (r.upper - r.lower)).toInt()
                seekBright.progress = p
                txtBright.text = "$p%"
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun applyZoom() {
        val hw = min(zoom, hwMax)
        if (hw != lastHw) {
            lastHw = hw
            camera?.cameraControl?.setZoomRatio(hw)
        }
        extra = zoom / hw
        previewView.scaleX = extra
        previewView.scaleY = extra
        txtZoom.text = String.format(Locale.US, "%.1fx", zoom)
    }

    // ---------- fokus ----------
    private fun focusAt(x: Float, y: Float, rawX: Float, rawY: Float) {
        lastPt = Pair(x, y)
        val cam = camera ?: return
        try {
            val pt = previewView.meteringPointFactory.createPoint(x, y)
            val b = FocusMeteringAction.Builder(
                pt, FocusMeteringAction.FLAG_AF or FocusMeteringAction.FLAG_AE
            )
            if (focusLocked) b.disableAutoCancel() else b.setAutoCancelDuration(4, TimeUnit.SECONDS)
            cam.cameraControl.startFocusAndMetering(b.build())
        } catch (e: Exception) {
            // kamera tidak mendukung area fokus; abaikan
        }
        showRing(rawX, rawY)
    }

    private fun showRing(rawX: Float, rawY: Float) {
        val loc = IntArray(2)
        root.getLocationOnScreen(loc)
        focusRing.animate().cancel()
        focusRing.x = rawX - loc[0] - focusRing.width / 2f
        focusRing.y = rawY - loc[1] - focusRing.height / 2f
        focusRing.isSelected = focusLocked
        focusRing.visibility = View.VISIBLE
        focusRing.alpha = 1f
        focusRing.scaleX = 1.5f
        focusRing.scaleY = 1.5f
        val a = focusRing.animate().scaleX(1f).scaleY(1f).setStartDelay(0).setDuration(220)
        if (!focusLocked) {
            a.withEndAction {
                focusRing.animate().alpha(0f).setStartDelay(900).setDuration(300)
                    .withEndAction { focusRing.visibility = View.INVISIBLE }.start()
            }
        }
        a.start()
    }

    private fun toggleFocusLock() {
        focusLocked = !focusLocked
        btnLock.isSelected = focusLocked
        if (focusLocked) {
            val l = IntArray(2)
            previewBox.getLocationOnScreen(l)
            focusAt(
                previewView.width / 2f, previewView.height / 2f,
                l[0] + previewBox.width / 2f, l[1] + previewBox.height / 2f
            )
            Toast.makeText(this, "Fokus terkunci. Ketuk layar untuk pindah titik", Toast.LENGTH_SHORT).show()
        } else {
            camera?.cameraControl?.cancelFocusAndMetering()
            focusRing.animate().cancel()
            focusRing.visibility = View.INVISIBLE
        }
    }

    // ---------- folder & simpan ----------
    private fun folderName(): String = prefs.getString("folder", "Microscope") ?: "Microscope"

    private fun askFolder() {
        val et = EditText(this).apply { setText(folderName()) }
        AlertDialog.Builder(this)
            .setTitle("Nama folder di galeri (Pictures/...)")
            .setView(et)
            .setPositiveButton("Simpan") { _, _ ->
                val n = et.text.toString().replace(Regex("[\\\\/:*?\"<>|]"), "").trim()
                if (n.isNotEmpty()) prefs.edit().putString("folder", n).apply()
                Toast.makeText(this, "Folder: Pictures/${folderName()}", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun setShotEnabled(on: Boolean) {
        btnShot.isEnabled = on
        btnShot.alpha = if (on) 1f else 0.5f
    }

    /** Ketuk shutter: kunci fokus+exposure, tunggu sebentar agar getaran tangan reda, lalu ambil foto. */
    private fun onShutter() {
        if (shooting) return
        shooting = true
        setShotEnabled(false)
        txtHold.visibility = View.VISIBLE
        var fired = false
        fun go() {
            if (fired) return
            fired = true
            ui.postDelayed({ takePhoto() }, SETTLE_MS)
        }
        val cam = camera
        if (cam == null) { go(); return }
        try {
            val (px, py) = lastPt ?: Pair(previewView.width / 2f, previewView.height / 2f)
            val pt = previewView.meteringPointFactory.createPoint(px, py)
            val action = FocusMeteringAction.Builder(
                pt, FocusMeteringAction.FLAG_AF or FocusMeteringAction.FLAG_AE
            ).disableAutoCancel().build()
            cam.cameraControl.startFocusAndMetering(action)
                .addListener({ go() }, ContextCompat.getMainExecutor(this))
            ui.postDelayed({ go() }, 1500) // pengaman bila fokus tak kunjung selesai
        } catch (e: Exception) {
            go()
        }
    }

    private fun finishShot() {
        shooting = false
        txtHold.visibility = View.GONE
        setShotEnabled(true)
        if (!focusLocked) camera?.cameraControl?.cancelFocusAndMetering()
    }

    private fun takePhoto() {
        val ic = imageCapture ?: run { finishShot(); return }
        val crop = extra
        ic.takePicture(io, object : ImageCapture.OnImageCapturedCallback() {
            override fun onCaptureSuccess(image: ImageProxy) {
                try {
                    val rot = image.imageInfo.rotationDegrees
                    var bmp = image.toBitmap()
                    image.close()
                    if (rot != 0) {
                        val m = Matrix().apply { postRotate(rot.toFloat()) }
                        bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
                    }
                    if (crop > 1.01f) {
                        val cw = (bmp.width / crop).toInt()
                        val ch = (bmp.height / crop).toInt()
                        bmp = Bitmap.createBitmap(
                            bmp, (bmp.width - cw) / 2, (bmp.height - ch) / 2, cw, ch
                        )
                    }
                    save(bmp)
                    runOnUiThread {
                        Toast.makeText(
                            this@MainActivity, "Tersimpan di Pictures/${folderName()}",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                } catch (e: Exception) {
                    runOnUiThread {
                        Toast.makeText(this@MainActivity, "Gagal: ${e.message}", Toast.LENGTH_LONG).show()
                    }
                } finally {
                    runOnUiThread { finishShot() }
                }
            }

            override fun onError(e: ImageCaptureException) {
                runOnUiThread {
                    finishShot()
                    Toast.makeText(this@MainActivity, "Gagal: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        })
    }

    private fun save(bmp: Bitmap) {
        val name = "MIC_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".jpg"
        val folder = folderName()
        if (Build.VERSION.SDK_INT >= 29) {
            val cv = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, name)
                put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/" + folder)
            }
            val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv)!!
            contentResolver.openOutputStream(uri)!!.use { bmp.compress(Bitmap.CompressFormat.JPEG, 95, it) }
        } else {
            val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), folder)
            dir.mkdirs()
            val f = File(dir, name)
            FileOutputStream(f).use { bmp.compress(Bitmap.CompressFormat.JPEG, 95, it) }
            MediaScannerConnection.scanFile(this, arrayOf(f.path), arrayOf("image/jpeg"), null)
        }
    }

    // ---------- galeri ----------
    private fun showTab(gallery: Boolean) {
        tabCam.isSelected = !gallery
        tabGal.isSelected = gallery
        galleryLayer.visibility = if (gallery) View.VISIBLE else View.GONE
        btnFlash.visibility = if (gallery) View.INVISIBLE else View.VISIBLE
        backCb.isEnabled = gallery
        if (gallery) loadPhotos()
    }

    private fun loadPhotos() {
        io.execute {
            val list = ArrayList<Uri>()
            try {
                contentResolver.query(
                    MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                    arrayOf(MediaStore.Images.Media._ID),
                    MediaStore.Images.Media.DISPLAY_NAME + " LIKE ?",
                    arrayOf("MIC_%"),
                    MediaStore.Images.Media.DATE_ADDED + " DESC, " + MediaStore.Images.Media._ID + " DESC"
                )?.use { c ->
                    val col = c.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
                    while (c.moveToNext()) {
                        list.add(
                            android.content.ContentUris.withAppendedId(
                                MediaStore.Images.Media.EXTERNAL_CONTENT_URI, c.getLong(col)
                            )
                        )
                    }
                }
            } catch (e: Exception) {
                // abaikan; tampilkan kosong
            }
            runOnUiThread {
                photos = list
                galleryAdapter.notifyDataSetChanged()
                txtEmpty.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
            }
        }
    }

    private fun decode(uri: Uri, maxSide: Int): Bitmap? = try {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (max(bounds.outWidth, bounds.outHeight) / (sample * 2) >= maxSide) sample *= 2
        val opt = BitmapFactory.Options().apply { inSampleSize = sample }
        contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opt) }
    } catch (e: Exception) {
        null
    }

    private val galleryAdapter = object : BaseAdapter() {
        override fun getCount() = photos.size
        override fun getItem(p: Int) = photos[p]
        override fun getItemId(p: Int) = p.toLong()
        override fun getView(p: Int, cv: View?, parent: ViewGroup): View {
            val iv = (cv as? ImageView) ?: SquareImageView(parent.context).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP
                setBackgroundColor(0xFF161C24.toInt())
            }
            val uri = photos[p]
            val key = uri.toString()
            iv.tag = key
            val cached = thumbs.get(key)
            if (cached != null) {
                iv.setImageBitmap(cached)
            } else {
                iv.setImageDrawable(null)
                thumbIo.execute {
                    val b = decode(uri, 320) ?: return@execute
                    thumbs.put(key, b)
                    iv.post { if (iv.tag == key) iv.setImageBitmap(b) }
                }
            }
            return iv
        }
    }

    private fun openViewer(uri: Uri) {
        io.execute {
            val b = decode(uri, 2048)
            runOnUiThread {
                if (b == null) {
                    Toast.makeText(this, "Gagal membuka foto", Toast.LENGTH_SHORT).show()
                } else {
                    viewerImg.setImageBitmap(b)
                    viewer.visibility = View.VISIBLE
                    backCb.isEnabled = true
                }
            }
        }
    }

    private fun closeViewer() {
        viewer.visibility = View.GONE
        viewerImg.setImageDrawable(null)
        backCb.isEnabled = galleryLayer.visibility == View.VISIBLE
    }

    companion object {
        private const val SETTLE_MS = 700L
    }
}
