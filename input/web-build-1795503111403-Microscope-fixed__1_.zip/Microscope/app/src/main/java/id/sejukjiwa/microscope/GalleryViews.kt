package id.sejukjiwa.microscope

import android.content.Context
import android.graphics.Matrix
import android.graphics.RectF
import android.util.AttributeSet
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.widget.ImageView
import kotlin.math.min

/** ImageView kotak untuk grid thumbnail. */
class SquareImageView @JvmOverloads constructor(ctx: Context, attrs: AttributeSet? = null) :
    ImageView(ctx, attrs) {
    override fun onMeasure(w: Int, h: Int) = super.onMeasure(w, w)
}

/** ImageView dengan cubit-untuk-zoom, geser, dan ketuk dua kali. */
class ZoomImageView @JvmOverloads constructor(ctx: Context, attrs: AttributeSet? = null) :
    ImageView(ctx, attrs) {

    private val m = Matrix()
    private val vals = FloatArray(9)
    private var base = 1f

    private val sd = ScaleGestureDetector(ctx, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(d: ScaleGestureDetector): Boolean {
            val cur = scale()
            val target = (cur * d.scaleFactor).coerceIn(base, base * 10f)
            val f = target / cur
            m.postScale(f, f, d.focusX, d.focusY)
            fit()
            return true
        }
    })

    private val gd = GestureDetector(ctx, object : GestureDetector.SimpleOnGestureListener() {
        override fun onScroll(e1: MotionEvent?, e2: MotionEvent, dx: Float, dy: Float): Boolean {
            if (sd.isInProgress) return false
            m.postTranslate(-dx, -dy)
            fit()
            return true
        }

        override fun onDoubleTap(e: MotionEvent): Boolean {
            if (scale() > base * 1.05f) reset()
            else {
                val f = 3f
                m.postScale(f, f, e.x, e.y)
                fit()
            }
            return true
        }
    })

    init { scaleType = ScaleType.MATRIX }

    private fun scale(): Float {
        m.getValues(vals)
        return vals[Matrix.MSCALE_X]
    }

    private fun fit() {
        val d = drawable ?: return
        val r = RectF(0f, 0f, d.intrinsicWidth.toFloat(), d.intrinsicHeight.toFloat())
        m.mapRect(r)
        val dx: Float
        val dy: Float
        dx = if (r.width() <= width) (width - r.width()) / 2 - r.left
        else if (r.left > 0) -r.left else if (r.right < width) width - r.right else 0f
        dy = if (r.height() <= height) (height - r.height()) / 2 - r.top
        else if (r.top > 0) -r.top else if (r.bottom < height) height - r.bottom else 0f
        m.postTranslate(dx, dy)
        imageMatrix = m
    }

    fun reset() {
        val d = drawable ?: return
        if (width == 0 || height == 0) return
        val dw = d.intrinsicWidth.toFloat()
        val dh = d.intrinsicHeight.toFloat()
        base = min(width / dw, height / dh)
        m.setScale(base, base)
        fit()
    }

    override fun setImageBitmap(bm: android.graphics.Bitmap?) {
        super.setImageBitmap(bm)
        reset()
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        reset()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        sd.onTouchEvent(e)
        gd.onTouchEvent(e)
        return true
    }
}
