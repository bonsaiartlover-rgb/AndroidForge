
# dipanggil lewat refleksi (MainActivity.enableWebAuthn)
-keep class androidx.webkit.WebSettingsCompat { *; }
