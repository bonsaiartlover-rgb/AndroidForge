package com.spidtes.app;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.net.LinkProperties;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.os.Build;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONArray;
import org.json.JSONObject;

import java.net.InetAddress;

public class MainActivity extends Activity {
    private WebView web;

    /** Dipanggil dari JS sebagai Native.netInfo(): jenis koneksi + DNS perangkat. */
    public class Bridge {
        @JavascriptInterface
        public String netInfo() {
            JSONObject o = new JSONObject();
            try {
                String transport = "none";
                ConnectivityManager cm =
                        (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
                Network n = cm.getActiveNetwork();
                if (n != null) {
                    NetworkCapabilities nc = cm.getNetworkCapabilities(n);
                    if (nc != null) {
                        if (nc.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) transport = "vpn";
                        else if (nc.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) transport = "wifi";
                        else if (nc.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) transport = "cellular";
                        else if (nc.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)) transport = "ethernet";
                        else transport = "other";
                    }
                    LinkProperties lp = cm.getLinkProperties(n);
                    if (lp != null) {
                        JSONArray dns = new JSONArray();
                        for (InetAddress d : lp.getDnsServers()) {
                            String a = d.getHostAddress();
                            if (a == null) continue;
                            int pct = a.indexOf('%');
                            if (pct > 0) a = a.substring(0, pct);
                            dns.put(a);
                        }
                        o.put("dns", dns);
                        if (Build.VERSION.SDK_INT >= 28) {
                            o.put("privateDns", lp.isPrivateDnsActive());
                            String name = lp.getPrivateDnsServerName();
                            if (name != null) o.put("privateDnsName", name);
                        }
                    }
                }
                o.put("transport", transport);
            } catch (Exception e) {
                // abaikan, JS punya cadangan
            }
            return o.toString();
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.parseColor("#0d1b2a"));
        getWindow().setNavigationBarColor(Color.parseColor("#0d1b2a"));

        web = new WebView(this);
        web.setBackgroundColor(Color.parseColor("#0d1b2a"));
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true); // dipakai untuk menyimpan riwayat
        s.setCacheMode(WebSettings.LOAD_NO_CACHE);
        web.addJavascriptInterface(new Bridge(), "Native");
        web.setWebViewClient(new WebViewClient());
        setContentView(web);

        if (savedInstanceState == null) {
            web.loadUrl("file:///android_asset/index.html");
        } else {
            web.restoreState(savedInstanceState);
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        web.saveState(out);
    }
}
