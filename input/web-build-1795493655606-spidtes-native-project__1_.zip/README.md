# Spidtes – project Android native (Gradle)

Struktur ini langsung dikenali Gradle (ada settings.gradle & build.gradle di root),
jadi `gradle assembleDebug` bisa dijalankan tanpa langkah tambahan.

Isi: WebView yang menampilkan app/src/main/assets/index.html (UI speedtest).
Ubah tampilan/logika di file itu.

Build:  gradle assembleDebug
Hasil:  app/build/outputs/apk/debug/app-debug.apk
Syarat: JDK 17, Android SDK platform 34, Gradle 8.7+

## Perubahan v1.1
- Gauge berskala linear dengan garis & angka (0, 5, 10, 15, 20 → otomatis naik ke 50/100/200/500/1000 Mbps).
- Satu halaman tanpa scroll + tab bawah: Tes, Riwayat, Jaringan, Skor.
- Menampilkan Unduh, Unggah, Ping, Jitter, server tes (Cloudflare + kota), provider (MyRepublic/IndiHome/dll), jenis koneksi, dan DNS (bawaan ISP atau kustom + nama).
- Riwayat tes tersimpan di localStorage (maks. 100), lengkap dengan grafik.
- MainActivity: bridge `Native.netInfo()` membaca jenis koneksi & DNS asli perangkat (termasuk Private DNS).
- Layar dikunci portrait.
