# Spidtes – project Android native (Gradle)

Struktur ini langsung dikenali Gradle (ada settings.gradle & build.gradle di root),
jadi `gradle assembleDebug` bisa dijalankan tanpa langkah tambahan.

Isi: WebView yang menampilkan app/src/main/assets/index.html (UI speedtest).
Ubah tampilan/logika di file itu.

Build:  gradle assembleDebug
Hasil:  app/build/outputs/apk/debug/app-debug.apk
Syarat: JDK 17, Android SDK platform 34, Gradle 8.7+
