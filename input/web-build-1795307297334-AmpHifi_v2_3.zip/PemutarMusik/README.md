# MP3 (Android) - skin Ocean Blue

Jendela: PEMUTAR MUSIK, EQUALIZER 10 BAND (+ bass boost, stereo width, power amp), VU METER (VU L/R, LED meter L/R berlawanan, knob volume besar), PLAYLIST.

## Fitur
- Acak (shuffle) dan Ulang (mati / semua / 1 lagu), masing-masing dengan LED.
- Skin permanen OCEAN (tombol ganti skin dihapus).
- Playlist: tekan lama lagu -> Pindah ke album, Hapus lagu, Rincian (+ Naikkan/Turunkan urutan, Keluarkan dari album saat di dalam album).
- Album = playlist buatan sendiri: tombol "+" buat album, tekan lama nama album -> Ganti nama / Hapus album,
  tombol TAMBAH untuk memilih banyak lagu sesuai urutan ketukan.
- Suara: auto headroom, limiter look-ahead, bass guard otomatis, power amp 0..+12 dB.

## Cara pakai
1. Android Studio terbaru, File > Open > pilih folder ini, tunggu Gradle sync.
2. Colok HP (USB debugging), Run. Beri izin akses musik.
Min Android 7.0 (API 24).

## Catatan v6
- Nama aplikasi: MP3, ikon baru gradasi violet-magenta-coral (adaptive icon).
- Tombol utama: sebelumnya / jeda / putar (tengah, lebih besar) / henti / berikutnya (5 tombol, juga di mini player; tombol sesuai status tetap menyala, mini player selalu di tengah dan hanya digeser naik/turun, menyala biru tua OCEAN saat ditekan). Tombol acak dan ulang ada di baris bawah bersama EQ/DSP/PL; 5 tombol transport di tengah. Font playlist diperbesar.
- Playlist punya kolom cari di bagian bawah.
- Mini player melayang punya grafik spectrum warna.

## Instal tanpa peringatan Play Protect (sebisanya)
Peringatan Play Protect muncul untuk aplikasi di luar Play Store dari developer yang belum dikenal; tidak bisa dihilangkan 100% lewat kode.
1. Buat kunci tanda tangan sendiri (sekali saja, simpan baik-baik, jangan hilang):
   `keytool -genkeypair -v -keystore amphifi.jks -alias amphifi -keyalg RSA -keysize 2048 -validity 10000`
2. Salin `keystore.properties.example` jadi `keystore.properties`, isi password, taruh `.jks` di folder yang sama.
3. Build rilis: `./gradlew assembleRelease` (APK bertanda tangan tetap, bukan debug). Pakai kunci yang sama untuk semua versi.
4. Tanpa peringatan sama sekali: unggah ke Google Play Console (pengujian internal/tertutup), lalu instal dari tautan Play Store.
5. Hanya di HP sendiri: pilih "Instal saja" sekali, atau matikan "Pindai aplikasi dengan Play Protect", atau instal lewat `adb install`.

## Tampilan landscape
- Aplikasi dikunci landscape (`sensorLandscape`, boleh terbalik 180 derajat) dan layar penuh (status bar dan tombol navigasi disembunyikan; geser dari tepi layar untuk menampilkannya sebentar).
- Layar dibagi 2: kiri (player, EQ, DSP) sedikit lebih lebar dari kanan (playlist). Kiri: player, equalizer, DSP bertumpuk dengan tinggi sama (masing-masing 1/3), permanen tanpa minimize. Kanan: playlist, permanen.
- Tombol EQ / DSP / PL dihapus dari player.
- Pojok kanan atas (di baris judul playlist): "–" = minimize jadi mini player, "×" = tutup aplikasi (lagu dihentikan).
- Urutan lagu: terbaru (waktu ditambahkan) di atas, juga di dalam album.
- Judul jendela player: "MUSIC PLAYER", dengan tulisan "mod by aries" di pojok kanan atas jendela player.
- Tombol minimize (biru muda, "–") dan tutup (merah, "×") dibuat jelas; ukurannya mengikuti tinggi layar HP.
- Baris judul jendela player (kiri atas) dan playlist (kanan) sama tinggi; judul EQ/DSP tetap; teks judul rata tengah atas-bawah.
- Ikon aplikasi: gradasi biru OCEAN (biru laut dalam -> biru -> cyan), bar putih, titik aksen cyan muda.

## Mode radio (streaming)
- Baris judul jendela player (kiri atas) punya dua tombol: **MP3** dan **RADIO**, masing-masing dengan LED biru yang menyala di tombol yang aktif. Pindah mode menghentikan pemutaran yang sedang jalan.
- Mode MP3: jendela player penuh seperti biasa. Mode RADIO: seluruh jendela itu berganti jadi radio vintage.
- Radio vintage: layar LCD frekuensi digital (kiri), kaca skala krem dengan angka 88-108 MHz, garis skala, penanda tiap stasiun, dan jarum merah yang bergeser halus ke stasiun terpilih (kanan). Ketuk skala untuk menyetel ke stasiun terdekat.
- Tombol radio: stasiun frekuensi lebih rendah, jeda, putar, henti, stasiun frekuensi lebih tinggi, **SCAN** (loncat tiap ~5 detik ke stasiun berikutnya, ketuk lagi untuk berhenti), **SLEEP** (timer tidur 15/30/60/90 menit, ketuk berulang untuk ganti), **mute** + slider volume. EQ dan DSP tetap bekerja untuk radio.
- Daftar stasiun (kanan): urut dari frekuensi terkecil; stasiun tanpa frekuensi di paling bawah. Ketuk = putar; ikon pensil = edit nama / frekuensi / URL / hapus; "+ STASIUN" = tambah (nama, frekuensi manual opsional, URL).
- Stasiun bawaan: Sebayu FM 94.0, Slawi FM 99.3, Sananta 105.8, Elshinta 99.9 (frekuensi dari direktori radio Streema, bisa diedit), Paramount FM (frekuensi belum diketahui).
- Alamat harus langsung ke stream audio (MP3/AAC/HLS). Alamat berakhiran "/" yang gagal otomatis dicoba lagi dengan "/;" (server Shoutcast lama). File playlist .pls / .m3u belum didukung.
- Izin baru: INTERNET dan WAKE_LOCK; lalu lintas http (tanpa https) diizinkan agar stream lama tetap bisa dibuka.

## Nomor seri (versi)
- Tulisan di pojok kanan atas jendela player: "mod by aries v.17". Angkanya diambil otomatis dari `versionCode` di `app/build.gradle.kts`.
- Tiap selesai modif, naikkan `versionCode` (dan samakan `versionName`) di file itu: 17 -> 18 -> 19 dst. Tulisan di aplikasi ikut berubah.
- Nama file zip dari Claude mengikuti nomor yang sama (PemutarMusik17.zip dst.).

## Tampilan RADIO (v1.8, diperbarui v1.9)
- Badan radio biru bergaya vintage. Kiri = knob VOLUME (putar melingkar, ketuk = bisu), kanan = knob TUNING (putar = geser jarum, lepas = menyetel ke stasiun terdekat).
- Bagian atas: nama stasiun (teks berjalan) + frekuensi. Tengah: kaca skala + jarum merah. Bawah: prev, play/jeda, next (SCAN dan SLEEP kecil di sisi).

## Penomoran versi
Versi tampil di sebelah "mod by aries" (mis. v.1.8). Untuk rilis berikutnya ubah di `app/build.gradle.kts`: `versionName` (1.9, 2.0, ...) dan naikkan `versionCode` (19, 20, ...).

## v1.9 - Radio
- 9 stasiun Tegal dari aplikasi "Radio Online Tegal" (stream asli) masuk daftar bawaan; semua tetap bisa diedit (nama, frekuensi, URL). Daftar lama pengguna digabung otomatis tanpa menghapus hasil edit.
- Knob TUNING sekarang tombol ketuk = frekuensi/stasiun berikutnya. Skala analog dihapus, diganti layar digital (nama, frekuensi, grafik meter saat live).
- Dialog edit stasiun layar penuh: huruf besar, teks panjang turun ke baris bawah, naik di atas keyboard; SIMPAN/BATAL ada di bar atas.

## Perubahan v2.0
- Slider volume di jendela player dihapus; volume sekarang lewat **knob besar** di tengah panel bawah (putar melingkar = volume, ketuk = bisu). Berlaku untuk mode musik dan radio.
- Equalizer: pilihan preset (FLAT/BASS/ROCK/VOKAL/POP) dihapus. Tinggal tombol **ON/OFF** dan slider manual. Tombol **NOISE** (noise filter) ikut dipindah ke panel ini.
- BASS BOOST, STEREO WIDTH, dan POWER AMP dipindah dari panel bawah ke panel equalizer.
- Panel bawah jadi **VU METER**: VU meter jarum L dan R, di bawahnya LED meter L dan R yang bergerak berlawanan (L menyala ke kiri, R ke kanan), knob volume besar di tengah.
- Radio: knob volume di kiri dihapus (sudah ada knob besar di panel bawah).

## v2.3 - Tampilan PORTRAIT (rak hi-fi hitam)
Layar dikunci portrait (`sensorPortrait`). Susunan dari atas ke bawah:
1. **Pemutar MP3 / Radio** - selektor MP3 | RADIO (LED hijau di tombol aktif); panel di bawahnya berganti.
   - MP3: gambar kaset deck (roda pita berputar saat lagu jalan, label bertulis judul), bar posisi lagu, tombol
     sebelumnya / jeda / putar / henti / berikutnya + acak + ulang (strip LED di tiap tombol), lalu diagram LED spectrum.
   - RADIO: dua meter jarum SIGNAL dan TUNING, layar LCD merah (STEREO, frekuensi FM, nama stasiun berjalan),
     preset 1-8 (8 stasiun pertama urut frekuensi), tombol DOWN / jeda / putar / henti / UP, SCAN, SLEEP.
   - Tombol PLAYLIST / STASIUN membuka daftar lagu (album, cari, hapus, dst.) atau daftar stasiun (tambah/edit). Tutup dengan tombol x atau tombol kembali.
2. **Equalizer 7 band** (63, 160, 400, 1K, 2.5K, 6.3K, 16K Hz, +/-12 dB), kiri dan kanan terpisah. Seret fader; ketuk dua kali = 0 dB.
   LED meter L/R kecil di tengah. Tombol FLAT (semua ke 0) dan ON/OFF.
3. **Amplifier**: dua VU meter (lampu oranye), knob VOLUME (putar = volume, ketuk = bisu), knob BASS dan TREBLE
   dengan tombol - / + di bawahnya (-10..+10 dB, tahan = berulang, ketuk knob = 0) dan LED melingkar yang mengikuti.

Perubahan mesin audio (`audio/EqAudioProcessor.kt`, `audio/AudioEngine.kt`):
- Equalizer 7 band punya koefisien terpisah untuk kanal kiri dan kanan. Equalizer 10 band lama tidak dipakai lagi (jalur dibiarkan datar).
- BASS = low shelf 100 Hz, TREBLE = high shelf 10 kHz. Auto headroom ikut menghitung keduanya, jadi boost tidak membuat suara pecah.
- Pengaturan baru disimpan otomatis (kunci `eqL`, `eqR`, `bass`, `treble`).

File baru: `RackKit.kt` (bahan gambar: pelat, tombol, knob, VU, LED) dan `RackScreen.kt` (susunan layar).
Tampilan landscape lama (Screens.kt, WinampKit.kt) masih ada di proyek tetapi tidak dipakai lagi oleh MainActivity.

## Amp Hifi (aplikasi terpisah)
Versi ini diinstal sebagai aplikasi BARU, bukan pembaruan MP3 lama: applicationId `com.aries.amphifi`, nama "Amp Hifi",
ikon knob amber di latar hitam. Pakai kunci tanda tangan sendiri (`amphifi.jks`, alias `amphifi`), berbeda dari aplikasi lama.
Pengaturan dan daftar stasiun/album mulai dari awal karena data aplikasi terpisah.
