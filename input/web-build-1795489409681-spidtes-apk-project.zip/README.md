# Spidtes – Speedtest Internet (APK)

Cek unduh, unggah, ping, jitter (Mbps/ms), jenis koneksi, ISP, dan skor kualitas.
Tes berjalan otomatis saat aplikasi dibuka.

## Cara 1 – Build di komputer (Windows/Mac/Linux)
Butuh: Node.js 18+ (disarankan 20), JDK 17, dan Android SDK
(paling mudah: pasang Android Studio, lalu set variabel ANDROID_HOME).

    npm install
    npm run build:apk

Hasil: android/app/build/outputs/apk/debug/app-debug.apk
Kirim file itu ke HP, lalu pasang (izinkan "Install dari sumber tidak dikenal").

## Cara 2 – Lewat Android Studio
    npm install
    npx cap add android
    node scripts/patch-manifest.js
    npx cap sync android
    npx cap open android
Lalu di Android Studio: Build > Build APK(s).

## Cara 3 – Tanpa pasang apa pun (GitHub Actions)
1. Buat repo GitHub baru, unggah semua isi folder ini.
2. Buka tab Actions > "Build APK" > Run workflow.
3. Setelah selesai, unduh artifact "Spidtes-APK" (berisi app-debug.apk).

## Mengubah tampilan / logika
Edit www/index.html, lalu build ulang.
Nama aplikasi & ID paket ada di capacitor.config.json.

## Catatan
- APK ini versi debug (cukup untuk dipakai pribadi). Untuk Play Store perlu
  build release yang ditandatangani (Build > Generate Signed Bundle/APK).
- Butuh internet aktif; server tes: speed.cloudflare.com.
