// Build APK debug: node scripts/build.js (atau: npm run build:apk)
const { execSync } = require('child_process');
const fs = require('fs');
const run = c => { console.log('\n> ' + c); execSync(c, { stdio: 'inherit' }); };
const win = process.platform === 'win32';

if (!fs.existsSync('android')) run('npx cap add android');
require('./patch-manifest.js');
run('npx cap sync android');
process.chdir('android');
run((win ? 'gradlew.bat' : './gradlew') + ' assembleDebug');
console.log('\nSelesai! APK: android/app/build/outputs/apk/debug/app-debug.apk');
