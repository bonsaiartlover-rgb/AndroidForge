// Menambahkan izin ACCESS_NETWORK_STATE agar jenis koneksi (Wi-Fi/seluler) bisa terbaca
const fs = require('fs');
const p = 'android/app/src/main/AndroidManifest.xml';
let x = fs.readFileSync(p, 'utf8');
const perm = 'android.permission.ACCESS_NETWORK_STATE';
if (!x.includes(perm)) {
  x = x.replace(/(<uses-permission[^>]*android\.permission\.INTERNET[^>]*\/>)/,
    '$1\n    <uses-permission android:name="' + perm + '" />');
  fs.writeFileSync(p, x);
  console.log('Izin ACCESS_NETWORK_STATE ditambahkan.');
}
