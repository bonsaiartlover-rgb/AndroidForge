package com.example.pemutarmusik

import android.content.Context
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import com.example.pemutarmusik.audio.AudioEngine
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Pengatur dua player: [mp3] (lagu) dan [radio] (stream). Dibuat oleh PlaybackService, dipakai bersama
 * oleh PlayerViewModel (aplikasi) dan FloatingPlayerService (mini player), jadi keduanya selalu konsisten.
 *
 * Aturan serah-terima (suara tidak pernah putus di tengah):
 *  - MP3 sedang jalan lalu pindah ke RADIO: MP3 tetap berbunyi. Radio menyambung di latar (diam).
 *    Begitu radio benar-benar live (STATE_READY), baru radio berbunyi dan MP3 DIJEDA (posisi tersimpan).
 *  - Pindah balik ke MP3: lagu dilanjutkan dari posisi terakhir. Radio baru dimatikan setelah MP3 benar-benar berbunyi.
 *  - Kalau MP3 tidak sedang jalan saat pindah, radio langsung berbunyi (dan sebaliknya).
 */
object DeckEngine {

    private var appCtx: Context? = null
    private var initialized = false

    var mp3: ExoPlayer? = null
        private set
    var radio: ExoPlayer? = null
        private set
    private var session: MediaSession? = null

    // ---- status yang dilihat UI ----
    private val _mode = MutableStateFlow(AppMode.MP3)
    /** Tab / mode yang sedang dibuka. */
    val mode: StateFlow<AppMode> = _mode.asStateFlow()

    private val _audible = MutableStateFlow(AppMode.MP3)
    /** Sumber yang sedang BERBUNYI (bisa beda dari [mode] selama radio masih menyambung). */
    val audible: StateFlow<AppMode> = _audible.asStateFlow()

    private val _stationId = MutableStateFlow<Long?>(null)
    val stationId: StateFlow<Long?> = _stationId.asStateFlow()

    private val _radioError = MutableStateFlow<String?>(null)
    val radioError: StateFlow<String?> = _radioError.asStateFlow()

    private val _radioConnecting = MutableStateFlow(false)
    /** true = radio sedang menyambung di latar, sementara MP3 masih berbunyi. */
    val radioConnecting: StateFlow<Boolean> = _radioConnecting.asStateFlow()

    /** Dipanggil saat pengguna menyetel radio manual (tombol / mini player): VM memakainya untuk menghentikan SCAN. */
    @Volatile
    var onUserRadioAction: (() -> Unit)? = null

    // ---- catatan serah-terima ----
    private var pendingRadio = false     // radio menyambung, MP3 masih berbunyi
    private var resumeMp3 = false        // MP3 dijeda karena radio mengambil alih -> lanjutkan saat kembali
    private var resumeRadio = false      // radio dimatikan karena MP3 mengambil alih -> sambung lagi saat kembali
    private var radioUserOff = false     // radio sengaja dijeda / dihentikan pengguna
    private var fallbackTried = false

    @Synchronized
    fun init(context: Context) {
        if (initialized) return
        initialized = true
        val c = context.applicationContext
        appCtx = c
        _mode.value = if (RadioStore.isRadioMode(c)) AppMode.RADIO else AppMode.MP3
        _stationId.value = RadioStore.lastStation(c)
    }

    // ------------------------------------------------------------------ sambungan ke service

    private val mp3Listener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) {
            // MP3 benar-benar berbunyi sementara radio masih yang terdengar -> serahkan ke MP3, matikan radio.
            if (isPlaying && _audible.value == AppMode.RADIO) commitMp3()
        }
    }

    private val radioListener = object : Player.Listener {
        override fun onPlaybackStateChanged(playbackState: Int) {
            if (playbackState == Player.STATE_READY) {
                _radioError.value = null
                // radio sudah live -> sekarang suara pindah dari MP3 ke radio
                if (pendingRadio) commitRadio()
            }
        }

        override fun onPlayerError(error: PlaybackException) = onRadioError(error)
    }

    fun attach(context: Context, mp3Player: ExoPlayer, radioPlayer: ExoPlayer, mediaSession: MediaSession) {
        init(context)
        mp3 = mp3Player
        radio = radioPlayer
        session = mediaSession
        pendingRadio = false
        _radioConnecting.value = false
        resumeMp3 = false
        resumeRadio = false
        radioUserOff = false
        _audible.value = AppMode.MP3
        AudioEngine.radioActive = false
        mp3Player.addListener(mp3Listener)
        radioPlayer.addListener(radioListener)
    }

    fun detach() {
        mp3?.removeListener(mp3Listener)
        radio?.removeListener(radioListener)
        mp3 = null
        radio = null
        session = null
        pendingRadio = false
        _radioConnecting.value = false
        AudioEngine.radioActive = false
    }

    private fun setPending(v: Boolean) {
        pendingRadio = v
        _radioConnecting.value = v
    }

    /** Pindahkan "yang terdengar" + player milik MediaSession (notifikasi, tombol headset, layar kunci). */
    private fun setAudible(m: AppMode) {
        _audible.value = m
        AudioEngine.radioActive = m == AppMode.RADIO
        val p: Player? = if (m == AppMode.RADIO) radio else mp3
        val s = session
        if (p != null && s != null && s.player !== p) s.player = p
    }

    /** Apakah ada suara yang benar-benar keluar sekarang (dipakai spektrum / VU). */
    fun audioPlaying(): Boolean {
        val p = if (_audible.value == AppMode.RADIO) radio else mp3
        return p?.isPlaying == true
    }

    // ------------------------------------------------------------------ pindah mode

    fun setMode(m: AppMode) {
        if (m == _mode.value) return
        _mode.value = m
        _radioError.value = null
        appCtx?.let { RadioStore.setRadioMode(it, m == AppMode.RADIO) }
        if (m == AppMode.RADIO) enterRadio() else enterMp3()
    }

    private fun enterRadio() {
        val mp3Playing = mp3?.isPlaying == true
        // Radio otomatis menyambung kalau MP3 sedang berbunyi (suara pindah setelah radio live)
        // atau kalau radio tadi dimatikan gara-gara MP3 mengambil alih.
        if (mp3Playing || resumeRadio) {
            resumeRadio = false
            val st = currentStation() ?: stations().firstOrNull() ?: return
            startStation(st)
        }
    }

    private fun enterMp3() {
        // Batalkan penyambungan radio yang belum live: MP3 tidak terganggu sama sekali.
        if (pendingRadio) {
            setPending(false)
            radio?.stop()
        }
        val m = mp3 ?: return
        // Kalau radio yang terdengar dan MP3 tadi dijeda karena radio mengambil alih -> lanjutkan lagu dari posisi terakhir.
        // Radio TIDAK dimatikan di sini; baru dimatikan saat MP3 benar-benar berbunyi (commitMp3).
        if (_audible.value == AppMode.RADIO && resumeMp3 && m.currentMediaItem != null) {
            resumeMp3 = false
            playPlayer(m)
        }
    }

    private fun playPlayer(p: ExoPlayer) {
        if (p.playbackState == Player.STATE_IDLE) p.prepare()
        p.play()
    }

    private fun commitMp3() {
        val r = radio
        val radioWasLive = !radioUserOff && r != null &&
            r.playbackState != Player.STATE_IDLE && r.playbackState != Player.STATE_ENDED
        setPending(false)
        r?.stop()
        resumeRadio = radioWasLive
        setAudible(AppMode.MP3)
    }

    private fun commitRadio() {
        val r = radio ?: return
        val m = mp3
        val mp3WasPlaying = _audible.value == AppMode.MP3 && m?.isPlaying == true
        setPending(false)
        setAudible(AppMode.RADIO)
        r.play()
        if (m != null && mp3WasPlaying) {
            m.pause()            // posisi lagu tetap tersimpan
            resumeMp3 = true
        }
    }

    // ------------------------------------------------------------------ MP3

    fun mp3PlayList(items: List<MediaItem>, index: Int) {
        val m = mp3 ?: return
        resumeMp3 = false
        m.setMediaItems(items, index, 0L)
        m.prepare()
        m.play()
    }

    fun mp3Play() {
        val m = mp3 ?: return
        resumeMp3 = false
        playPlayer(m)
    }

    fun mp3Pause() {
        resumeMp3 = false
        mp3?.pause()
    }

    fun mp3Stop() {
        resumeMp3 = false
        mp3?.let { it.pause(); it.seekTo(0L) }
    }

    fun mp3Next() {
        mp3?.seekToNextMediaItem()
    }

    fun mp3Previous() {
        mp3?.seekToPrevious()
    }

    // ------------------------------------------------------------------ radio

    private fun stations(): List<RadioStation> = appCtx?.let { RadioStore.load(it) } ?: emptyList()

    fun currentStation(): RadioStation? = stations().firstOrNull { it.id == _stationId.value }

    private fun stationItem(st: RadioStation, url: String): MediaItem =
        MediaItem.Builder()
            .setMediaId("radio:${st.id}")
            .setUri(url)
            .setMediaMetadata(
                MediaMetadata.Builder()
                    .setTitle(st.name)
                    .setArtist(if (st.freq.isNotBlank()) "FM ${st.freq}" else "Radio")
                    .setIsPlayable(true)
                    .build()
            )
            .build()

    fun isStationLoaded(id: Long): Boolean {
        val r = radio ?: return false
        return r.currentMediaItem?.mediaId == "radio:$id" && r.playbackState != Player.STATE_IDLE
    }

    /**
     * Sambungkan stasiun [st] (selalu mulai dari siaran langsung).
     * Kalau MP3 sedang berbunyi, radio menyambung diam-diam dan baru berbunyi saat live; MP3 jalan terus sampai saat itu.
     */
    fun startStation(st: RadioStation) {
        val r = radio ?: return
        val c = appCtx ?: return
        _stationId.value = st.id
        RadioStore.setLastStation(c, st.id)
        _radioError.value = null
        fallbackTried = false
        radioUserOff = false
        val hold = _audible.value == AppMode.MP3 && mp3?.isPlaying == true
        r.setMediaItem(stationItem(st, st.url))
        if (hold) {
            setPending(true)
            r.playWhenReady = false
            r.prepare()
        } else {
            setPending(false)
            r.prepare()
            commitRadio()
        }
    }

    fun radioPlay() {
        onUserRadioAction?.invoke()
        val r = radio ?: return
        val st = currentStation() ?: stations().firstOrNull() ?: return
        val same = r.currentMediaItem?.mediaId == "radio:${st.id}"
        val mp3Audible = _audible.value == AppMode.MP3 && mp3?.isPlaying == true
        if (!same || r.playbackState == Player.STATE_IDLE || r.playbackState == Player.STATE_ENDED || mp3Audible || pendingRadio) {
            startStation(st)
        } else {
            radioUserOff = false
            r.seekToDefaultPosition()   // lompat ke siaran langsung, bukan lanjut dari sisa buffer lama
            setAudible(AppMode.RADIO)
            r.play()
        }
    }

    fun radioPause() {
        onUserRadioAction?.invoke()
        val wasPending = pendingRadio
        setPending(false)
        radioUserOff = true
        resumeRadio = false
        if (wasPending) {
            // tombol jeda ditekan saat radio masih menyambung: batalkan sambungan dan senyapkan MP3 juga
            radio?.stop()
            mp3Pause()
        } else {
            radio?.pause()
        }
    }

    fun radioStop() {
        onUserRadioAction?.invoke()
        val wasPending = pendingRadio
        setPending(false)
        radioUserOff = true
        resumeRadio = false
        _radioError.value = null
        radio?.stop()
        if (wasPending) mp3Pause()
    }

    /** Pindah ke stasiun berikutnya (+1) / sebelumnya (-1) dan langsung diputar. */
    fun stepStation(delta: Int) {
        onUserRadioAction?.invoke()
        val list = stations()
        if (list.isEmpty()) return
        val i = list.indexOfFirst { it.id == _stationId.value }
        val j = if (i < 0) 0 else (i + delta).mod(list.size)
        startStation(list[j])
    }

    /** Stasiun yang sedang dipilih dihapus. */
    fun clearStation() {
        setPending(false)
        radio?.stop()
        _stationId.value = null
        appCtx?.let { RadioStore.setLastStation(it, null) }
    }

    private fun onRadioError(error: PlaybackException) {
        val st = currentStation() ?: return
        val r = radio ?: return
        // Server Shoutcast lama: "http://host:port/" menampilkan halaman web, audionya ada di "/;"
        if (!fallbackTried && st.url.endsWith("/")) {
            fallbackTried = true
            r.setMediaItem(stationItem(st, st.url + ";"))
            r.playWhenReady = !pendingRadio
            r.prepare()
            return
        }
        // Gagal menyambung: kalau MP3 sedang berbunyi, MP3 tetap jalan.
        setPending(false)
        _radioError.value = when (error.errorCode) {
            PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED,
            PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_TIMEOUT -> "Tidak bisa terhubung. Cek internet atau alamat server."
            PlaybackException.ERROR_CODE_IO_BAD_HTTP_STATUS -> "Server menolak. Alamat URL mungkin salah."
            PlaybackException.ERROR_CODE_PARSING_CONTAINER_UNSUPPORTED,
            PlaybackException.ERROR_CODE_PARSING_CONTAINER_MALFORMED,
            PlaybackException.ERROR_CODE_PARSING_MANIFEST_MALFORMED -> "Alamat ini bukan stream audio. Edit URL stasiun."
            else -> "Gagal memutar stream (kode ${error.errorCode})."
        }
    }

    // ------------------------------------------------------------------ perintah sesuai mode (mini player, tombol umum)

    fun play() {
        if (_mode.value == AppMode.RADIO) radioPlay()
        else if (mp3?.currentMediaItem != null) mp3Play()
    }

    fun pause() {
        if (_mode.value == AppMode.RADIO) radioPause() else mp3Pause()
    }

    fun stop() {
        if (_mode.value == AppMode.RADIO) radioStop() else mp3Stop()
    }

    fun next() {
        if (_mode.value == AppMode.RADIO) stepStation(1) else mp3Next()
    }

    fun previous() {
        if (_mode.value == AppMode.RADIO) stepStation(-1) else mp3Previous()
    }

    // ------------------------------------------------------------------ umum

    fun setVolume(v: Float) {
        val x = v.coerceIn(0f, 1f)
        mp3?.volume = x
        radio?.volume = x
    }

    /** Hentikan semuanya (tombol tutup aplikasi). */
    fun stopAll() {
        setPending(false)
        radioUserOff = true
        resumeRadio = false
        resumeMp3 = false
        radio?.stop()
        mp3?.let { it.pause(); it.seekTo(0L) }
    }

    /** Jeda semuanya tanpa menghapus posisi (aplikasi di-swipe dari recent apps). */
    fun pauseAll() {
        setPending(false)
        mp3?.pause()
        radio?.pause()
    }
}
