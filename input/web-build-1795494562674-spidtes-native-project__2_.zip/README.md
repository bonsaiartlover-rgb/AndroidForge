# Spidtes – project Android native (Gradle)

Struktur ini langsung dikenali Gradle (ada settings.gradle & build.gradle di root),
jadi `gradle assembleDebug` bisa dijalankan tanpa langkah tambahan.

Isi: WebView yang menampilkan app/src/main/assets/index.html (UI speedtest).
Ubah tampilan/logika di file itu.

Build:  gradle assembleDebug
Hasil:  app/build/outputs/apk/debug/spidtes-v<versi>-<kode>-debug.apk
Syarat: JDK 17, Android SDK platform 34, Gradle 8.7+

## Update tanpa hapus aplikasi lama
1. Edit `version.properties`: naikkan `versionCode` (harus lebih besar dari sebelumnya) dan ubah `versionName`.
2. Catat perubahan di `CHANGELOG.md`.
3. `gradle assembleDebug`, lalu pasang APK baru langsung di atas yang lama.

Syarat: `applicationId` (com.spidtes.app) dan kunci `spidtes.keystore` jangan diganti.
Catatan: jika aplikasi lama (v1.0) dibuild dengan kunci debug bawaan komputer lain, pemasangan
pertama versi ini mungkin ditolak (tanda tangan beda). Hapus sekali saja; setelah itu semua
update berikutnya bisa ditimpa. Riwayat tes ikut tersimpan selama tidak di-uninstall.

Lihat `CHANGELOG.md` untuk daftar perubahan.
