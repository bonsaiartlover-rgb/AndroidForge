# Riwayat versi Spidtes

Aturan: tiap perbaikan/modif -> naikkan `versionCode` (+1) dan ubah `versionName`
di `version.properties`, tambah catatan di sini, lalu build ulang.
APK baru otomatis menimpa (update) yang lama tanpa uninstall.

## v1.1.0 (versionCode 2)
- Gauge berskala dengan garis & angka (0, 5, 10, 15, 20, otomatis naik).
- Satu halaman tanpa scroll + tab: Tes, Riwayat, Jaringan, Skor.
- Kartu Unduh/Unggah/Ping/Jitter berwarna: hijau = Good, kuning = Medium, merah = Bad.
- Info server, provider (MyRepublic/IndiHome/dll), koneksi, DNS beserta IP-nya (tes kebocoran DNS via bash.ws).
- Daftar DNS perangkat dan resolver ditulis satu per baris.
- Nomor versi tampil di header; nama APK berurutan.
- Tanda tangan tetap (spidtes.keystore) agar bisa update tanpa hapus aplikasi lama.

## v1.0 (versionCode 1)
- Versi awal: speedtest unduh/unggah/ping/jitter, skor.
