# MP3Radio (Android)

Pemutar **MP3 + Radio streaming** dengan **equalizer 10 band**, **power amp / pre amp / bass boost**, dan **VU meter**.
Mesin audio dan fitur sama seperti PemutarMusik v2.6, tetapi tampilannya dibuat ulang: potret, kaca (glass), warna neon cyan-violet-magenta.

## Layar (navigasi bawah)
- **PUTAR** - MP3: cakram berputar + spektrum melingkar, seek, prev / play-jeda / henti / next, ACAK, ULANG (mati / semua / 1 lagu).
  RADIO: layar frekuensi besar, **dial bergulir** (geser untuk menyetel, lepas = pindah ke stasiun terdekat, ketuk penanda = langsung setel), prev / play / henti / next, **SCAN**, **SLEEP** (15/30/60/90 menit), pesan gangguan stream.
- **LIST** - MP3: album buatan sendiri (chip di atas; tekan lama chip = ganti nama / hapus), kolom cari, tekan lama lagu = pindah ke album, naikkan / turunkan (di dalam album), keluarkan, rincian, hapus. "TAMBAH LAGU" memilih banyak lagu sesuai urutan ketukan.
  RADIO: daftar stasiun (urut frekuensi), ketuk = putar, pensil = edit nama / frekuensi / URL / hapus, "+ STASIUN" = tambah.
- **EQ** - EQ ON/OFF, NOISE filter, 10 slider band (-12..+12 dB, langkah 0,5), RESET, BASS BOOST, POWER AMP (0..+12 dB), PRE AMP, indikator hidup BASS GUARD / LIMITER / HEADROOM.
- **VU** - dua VU meter jarum neon L/R, LED meter dua sisi dari tengah (L ke kiri, R ke kanan), knob volume besar (putar melingkar = volume, ketuk = bisu).

Tombol **MP3 / RADIO** di pojok kanan atas mengganti mode. **Suara tidak diputus saat pindah** (v1.1):
- MP3 sedang main lalu pindah ke RADIO: MP3 tetap berbunyi, radio menyambung di latar (status "MENYAMBUNG"). Begitu radio live, suara pindah ke radio dan MP3 dijeda (posisi tersimpan).
- Pindah balik ke MP3: lagu lanjut dari posisi terakhir; radio baru dimatikan setelah MP3 benar-benar berbunyi.
- Kalau radio gagal tersambung, MP3 tetap jalan dan pesan gangguan muncul.
- Mini player melayang: tombol sebelumnya / berikutnya mengganti lagu (mode MP3) atau stasiun (mode RADIO). Tombol "-" = mini player melayang, "x" = tutup aplikasi.
EQ, DSP, VU, dan spektrum bekerja untuk MP3 maupun radio.

## Yang sama dengan versi lama (tidak diubah)
`MusicRepository`, `AlbumStore`, `RadioStore` (11 stasiun bawaan), seluruh folder `audio/` (EQ, limiter look-ahead, bass guard, spectrum; kini ada satu prosesor per player).

## Perubahan v1.1
`PlaybackService` kini memegang DUA ExoPlayer (MP3 + radio). File baru `DeckEngine.kt` mengatur serah-terima suara dan dipakai bersama oleh `PlayerViewModel` dan `FloatingPlayerService`.


## Beda dengan versi lama
- Tampilan potret (bukan landscape 3 jendela); semua tema Winamp/OCEAN diganti tema neon.
- applicationId baru `id.sejukjiwa.neondeck` sehingga bisa dipasang berdampingan dengan aplikasi lama.
- Di dalam album, urutan lagu mengikuti urutan album (Naikkan / Turunkan benar-benar terlihat). Di SEMUA tetap terbaru di atas.
- Volume lewat knob melingkar mutlak (sudut = nilai).

## Cara pakai
1. Android Studio terbaru, File > Open > pilih folder ini, tunggu Gradle sync.
2. Colok HP (USB debugging), Run. Beri izin akses musik.
Min Android 7.0 (API 24).

## Tanda tangan rilis
Salin `keystore.properties.example` menjadi `keystore.properties`, isi, lalu `./gradlew assembleRelease` (lihat README versi lama untuk langkah keytool).

## Versi
Ubah `versionName` dan naikkan `versionCode` di `app/build.gradle.kts` untuk tiap rilis.
