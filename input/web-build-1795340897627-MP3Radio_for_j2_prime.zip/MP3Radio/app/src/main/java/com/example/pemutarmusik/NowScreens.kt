package com.example.pemutarmusik

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Bedtime
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Radio
import androidx.compose.material.icons.rounded.Repeat
import androidx.compose.material.icons.rounded.RepeatOne
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.ui.draw.clip
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.Player
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.floor

// ================================================================== MP3

private const val SPEED_MIN = 0.75f
private const val SPEED_MAX = 1.25f
/** Lebar zona magnet di sekitar kecepatan normal (1.0x). */
private const val SPEED_MAGNET = 0.04f

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun Mp3NowScreen(vm: PlayerViewModel, modifier: Modifier = Modifier) {
    val ui by vm.ui.collectAsState()
    val hasSong = ui.mediaId != null

    Column(
        modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Spacer(Modifier.height(6.dp))
        HeroVisualizer(ui.isPlaying, Modifier.fillMaxWidth(0.72f)) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Rounded.MusicNote, null, tint = Cyan, modifier = Modifier.size(22.dp))
                Spacer(Modifier.height(2.dp))
                Text(formatTime(ui.positionMs), style = hud(17.sp, TextHi, bold = true, mono = true, spacing = 1.sp))
            }
        }
        Spacer(Modifier.height(10.dp))
        Text(
            ui.title ?: "Belum ada lagu",
            style = hud(20.sp, TextHi, bold = true, spacing = 0.4.sp),
            maxLines = 1,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth().basicMarquee(iterations = Int.MAX_VALUE),
        )
        Spacer(Modifier.height(2.dp))
        Text(
            if (hasSong) (ui.artist ?: "") else "Buka tab LIST lalu pilih lagu",
            style = hud(13.sp, TextDim, spacing = 0.6.sp),
            maxLines = 1,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth(),
        )
        Spacer(Modifier.height(6.dp))
        SeekBar(ui.positionMs, ui.durationMs, vm::seekTo, Modifier.fillMaxWidth())
        Spacer(Modifier.height(6.dp))

        // transport: sebelumnya, PUTAR/JEDA (besar), henti, berikutnya
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            NeonIconButton(Icons.Rounded.SkipPrevious, "Sebelumnya", vm::previous, size = 52.dp)
            NeonIconButton(
                if (ui.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                if (ui.isPlaying) "Jeda" else "Putar",
                { if (ui.isPlaying) vm.pause() else vm.play() },
                size = 74.dp, filled = true,
            )
            NeonIconButton(Icons.Rounded.Stop, "Henti", vm::stop, size = 52.dp, active = ui.isStopped && hasSong, color = Danger)
            NeonIconButton(Icons.Rounded.SkipNext, "Berikutnya", vm::next, size = 52.dp)
        }
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
            NeonChip("ACAK", ui.shuffle, vm::toggleShuffle, leading = Icons.Rounded.Shuffle, color = Violet)
            val repeatText = when (ui.repeatMode) {
                Player.REPEAT_MODE_ONE -> "ULANG 1"
                Player.REPEAT_MODE_ALL -> "ULANG SEMUA"
                else -> "ULANG MATI"
            }
            NeonChip(
                repeatText, ui.repeatMode != Player.REPEAT_MODE_OFF, vm::toggleRepeat,
                leading = if (ui.repeatMode == Player.REPEAT_MODE_ONE) Icons.Rounded.RepeatOne else Icons.Rounded.Repeat,
                color = Magenta,
            )
        }
        Spacer(Modifier.height(10.dp))
        SpeedDial(ui.speed, vm::setSpeed)
        Spacer(Modifier.height(14.dp))
        SpectrumBars(ui.isPlaying, Modifier.fillMaxWidth().height(52.dp))
        Spacer(Modifier.height(10.dp))
    }
}

// ================================================================== RADIO

private const val FM_MIN = 87.5f
private const val FM_MAX = 108f

@OptIn(ExperimentalFoundationApi::class, ExperimentalLayoutApi::class)
@Composable
fun RadioNowScreen(vm: PlayerViewModel, modifier: Modifier = Modifier) {
    val ui by vm.ui.collectAsState()
    val stations by vm.stations.collectAsState()
    val stationId by vm.stationId.collectAsState()
    val error by vm.radioError.collectAsState()
    val scanning by vm.scanning.collectAsState()
    val sleepLeft by vm.sleepLeft.collectAsState()
    val connecting by vm.radioConnecting.collectAsState()

    val st = stations.firstOrNull { it.id == stationId }
    val freq = st?.freqValue
    val buffering = connecting || (ui.playWhenReady && ui.playbackState == Player.STATE_BUFFERING)
    val status = when {
        error != null -> "GANGGUAN"
        ui.isPlaying -> "LIVE"
        buffering -> "MENYAMBUNG"
        else -> "SIAGA"
    }
    val statusColor = when (status) {
        "LIVE" -> Lime
        "GANGGUAN" -> Danger
        "MENYAMBUNG" -> Amber
        else -> TextDim
    }

    Column(
        modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 18.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Spacer(Modifier.height(6.dp))
        // ---- layar hologram frekuensi
        Column(
            Modifier.fillMaxWidth().glass(26.dp, Cyan, 0.9f).padding(horizontal = 16.dp, vertical = 14.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.Radio, null, tint = Cyan, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(6.dp))
                Text("FM TUNER", style = hud(11.sp, Cyan, bold = true, spacing = 2.2.sp))
                Spacer(Modifier.weight(1f))
                Box(Modifier.size(8.dp).neonGlow(statusColor, 5.dp, 0.8f).background(statusColor, CircleShape))
                Spacer(Modifier.width(6.dp))
                Text(status, style = hud(11.sp, statusColor, bold = true, spacing = 1.8.sp))
            }
            Spacer(Modifier.height(6.dp))
            Row(verticalAlignment = Alignment.Bottom) {
                Text(
                    freq?.let { "%.1f".format(java.util.Locale.US, it) } ?: "--.-",
                    style = hud(64.sp, TextHi, bold = true, mono = true, spacing = 2.sp),
                )
                Spacer(Modifier.width(8.dp))
                Text("MHz", style = hud(14.sp, Cyan, bold = true), modifier = Modifier.padding(bottom = 14.dp))
            }
            Text(
                st?.name ?: "Pilih stasiun di tab LIST",
                style = hud(16.sp, Cyan, bold = true, spacing = 1.6.sp),
                maxLines = 1,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth().basicMarquee(iterations = Int.MAX_VALUE),
            )
            Spacer(Modifier.height(10.dp))
            SpectrumBars(ui.isPlaying, Modifier.fillMaxWidth().height(38.dp))
        }
        Spacer(Modifier.height(14.dp))

        TunerStrip(
            stations = stations,
            currentFreq = freq,
            currentId = stationId,
            onTune = vm::playStation,
            modifier = Modifier.fillMaxWidth().height(92.dp).glass(20.dp),
        )
        Text("geser dial untuk menyetel stasiun", style = hud(10.sp, TextFaint, spacing = 1.sp), modifier = Modifier.padding(top = 6.dp))
        Spacer(Modifier.height(12.dp))

        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            NeonIconButton(Icons.Rounded.SkipPrevious, "Stasiun sebelumnya", { vm.stepStation(-1) }, size = 58.dp, filled = true)
            NeonIconButton(
                if (ui.isPlaying || buffering) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                if (ui.isPlaying) "Jeda" else "Putar",
                { if (ui.isPlaying || buffering) vm.radioPause() else vm.radioPlay() },
                size = 58.dp, filled = true,
            )
            TuningKnob(stations.size, stations.indexOfFirst { it.id == stationId }, { vm.stepStation(1) })
        }
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            NeonChip("SCAN", scanning, vm::toggleScan, leading = Icons.Rounded.Search, color = Violet)
            NeonChip(
                if (sleepLeft > 0) "SLEEP ${sleepLeft}M" else "SLEEP",
                sleepLeft > 0, vm::cycleSleep, leading = Icons.Rounded.Bedtime, color = Magenta,
            )
        }
        // tombol channel 1..N (otomatis bertambah / berkurang mengikuti daftar stasiun, urut frekuensi)
        if (stations.isNotEmpty()) {
            Spacer(Modifier.height(14.dp))
            FlowRow(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                stations.forEachIndexed { i, s ->
                    NeonChip("${i + 1}", s.id == stationId, { vm.playStation(s) }, color = Cyan, modifier = Modifier.width(52.dp))
                }
            }
        }
        error?.let {
            Spacer(Modifier.height(10.dp))
            Text(it, style = hud(12.sp, Danger, spacing = 0.4.sp), textAlign = TextAlign.Center)
        }
        Spacer(Modifier.height(10.dp))
    }
}

/**
 * Dial frekuensi: skala bergulir, jarum tetap di tengah. Geser = menyetel; dilepas = pindah ke stasiun terdekat.
 * Ketuk penanda stasiun = langsung setel.
 */
@Composable
fun TunerStrip(
    stations: List<RadioStation>,
    currentFreq: Float?,
    currentId: Long?,
    onTune: (RadioStation) -> Unit,
    modifier: Modifier = Modifier,
) {
    val tm = rememberTextMeasurer(cacheSize = 64)
    val pxPerMhz = with(LocalDensity.current) { 46.dp.toPx() }
    var dragFreq by remember { mutableStateOf<Float?>(null) }
    val curNow by rememberUpdatedState(currentFreq ?: 98f)
    val stNow by rememberUpdatedState(stations)
    val idNow by rememberUpdatedState(currentId)
    val tuneNow by rememberUpdatedState(onTune)
    var widthPx by remember { mutableStateOf(0f) }

    fun nearest(f: Float, maxDist: Float): RadioStation? =
        stNow.filter { it.freqValue != null }
            .minByOrNull { abs(it.freqValue!! - f) }
            ?.takeIf { abs(it.freqValue!! - f) <= maxDist }

    val shown = dragFreq ?: (currentFreq ?: 98f)

    Canvas(
        modifier
            .onSizeChanged { widthPx = it.width.toFloat() }
            .pointerInput(Unit) {
                detectHorizontalDragGestures(
                    onDragStart = { dragFreq = curNow },
                    onDragEnd = {
                        val f = dragFreq
                        dragFreq = null
                        if (f != null) {
                            val s = nearest(f, 99f)
                            if (s != null && s.id != idNow) tuneNow(s)
                        }
                    },
                    onDragCancel = { dragFreq = null },
                    onHorizontalDrag = { change, dx ->
                        change.consume()
                        dragFreq = ((dragFreq ?: curNow) - dx / pxPerMhz).coerceIn(FM_MIN, FM_MAX)
                    },
                )
            }
            .pointerInput(Unit) {
                detectTapGestures(onTap = { o ->
                    val f = curNow + (o.x - widthPx / 2f) / pxPerMhz
                    val s = nearest(f, 0.7f)
                    if (s != null && s.id != idNow) tuneNow(s)
                })
            }
    ) {
        val cx = size.width / 2f
        val h = size.height
        val baseY = h * 0.58f
        val half = cx / pxPerMhz + 0.5f
        val kFrom = floor((shown - half) * 10f).toInt()
        val kTo = ceil((shown + half) * 10f).toInt()

        // garis dasar
        drawLine(Color.White.copy(alpha = 0.14f), Offset(10f, baseY), Offset(size.width - 10f, baseY), strokeWidth = 1.dp.toPx())

        for (k in kFrom..kTo) {
            val f = k / 10f
            if (f < FM_MIN - 0.01f || f > FM_MAX + 0.01f) continue
            val x = cx + (f - shown) * pxPerMhz
            if (x < 0f || x > size.width) continue
            val fade = (1f - abs(x - cx) / cx * 0.75f).coerceIn(0.15f, 1f)
            val major = k % 10 == 0
            val mid = k % 5 == 0
            val len = when {
                major -> h * 0.26f
                mid -> h * 0.17f
                else -> h * 0.09f
            }
            drawLine(
                (if (major) TextHi else TextDim).copy(alpha = fade * (if (major) 0.9f else 0.6f)),
                Offset(x, baseY), Offset(x, baseY + len),
                strokeWidth = (if (major) 1.6f else 1f).dp.toPx(), cap = StrokeCap.Round,
            )
            if (major) {
                val lay = tm.measure("${f.toInt()}", hud(10.sp, TextHi.copy(alpha = fade), mono = true, spacing = 0.sp))
                drawText(lay, topLeft = Offset(x - lay.size.width / 2f, baseY + len + 2.dp.toPx()))
            }
        }

        // penanda stasiun
        for (s in stations) {
            val f = s.freqValue ?: continue
            val x = cx + (f - shown) * pxPerMhz
            if (x < -20f || x > size.width + 20f) continue
            val on = s.id == currentId
            val col = if (on) Cyan else Violet
            val fade = (1f - abs(x - cx) / cx * 0.6f).coerceIn(0.25f, 1f)
            val y = baseY - 12.dp.toPx()
            drawCircle(
                Brush.radialGradient(listOf(col.copy(alpha = 0.55f * fade), Color.Transparent), center = Offset(x, y), radius = 12.dp.toPx()),
                radius = 12.dp.toPx(), center = Offset(x, y),
            )
            drawCircle(col.copy(alpha = fade), radius = if (on) 4.dp.toPx() else 3.dp.toPx(), center = Offset(x, y))
            val nm = s.name.take(9)
            val lay = tm.measure(nm, hud(8.sp, (if (on) Cyan else TextDim).copy(alpha = fade), bold = on, spacing = 0.3.sp))
            drawText(lay, topLeft = Offset(x - lay.size.width / 2f, y - 12.dp.toPx() - lay.size.height))
        }

        // jarum tengah
        drawLine(Magenta.copy(alpha = 0.30f), Offset(cx, 6.dp.toPx()), Offset(cx, h - 6.dp.toPx()), strokeWidth = 6.dp.toPx(), cap = StrokeCap.Round)
        drawLine(Magenta, Offset(cx, 8.dp.toPx()), Offset(cx, h - 8.dp.toPx()), strokeWidth = 2.dp.toPx(), cap = StrokeCap.Round)
        val tri = Path().apply {
            moveTo(cx - 6.dp.toPx(), 0f)
            lineTo(cx + 6.dp.toPx(), 0f)
            lineTo(cx, 9.dp.toPx())
            close()
        }
        drawPath(tri, Magenta)
    }
}


/**
 * Knob tuning besar: ketuk = stasiun berikutnya. Di lingkarnya ada satu titik per channel;
 * titik channel yang sedang aktif menyala. Tulisan "TUNING" ada di bawah knob.
 */
@Composable
fun TuningKnob(count: Int, index: Int, onClick: () -> Unit, modifier: Modifier = Modifier, size: androidx.compose.ui.unit.Dp = 128.dp) {
    // Sudut kumulatif: tiap pindah channel knob berputar searah satu langkah (tidak berputar balik saat kembali ke channel 1)
    var rot by remember { mutableStateOf(if (count > 0 && index >= 0) 360f * index / count else 0f) }
    var last by remember { mutableStateOf(index) }
    LaunchedEffect(index, count) {
        if (count > 0 && index >= 0) {
            if (last in 0 until count) {
                var d = (index - last) % count
                if (d > count / 2) d -= count
                if (d < -count / 2) d += count
                rot += d * 360f / count
            } else {
                rot = 360f * index / count
            }
        }
        last = index
    }
    val ang by animateFloatAsState(
        rot,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow),
        label = "knob",
    )
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier.size(size).clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onClick),
            contentAlignment = Alignment.Center,
        ) {
            Canvas(Modifier.fillMaxSize()) {
                val c = center
                val ringR = this.size.minDimension / 2f - 10.dp.toPx()   // sisakan ruang agar cahaya LED tidak terpotong
                val knobR = ringR - 10.dp.toPx()
                // titik channel (LED kecil)
                if (count > 0) {
                    val dotR = minOf(2.2.dp.toPx(), (2f * Math.PI.toFloat() * ringR / count) * 0.28f)
                    for (i in 0 until count) {
                        val a = Math.toRadians((-90.0 + 360.0 * i / count))
                        val p = Offset(c.x + ringR * Math.cos(a).toFloat(), c.y + ringR * Math.sin(a).toFloat())
                        val on = i == index
                        if (on) {
                            drawCircle(
                                Brush.radialGradient(listOf(Lime.copy(alpha = 0.8f), Color.Transparent), center = p, radius = dotR * 3.6f),
                                radius = dotR * 3.6f, center = p,
                            )
                        }
                        drawCircle(if (on) Lime else Color.White.copy(alpha = 0.22f), radius = if (on) dotR * 1.25f else dotR, center = p)
                    }
                }
                // badan knob: gradasi MELINGKAR (sweep) biru -> ungu -> hijau -> kembali biru
                rotate(ang, pivot = c) {
                    drawCircle(
                        Brush.sweepGradient(listOf(Cyan, Violet, Magenta, Lime, Cyan).map { it.copy(alpha = 0.55f) }, center = c),
                        radius = knobR, center = c,
                    )
                }
                // lubang tengah gelap agar gradasi terlihat seperti cincin neon
                drawCircle(Bg0.copy(alpha = 0.72f), radius = knobR * 0.62f, center = c)
                // border tegas: cincin putih tebal di tepi + garis tipis di tepi cincin dalam
                drawCircle(Color.White.copy(alpha = 0.95f), radius = knobR, center = c, style = Stroke(2.5.dp.toPx()))
                drawCircle(Color.White.copy(alpha = 0.55f), radius = knobR * 0.62f, center = c, style = Stroke(1.5.dp.toPx()))
                // penunjuk mengarah ke channel aktif
                if (index >= 0) {
                    rotate(ang, pivot = c) {
                        drawLine(Color.White, Offset(c.x, c.y - knobR + 7.dp.toPx()), Offset(c.x, c.y - knobR * 0.7f),
                            strokeWidth = 3.5.dp.toPx(), cap = StrokeCap.Round)
                    }
                }
            }
        }
        Text("TUNING", style = hud(12.sp, TextDim, spacing = 1.sp), modifier = Modifier.padding(top = 2.dp))
    }
}

/**
 * Slider kecepatan MP3 (pusat di tengah = normal 1.0x): geser kiri = lambat, kanan = cepat.
 * Di sekitar tengah ada "magnet": jari harus menggeser agak jauh dulu sebelum kecepatan meninggalkan normal,
 * dan saat tertarik ke tengah terasa getar.
 */
@Composable
fun SpeedDial(speed: Float, onChange: (Float) -> Unit, modifier: Modifier = Modifier) {
    val haptic = LocalHapticFeedback.current
    var raw by remember { mutableStateOf(speed) }
    var dragging by remember { mutableStateOf(false) }
    LaunchedEffect(speed) { if (!dragging) raw = speed }

    fun shown(r: Float) = if (abs(r - 1f) < SPEED_MAGNET) 1f else r
    val cur = if (dragging) shown(raw) else speed
    val changeNow by rememberUpdatedState(onChange)
    val normal = abs(cur - 1f) < 0.005f
    val frac = ((cur - SPEED_MIN) / (SPEED_MAX - SPEED_MIN)).coerceIn(0f, 1f)

    Column(modifier.fillMaxWidth(0.8f), horizontalAlignment = Alignment.CenterHorizontally) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("SPEED", style = hud(11.sp, TextDim, bold = true, spacing = 1.4.sp))
            Spacer(Modifier.weight(1f))
            Text(
                if (normal) "1.00x  NORMAL" else "%.2fx".format(java.util.Locale.US, cur),
                style = hud(12.sp, if (normal) Magenta else Cyan, bold = true, mono = true, spacing = 1.sp),
            )
        }
        Canvas(
            Modifier
                .fillMaxWidth()
                .height(48.dp)
                .pointerInput(Unit) {
                    detectHorizontalDragGestures(
                        onDragStart = { dragging = true },
                        onDragEnd = { dragging = false; raw = shown(raw) },
                        onDragCancel = { dragging = false },
                        onHorizontalDrag = { change, dx ->
                            change.consume()
                            val before = shown(raw)
                            val w = (this.size.width - 36.dp.toPx()).coerceAtLeast(1f)
                            raw = (raw + dx / w * (SPEED_MAX - SPEED_MIN)).coerceIn(SPEED_MIN, SPEED_MAX)
                            val after = shown(raw)
                            if (after == 1f && before != 1f) haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            val rounded = Math.round(after * 100f) / 100f
                            if (abs(rounded - before) >= 0.005f) changeNow(rounded)
                        },
                    )
                }
                .pointerInput(Unit) {
                    detectTapGestures(onDoubleTap = { raw = 1f; changeNow(1f) })
                },
        ) {
            val pad = 14.dp.toPx()
            val x0 = pad
            val x1 = size.width - pad
            val cy = size.height * 0.45f
            val cx = (x0 + x1) / 2f
            val tx = x0 + (x1 - x0) * frac
            val th = 8.dp.toPx()
            // jalur
            drawLine(Color.White.copy(alpha = 0.14f), Offset(x0, cy), Offset(x1, cy), strokeWidth = th, cap = StrokeCap.Round)
            // isi dari tengah ke posisi tombol
            drawLine(
                Brush.horizontalGradient(listOf(Violet, Cyan), startX = minOf(cx, tx), endX = maxOf(cx, tx) + 0.1f),
                Offset(cx, cy), Offset(tx, cy), strokeWidth = th, cap = StrokeCap.Round,
            )
            // tanda skala rapat tiap 0.025; tengah lebih panjang
            for (i in 0..20) {
                val x = x0 + (x1 - x0) * i / 20f
                val mid = i == 10
                val major = i % 5 == 0
                val len = if (mid) 9.dp.toPx() else if (major) 7.dp.toPx() else 4.dp.toPx()
                drawLine(
                    if (mid) Magenta else TextDim.copy(alpha = if (major) 0.85f else 0.6f),
                    Offset(x, cy + 10.dp.toPx()), Offset(x, cy + 10.dp.toPx() + len),
                    strokeWidth = (if (mid) 3.5f else if (major) 2.5f else 2f).dp.toPx(), cap = StrokeCap.Round,
                )
            }
            // tombol geser
            val tc = if (normal) Magenta else Cyan
            drawCircle(
                Brush.radialGradient(listOf(tc.copy(alpha = 0.55f), Color.Transparent), center = Offset(tx, cy), radius = 20.dp.toPx()),
                radius = 20.dp.toPx(), center = Offset(tx, cy),
            )
            drawCircle(Bg0, radius = 10.dp.toPx(), center = Offset(tx, cy))
            drawCircle(tc, radius = 10.dp.toPx(), center = Offset(tx, cy), style = Stroke(2.5.dp.toPx()))
            drawCircle(tc, radius = 3.5.dp.toPx(), center = Offset(tx, cy))
        }
        Row(Modifier.fillMaxWidth()) {
            Text("LAMBAT", style = hud(9.sp, TextFaint, spacing = 0.8.sp))
            Spacer(Modifier.weight(1f))
            Text("ketuk 2x = normal", style = hud(9.sp, TextFaint, spacing = 0.8.sp))
            Spacer(Modifier.weight(1f))
            Text("CEPAT", style = hud(9.sp, TextFaint, spacing = 0.8.sp))
        }
    }
}
