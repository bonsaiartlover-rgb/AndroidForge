package com.example.pemutarmusik

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.LibraryMusic
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Radio
import androidx.compose.material.icons.rounded.Remove
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.pemutarmusik.audio.AudioEngine

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AudioEngine.init(applicationContext)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
        )
        // Tombol kembali saat ada suara: jadi mini player melayang (bukan menutup aplikasi)
        onBackPressedDispatcher.addCallback(this, object : androidx.activity.OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (isSoundPlaying() && startFloating(this@MainActivity)) {
                    moveTaskToBack(true)
                } else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                    isEnabled = true
                }
            }
        })
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Cyan, secondary = Violet, tertiary = Magenta,
                    background = Bg0, surface = Bg1, onSurface = TextHi,
                ),
            ) { PlayerApp() }
        }
    }

    /** Tombol home / recents saat ada suara: mini player melayang tampil otomatis. */
    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (isSoundPlaying()) startFloating(this)
    }

    private fun isSoundPlaying(): Boolean = DeckEngine.audioPlaying() || DeckEngine.radioConnecting.value

    override fun onResume() {
        super.onResume()
        // Kembali ke aplikasi = mini player melayang ditutup
        stopService(Intent(this, FloatingPlayerService::class.java))
    }
}

/** Nyalakan mini player melayang kalau izin "tampil di atas aplikasi lain" sudah ada. */
private fun startFloating(context: Context): Boolean {
    if (!Settings.canDrawOverlays(context)) return false
    context.startService(Intent(context, FloatingPlayerService::class.java))
    return true
}

/** Minimize: app turun ke belakang, mini player melayang tampil di depan. */
private fun minimizeToFloating(context: Context) {
    if (!Settings.canDrawOverlays(context)) {
        Toast.makeText(
            context,
            "Aktifkan \"Tampil di atas aplikasi lain\" untuk MP3Radio, lalu tekan minimize lagi.",
            Toast.LENGTH_LONG,
        ).show()
        context.startActivity(
            Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${context.packageName}"))
        )
        return
    }
    context.startService(Intent(context, FloatingPlayerService::class.java))
    (context as? Activity)?.moveTaskToBack(true)
}

private fun audioPermission(): String =
    if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
    else Manifest.permission.READ_EXTERNAL_STORAGE

private fun hasAudioPermission(context: Context): Boolean =
    ContextCompat.checkSelfPermission(context, audioPermission()) == PackageManager.PERMISSION_GRANTED

private fun requestedPermissions(): Array<String> = when {
    Build.VERSION.SDK_INT >= 33 -> arrayOf(audioPermission(), Manifest.permission.POST_NOTIFICATIONS)
    // Android 9 ke bawah: butuh izin tulis untuk menghapus file lagu
    Build.VERSION.SDK_INT <= 28 -> arrayOf(audioPermission(), Manifest.permission.WRITE_EXTERNAL_STORAGE)
    else -> arrayOf(audioPermission())
}

/** Tutup: hentikan pemutaran, tutup mini player dan service pemutar, lalu keluar. */
private fun closeApp(context: Context, vm: PlayerViewModel) {
    vm.saveResume()   // ingat lagu + menit terakhir untuk dibuka lagi nanti
    vm.stopAll()
    context.stopService(Intent(context, FloatingPlayerService::class.java))
    context.stopService(Intent(context, PlaybackService::class.java))
    (context as? Activity)?.finishAndRemoveTask()
}

private enum class Tab(val label: String) { NOW("PUTAR"), LIST("LIST"), EQ("EQ"), VU("VU") }

@Composable
fun PlayerApp(vm: PlayerViewModel = viewModel()) {
    val context = LocalContext.current
    var granted by remember { mutableStateOf(hasAudioPermission(context)) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        granted = hasAudioPermission(context)
    }
    LaunchedEffect(Unit) {
        if (!granted) launcher.launch(requestedPermissions())
    }
    LaunchedEffect(granted) {
        if (granted) vm.loadSongs()
    }

    val deleteLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { res ->
        vm.onDeleteResult(res.resultCode == Activity.RESULT_OK)
    }
    val onDeleteSong: (Song) -> Unit = { song ->
        when (val outcome = vm.requestDelete(song)) {
            is DeleteOutcome.NeedsUser -> deleteLauncher.launch(IntentSenderRequest.Builder(outcome.sender).build())
            DeleteOutcome.Done -> Toast.makeText(context, "Lagu dihapus", Toast.LENGTH_SHORT).show()
            DeleteOutcome.Failed -> Toast.makeText(context, "Gagal menghapus lagu", Toast.LENGTH_SHORT).show()
        }
    }

    val mode by vm.mode.collectAsState()
    var tabIndex by rememberSaveable { mutableStateOf(0) }
    val tab = Tab.values()[tabIndex.coerceIn(0, Tab.values().lastIndex)]

    AuroraBackground {
        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .imePadding()
        ) {
            AppHeader(
                mode = mode,
                onMode = vm::setMode,
                onMinimize = { minimizeToFloating(context) },
                onClose = { closeApp(context, vm) },
            )
            Box(Modifier.weight(1f).fillMaxWidth()) {
                when (tab) {
                    Tab.NOW -> if (mode == AppMode.MP3) Mp3NowScreen(vm) else RadioNowScreen(vm)
                    Tab.LIST -> if (mode == AppMode.MP3) {
                        PlaylistScreen(vm, granted, { launcher.launch(requestedPermissions()) }, onDeleteSong)
                    } else {
                        StationListScreen(vm)
                    }
                    Tab.EQ -> StudioScreen()
                    Tab.VU -> AmpScreen(vm)
                }
            }
            if (tab != Tab.NOW) MiniBar(vm, mode) { tabIndex = Tab.NOW.ordinal }
            BottomNav(tab, mode) { tabIndex = it.ordinal }
        }
    }
}

// ================================================================== HEADER

@Composable
private fun AppHeader(mode: AppMode, onMode: (AppMode) -> Unit, onMinimize: () -> Unit, onClose: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            "MP3Radio",
            style = TextStyle(brush = NeonBrush, fontSize = 14.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp),
            maxLines = 1,
        )
        Spacer(Modifier.weight(1f))
        ModeSwitch(mode, onMode)
        Spacer(Modifier.width(8.dp))
        NeonIconButton(Icons.Rounded.Remove, "Kecilkan ke mini player", onMinimize, size = 34.dp)
        Spacer(Modifier.width(6.dp))
        NeonIconButton(Icons.Rounded.Close, "Tutup aplikasi", onClose, size = 34.dp)
    }
}

@Composable
private fun ModeSwitch(mode: AppMode, onChange: (AppMode) -> Unit) {
    Row(Modifier.height(36.dp).glass(18.dp).padding(3.dp)) {
        listOf(AppMode.MP3 to "MP3", AppMode.RADIO to "RADIO").forEach { (m, label) ->
            val on = mode == m
            Box(
                Modifier
                    .fillMaxHeight()
                    .clip(RoundedCornerShape(15.dp))
                    .then(if (on) Modifier.background(Brush.linearGradient(listOf(Cyan, Violet))) else Modifier)
                    .clickable { onChange(m) }
                    .padding(horizontal = 12.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text(label, style = hud(11.sp, if (on) Bg0 else TextDim, bold = true, spacing = 1.4.sp), maxLines = 1)
            }
        }
    }
}

// ================================================================== MINI BAR & NAV

@Composable
private fun MiniBar(vm: PlayerViewModel, mode: AppMode, onOpen: () -> Unit) {
    val ui by vm.ui.collectAsState()
    val stations by vm.stations.collectAsState()
    val stationId by vm.stationId.collectAsState()
    val connecting by vm.radioConnecting.collectAsState()
    val radio = mode == AppMode.RADIO
    val on = ui.isPlaying || (radio && connecting)
    val st = stations.firstOrNull { it.id == stationId }
    val title = if (radio) (st?.name ?: "Pilih stasiun") else (ui.title ?: "Belum ada lagu")
    val sub = if (radio) (st?.freqValue?.let { "FM %.1f MHz".format(java.util.Locale.US, it) } ?: "Radio") else (ui.artist ?: "")

    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp)
            .glass(24.dp, Cyan, 0.9f)
            .clickable(onClick = onOpen)
            .padding(start = 16.dp, end = 8.dp, top = 6.dp, bottom = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(if (radio) Icons.Rounded.Radio else Icons.Rounded.MusicNote, null, tint = Cyan, modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(title, style = hud(13.sp, TextHi, bold = true, spacing = 0.3.sp), maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (sub.isNotBlank()) Text(sub, style = hud(10.sp, TextDim, spacing = 0.3.sp), maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        NeonIconButton(
            if (on) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
            if (on) "Jeda" else "Putar",
            {
                if (radio) { if (on) vm.radioPause() else vm.radioPlay() }
                else { if (ui.isPlaying) vm.pause() else vm.play() }
            },
            size = 42.dp, filled = true,
        )
    }
    Spacer(Modifier.height(6.dp))
}

@Composable
private fun BottomNav(current: Tab, mode: AppMode, onSelect: (Tab) -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 8.dp)
            .glass(28.dp)
            .padding(vertical = 6.dp),
    ) {
        for (t in Tab.values()) {
            val icon: ImageVector = when (t) {
                Tab.NOW -> if (mode == AppMode.MP3) Icons.Rounded.MusicNote else Icons.Rounded.Radio
                Tab.LIST -> Icons.Rounded.LibraryMusic
                Tab.EQ -> Icons.Rounded.Tune
                Tab.VU -> Icons.Rounded.Speed
            }
            val on = t == current
            Column(
                Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(20.dp))
                    .clickable { onSelect(t) }
                    .padding(vertical = 4.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Box(
                    Modifier
                        .then(if (on) Modifier.neonGlow(Cyan, 14.dp, 0.35f) else Modifier)
                        .size(width = 46.dp, height = 28.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .then(if (on) Modifier.background(Cyan.copy(alpha = 0.18f)) else Modifier),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(icon, t.label, tint = if (on) Cyan else TextDim, modifier = Modifier.size(22.dp))
                }
                Text(t.label, style = hud(9.sp, if (on) Cyan else TextDim, bold = true, spacing = 1.4.sp), maxLines = 1)
            }
        }
    }
}
