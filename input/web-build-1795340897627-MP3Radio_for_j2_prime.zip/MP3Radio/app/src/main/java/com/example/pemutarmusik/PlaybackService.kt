package com.example.pemutarmusik

import android.content.Intent
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.Player
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.Renderer
import androidx.media3.exoplayer.RenderersFactory
import androidx.media3.exoplayer.audio.DefaultAudioSink
import androidx.media3.exoplayer.audio.MediaCodecAudioRenderer
import androidx.media3.exoplayer.mediacodec.MediaCodecSelector
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import com.example.pemutarmusik.audio.AudioEngine
import com.example.pemutarmusik.audio.EqAudioProcessor

/**
 * Service pemutar: musik / radio tetap jalan saat aplikasi ditutup/layar mati,
 * lengkap dengan notifikasi kontrol.
 *
 * Ada DUA ExoPlayer: satu untuk MP3, satu untuk radio, masing-masing dengan equalizer sendiri.
 * Dengan begitu lagu bisa tetap berbunyi (dan posisinya tersimpan) selagi radio menyambung, dan sebaliknya.
 * [DeckEngine] mengatur serah-terima suara; MediaSession (notifikasi) selalu mengikuti player yang sedang berbunyi.
 */
class PlaybackService : MediaSessionService() {

    private var mediaSession: MediaSession? = null
    private var mp3Player: ExoPlayer? = null
    private var radioPlayer: ExoPlayer? = null

    private fun buildPlayer(processor: EqAudioProcessor, isRadio: Boolean): ExoPlayer {
        // Renderer audio saja, dengan AudioSink yang memakai equalizer kita.
        val renderersFactory = RenderersFactory { handler, _, audioListener, _, _ ->
            val sink = DefaultAudioSink.Builder(this)
                .setAudioProcessors(arrayOf<AudioProcessor>(processor))
                .build()
            arrayOf<Renderer>(
                MediaCodecAudioRenderer(this, MediaCodecSelector.DEFAULT, handler, audioListener, sink)
            )
        }

        // Sumber data untuk radio streaming (http/https): ikuti redirect, batas waktu 15 dtk.
        // User-Agent sengaja bukan "Mozilla": server Shoutcast lama memberi halaman web, bukan audio, ke browser.
        val httpFactory = DefaultHttpDataSource.Factory()
            .setUserAgent("MusicPlayerMod/1.0 (Android)")
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(15_000)
            .setReadTimeoutMs(15_000)
        val mediaSourceFactory = DefaultMediaSourceFactory(DefaultDataSource.Factory(this, httpFactory))

        val player = ExoPlayer.Builder(this, renderersFactory)
            .setMediaSourceFactory(mediaSourceFactory)
            .setWakeMode(if (isRadio) C.WAKE_MODE_NETWORK else C.WAKE_MODE_LOCAL) // radio tetap tersambung saat layar mati
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .build(),
                /* handleAudioFocus = */ true
            )
            .setHandleAudioBecomingNoisy(true) // pause otomatis saat headset dicabut
            .build()
        player.repeatMode = if (isRadio) Player.REPEAT_MODE_OFF else Player.REPEAT_MODE_ALL
        return player
    }

    override fun onCreate() {
        super.onCreate()
        AudioEngine.init(this)

        val mp3 = buildPlayer(AudioEngine.mp3Processor, isRadio = false)
        val radio = buildPlayer(AudioEngine.radioProcessor, isRadio = true)
        mp3Player = mp3
        radioPlayer = radio

        // Sesi (notifikasi / layar kunci) mulai dengan player MP3; DeckEngine memindahkannya ke radio saat radio live.
        val session = MediaSession.Builder(this, mp3).build()
        mediaSession = session

        DeckEngine.attach(this, mp3, radio, session)
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = mediaSession

    override fun onTaskRemoved(rootIntent: Intent?) {
        // Aplikasi di-swipe dari recent apps -> hentikan musik / radio.
        DeckEngine.saveResume()
        DeckEngine.pauseAll()
        pauseAllPlayersAndStopSelf()
    }

    override fun onDestroy() {
        DeckEngine.detach()
        mediaSession?.release()
        mediaSession = null
        mp3Player?.release()
        radioPlayer?.release()
        mp3Player = null
        radioPlayer = null
        super.onDestroy()
    }
}
