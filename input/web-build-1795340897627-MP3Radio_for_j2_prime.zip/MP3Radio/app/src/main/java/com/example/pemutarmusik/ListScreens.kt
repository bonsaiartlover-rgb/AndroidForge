package com.example.pemutarmusik

import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private const val ALL = -1L

// ================================================================== DIALOG & BANTU

@Composable
fun NeonDialog(title: String, onDismiss: () -> Unit, content: @Composable () -> Unit) {
    val shape = RoundedCornerShape(26.dp)
    Dialog(onDismissRequest = onDismiss) {
        Column(
            Modifier
                .fillMaxWidth()
                .clip(shape)
                .background(Brush.verticalGradient(listOf(Color(0xFF161E4E), Color(0xFF0A1030))))
                .border(1.dp, Brush.linearGradient(listOf(Cyan.copy(alpha = 0.6f), Violet.copy(alpha = 0.3f), Magenta.copy(alpha = 0.5f))), shape)
                .padding(18.dp)
        ) {
            Text(title, style = hud(13.sp, Cyan, bold = true, spacing = 2.sp))
            Spacer(Modifier.height(12.dp))
            content()
        }
    }
}

@Composable
fun NeonTextButton(text: String, color: Color = Cyan, onClick: () -> Unit) {
    Text(
        text,
        style = hud(13.sp, color, bold = true, spacing = 1.4.sp),
        modifier = Modifier.clip(RoundedCornerShape(12.dp)).clickable(onClick = onClick).padding(horizontal = 12.dp, vertical = 10.dp),
    )
}

@Composable
fun NeonField(
    value: String,
    onChange: (String) -> Unit,
    label: String,
    modifier: Modifier = Modifier,
    keyboard: KeyboardType = KeyboardType.Text,
    maxLines: Int = 1,
) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(label) },
        singleLine = maxLines == 1,
        maxLines = maxLines,
        keyboardOptions = KeyboardOptions(keyboardType = keyboard),
        textStyle = hud(15.sp, TextHi, spacing = 0.sp),
        shape = RoundedCornerShape(14.dp),
        colors = OutlinedTextFieldDefaults.colors(
            focusedTextColor = TextHi,
            unfocusedTextColor = TextHi,
            focusedBorderColor = Cyan,
            unfocusedBorderColor = Color.White.copy(alpha = 0.2f),
            focusedLabelColor = Cyan,
            unfocusedLabelColor = TextDim,
            cursorColor = Cyan,
        ),
        modifier = modifier.fillMaxWidth(),
    )
}

@Composable
private fun NameDialog(title: String, initial: String, confirm: String, onConfirm: (String) -> Unit, onDismiss: () -> Unit) {
    var text by remember { mutableStateOf(initial) }
    NeonDialog(title, onDismiss) {
        NeonField(text, { text = it.replace("\n", "").take(40) }, "Nama")
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
            NeonTextButton("BATAL", TextDim, onDismiss)
            NeonTextButton(confirm) { if (text.isNotBlank()) onConfirm(text.trim()) }
        }
    }
}

@Composable
private fun NeonSearch(query: String, onChange: (String) -> Unit, modifier: Modifier = Modifier) {
    Row(
        modifier.height(44.dp).glass(22.dp).padding(horizontal = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(Icons.Rounded.Search, null, tint = TextDim, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(8.dp))
        Box(Modifier.weight(1f)) {
            if (query.isEmpty()) Text("Cari judul / artis / album", style = hud(14.sp, TextFaint, spacing = 0.sp))
            BasicTextField(
                value = query,
                onValueChange = onChange,
                singleLine = true,
                textStyle = hud(14.sp, TextHi, spacing = 0.sp),
                cursorBrush = SolidColor(Cyan),
                modifier = Modifier.fillMaxWidth(),
            )
        }
        if (query.isNotEmpty()) {
            Icon(Icons.Rounded.Close, "Hapus pencarian", tint = TextDim, modifier = Modifier.size(18.dp).clickable { onChange("") })
        }
    }
}

@Composable
private fun MenuItem(text: String, danger: Boolean = false, onClick: () -> Unit) {
    DropdownMenuItem(
        text = { Text(text, style = hud(14.sp, if (danger) Danger else TextHi, spacing = 0.sp)) },
        onClick = onClick,
    )
}

private fun formatSize(bytes: Long): String = "%.1f MB".format(Locale.US, bytes / 1048576.0)

@Composable
private fun DetailRow(label: String, value: String) {
    Column(Modifier.padding(vertical = 4.dp)) {
        Text(label, style = hud(10.sp, TextDim, bold = true, spacing = 1.6.sp))
        Text(value, style = hud(14.sp, TextHi, spacing = 0.sp))
    }
}

@Composable
private fun DetailsDialog(song: Song, onDismiss: () -> Unit) {
    NeonDialog("RINCIAN LAGU", onDismiss) {
        Column(Modifier.heightIn(max = 380.dp).verticalScroll(rememberScrollState())) {
            DetailRow("JUDUL", song.title)
            DetailRow("ARTIS", song.artist)
            DetailRow("ALBUM", song.album)
            DetailRow("DURASI", formatTime(song.durationMs))
            DetailRow("UKURAN", formatSize(song.sizeBytes))
            DetailRow("NAMA FILE", song.fileName)
            DetailRow("LOKASI", song.path)
            DetailRow("DITAMBAHKAN", SimpleDateFormat("dd MMM yyyy HH:mm", Locale("id")).format(Date(song.dateAddedSec * 1000L)))
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) { NeonTextButton("TUTUP", Cyan, onDismiss) }
    }
}

// ================================================================== PLAYLIST MP3

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun AlbumChip(name: String, active: Boolean, onClick: () -> Unit, onLong: (() -> Unit)? = null) {
    val shape = RoundedCornerShape(50)
    Box(
        Modifier
            .height(34.dp)
            .clip(shape)
            .background(if (active) Violet.copy(alpha = 0.24f) else Color.White.copy(alpha = 0.05f))
            .border(1.dp, if (active) Violet else Color.White.copy(alpha = 0.16f), shape)
            .combinedClickable(onClick = onClick, onLongClick = onLong)
            .padding(horizontal = 14.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(name, style = hud(12.sp, if (active) TextHi else TextDim, bold = true, spacing = 1.sp), maxLines = 1)
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun SongRow(
    song: Song,
    isCurrent: Boolean,
    playing: Boolean,
    onClick: () -> Unit,
    menu: @Composable (close: () -> Unit) -> Unit,
) {
    var open by remember { mutableStateOf(false) }
    val shape = RoundedCornerShape(18.dp)
    Box(Modifier.fillMaxWidth()) {
        Row(
            Modifier
                .fillMaxWidth()
                .clip(shape)
                .background(if (isCurrent) Cyan.copy(alpha = 0.12f) else Color.White.copy(alpha = 0.04f))
                .border(1.dp, if (isCurrent) Cyan.copy(alpha = 0.7f) else Color.White.copy(alpha = 0.08f), shape)
                .combinedClickable(onClick = onClick, onLongClick = { open = true })
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(
                Modifier.size(38.dp).clip(CircleShape)
                    .background(Brush.linearGradient(if (isCurrent) listOf(Cyan, Violet) else listOf(Color(0xFF1A2358), Color(0xFF0E1438)))),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    if (isCurrent && playing) Icons.Rounded.GraphicEq else Icons.Rounded.MusicNote, null,
                    tint = if (isCurrent) Bg0 else TextDim, modifier = Modifier.size(20.dp),
                )
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(song.title, style = hud(14.sp, if (isCurrent) Cyan else TextHi, bold = isCurrent, spacing = 0.2.sp), maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(song.artist, style = hud(11.sp, TextDim, spacing = 0.3.sp), maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Spacer(Modifier.width(8.dp))
            Text(formatTime(song.durationMs), style = hud(11.sp, TextDim, mono = true, spacing = 0.sp))
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }, containerColor = Color(0xFF141B45)) {
            menu { open = false }
        }
    }
}

@Composable
private fun AddSongsDialog(songs: List<Song>, onConfirm: (List<Long>) -> Unit, onDismiss: () -> Unit) {
    val picked = remember { mutableStateListOf<Long>() }
    NeonDialog("TAMBAH LAGU KE ALBUM", onDismiss) {
        if (songs.isEmpty()) {
            Text("Semua lagu sudah ada di album ini.", style = hud(13.sp, TextDim, spacing = 0.2.sp))
        } else {
            Text("Ketuk lagu sesuai urutan yang diinginkan.", style = hud(11.sp, TextDim, spacing = 0.2.sp))
            Spacer(Modifier.height(8.dp))
            LazyColumn(Modifier.heightIn(max = 340.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                items(songs, key = { it.id }) { s ->
                    val order = picked.indexOf(s.id)
                    val on = order >= 0
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(if (on) Cyan.copy(alpha = 0.14f) else Color.White.copy(alpha = 0.04f))
                            .clickable { if (on) picked.remove(s.id) else picked.add(s.id) }
                            .padding(horizontal = 10.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Box(
                            Modifier.size(26.dp).clip(CircleShape)
                                .background(if (on) Cyan else Color.White.copy(alpha = 0.08f)),
                            contentAlignment = Alignment.Center,
                        ) {
                            if (on) Text("${order + 1}", style = hud(11.sp, Bg0, bold = true, mono = true, spacing = 0.sp))
                        }
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(s.title, style = hud(13.sp, TextHi, spacing = 0.sp), maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(s.artist, style = hud(10.sp, TextDim, spacing = 0.sp), maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
            NeonTextButton("BATAL", TextDim, onDismiss)
            NeonTextButton("TAMBAH (${picked.size})") { if (picked.isNotEmpty()) onConfirm(picked.toList()) }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun PlaylistScreen(
    vm: PlayerViewModel,
    granted: Boolean,
    onRequestPermission: () -> Unit,
    onDeleteSong: (Song) -> Unit,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    val songs by vm.songs.collectAsState()
    val loaded by vm.loaded.collectAsState()
    val albums by vm.albums.collectAsState()
    val ui by vm.ui.collectAsState()

    var selected by rememberSaveable { mutableStateOf(ALL) }
    val current = albums.firstOrNull { it.id == selected }          // null = semua lagu
    val byId = remember(songs) { songs.associateBy { it.id } }
    // SEMUA: terbaru di atas. Di dalam album: urutan album (bisa digeser Naikkan/Turunkan).
    val list = if (current == null) songs.sortedByDescending { it.dateAddedSec } else current.songIds.mapNotNull { byId[it] }

    var query by rememberSaveable { mutableStateOf("") }
    val q = query.trim()
    val shown = if (q.isEmpty()) list else list.filter {
        it.title.contains(q, ignoreCase = true) || it.artist.contains(q, ignoreCase = true) ||
            it.album.contains(q, ignoreCase = true)
    }

    var details by remember { mutableStateOf<Song?>(null) }
    var moveSong by remember { mutableStateOf<Song?>(null) }
    var deleteConfirm by remember { mutableStateOf<Song?>(null) }
    var newAlbumFor by remember { mutableStateOf<List<Long>?>(null) }   // non-null = dialog nama album baru, isi = lagu awal
    var renameAlbum by remember { mutableStateOf<Album?>(null) }
    var addDialog by remember { mutableStateOf(false) }
    var albumMenu by remember { mutableStateOf<Long?>(null) }

    fun toast(msg: String) = Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()

    Column(modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            AlbumChip("SEMUA", current == null, { selected = ALL })
            albums.forEach { a ->
                Box {
                    AlbumChip(a.name, current?.id == a.id, { selected = a.id }, { albumMenu = a.id })
                    DropdownMenu(
                        expanded = albumMenu == a.id,
                        onDismissRequest = { albumMenu = null },
                        containerColor = Color(0xFF141B45),
                    ) {
                        MenuItem("Ganti nama") { albumMenu = null; renameAlbum = a }
                        MenuItem("Hapus album", danger = true) {
                            albumMenu = null
                            vm.deleteAlbum(a.id)
                            if (selected == a.id) selected = ALL
                            toast("Album dihapus")
                        }
                    }
                }
            }
            AlbumChip("+ ALBUM", false, { newAlbumFor = emptyList() })
        }
        Spacer(Modifier.height(10.dp))
        NeonSearch(query, { query = it }, Modifier.fillMaxWidth())
        if (current != null) {
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("${current.name}  ·  ${list.size} lagu", style = hud(11.sp, TextDim, bold = true, spacing = 1.2.sp), modifier = Modifier.weight(1f), maxLines = 1)
                NeonChip("TAMBAH LAGU", false, { addDialog = true }, color = Violet)
            }
        }
        Spacer(Modifier.height(10.dp))

        Box(Modifier.weight(1f).fillMaxWidth()) {
            when {
                !granted -> Column(
                    Modifier.fillMaxSize().padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp, Alignment.CenterVertically),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Text("Butuh izin membaca file musik (MP3).", style = hud(13.sp, TextHi, spacing = 0.2.sp), textAlign = TextAlign.Center)
                    NeonChip("IZINKAN AKSES MUSIK", true, onRequestPermission)
                    Text(
                        "Kalau dialog tidak muncul: Pengaturan > Aplikasi > MP3Radio > Izin.",
                        style = hud(10.sp, TextDim, spacing = 0.2.sp), textAlign = TextAlign.Center,
                    )
                }
                current == null && loaded && songs.isEmpty() -> EmptyNote("Tidak ada file MP3 di penyimpanan.")
                current != null && list.isEmpty() -> EmptyNote("Album masih kosong.\nTekan TAMBAH LAGU, atau tekan lama lagu di SEMUA lalu pilih \"Pindah ke album\".")
                q.isNotEmpty() && shown.isEmpty() -> EmptyNote("Tidak ada lagu yang cocok dengan \"$q\".")
                else -> LazyColumn(
                    Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    contentPadding = PaddingValues(bottom = 12.dp),
                ) {
                    items(shown, key = { it.id }) { song ->
                        SongRow(
                            song = song,
                            isCurrent = ui.mediaId == song.id.toString(),
                            playing = ui.isPlaying,
                            onClick = { vm.playList(list, song) },
                            menu = { close ->
                                MenuItem("Pindah ke album") { close(); moveSong = song }
                                if (current != null) {
                                    MenuItem("Naikkan") { close(); vm.moveInAlbum(current.id, song.id, -1) }
                                    MenuItem("Turunkan") { close(); vm.moveInAlbum(current.id, song.id, 1) }
                                    MenuItem("Keluarkan dari album") { close(); vm.removeFromAlbum(current.id, song.id) }
                                }
                                MenuItem("Rincian") { close(); details = song }
                                MenuItem("Hapus lagu", danger = true) { close(); deleteConfirm = song }
                            },
                        )
                    }
                }
            }
        }
    }

    // ---- dialog
    details?.let { DetailsDialog(it) { details = null } }

    deleteConfirm?.let { s ->
        NeonDialog("HAPUS LAGU?", { deleteConfirm = null }) {
            Text("\"${s.title}\" akan dihapus dari HP.", style = hud(14.sp, TextHi, spacing = 0.2.sp))
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                NeonTextButton("BATAL", TextDim) { deleteConfirm = null }
                NeonTextButton("HAPUS", Danger) { deleteConfirm = null; onDeleteSong(s) }
            }
        }
    }

    moveSong?.let { s ->
        NeonDialog("PINDAH KE ALBUM", { moveSong = null }) {
            Column(Modifier.heightIn(max = 340.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                albums.forEach { a ->
                    Text(
                        a.name,
                        style = hud(14.sp, TextHi, spacing = 0.2.sp),
                        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Color.White.copy(alpha = 0.05f))
                            .clickable {
                                vm.addToAlbum(a.id, listOf(s.id))
                                toast("Ditambahkan ke ${a.name}")
                                moveSong = null
                            }
                            .padding(14.dp),
                    )
                }
                Text(
                    "+ Album baru…",
                    style = hud(14.sp, Cyan, bold = true, spacing = 0.2.sp),
                    modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Cyan.copy(alpha = 0.10f))
                        .clickable { moveSong = null; newAlbumFor = listOf(s.id) }
                        .padding(14.dp),
                )
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) { NeonTextButton("BATAL", TextDim) { moveSong = null } }
        }
    }

    newAlbumFor?.let { first ->
        NameDialog("ALBUM BARU", "", "BUAT", { name ->
            val id = vm.createAlbum(name, first)
            newAlbumFor = null
            selected = id
            if (first.isEmpty()) addDialog = true
        }, { newAlbumFor = null })
    }

    renameAlbum?.let { a ->
        NameDialog("GANTI NAMA ALBUM", a.name, "SIMPAN", { vm.renameAlbum(a.id, it); renameAlbum = null }, { renameAlbum = null })
    }

    if (addDialog && current != null) {
        val inAlbum = current.songIds.toSet()
        AddSongsDialog(
            songs = songs.sortedByDescending { it.dateAddedSec }.filter { it.id !in inAlbum },
            onConfirm = { ids -> vm.addToAlbum(current.id, ids); addDialog = false },
            onDismiss = { addDialog = false },
        )
    }
}

@Composable
private fun EmptyNote(text: String) {
    Box(Modifier.fillMaxSize().padding(16.dp), contentAlignment = Alignment.Center) {
        Text(text, style = hud(13.sp, TextDim, spacing = 0.2.sp), textAlign = TextAlign.Center)
    }
}

// ================================================================== DAFTAR STASIUN RADIO

/** Rapikan alamat: tambahkan https:// kalau belum ada. Mengembalikan null kalau bukan alamat yang valid. */
private fun normalizeUrl(raw: String): String? {
    val t = raw.trim()
    if (t.isEmpty()) return null
    val full = if (t.startsWith("http://", true) || t.startsWith("https://", true)) t else "https://$t"
    val host = try { Uri.parse(full).host } catch (e: Exception) { null }
    return if (!host.isNullOrBlank() && host.contains('.')) full else null
}

@Composable
fun StationListScreen(vm: PlayerViewModel, modifier: Modifier = Modifier) {
    val stations by vm.stations.collectAsState()
    val stationId by vm.stationId.collectAsState()
    val ui by vm.ui.collectAsState()
    var editing by remember { mutableStateOf<RadioStation?>(null) }
    var adding by remember { mutableStateOf(false) }

    Column(modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("STASIUN RADIO  ·  ${stations.size}", style = hud(11.sp, Cyan, bold = true, spacing = 2.sp), modifier = Modifier.weight(1f))
            NeonChip("+ STASIUN", false, { adding = true }, color = Violet)
        }
        Spacer(Modifier.height(10.dp))
        LazyColumn(
            Modifier.weight(1f).fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            contentPadding = PaddingValues(bottom = 12.dp),
        ) {
            items(stations, key = { it.id }) { st ->
                val on = st.id == stationId
                val shape = RoundedCornerShape(18.dp)
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clip(shape)
                        .background(if (on) Cyan.copy(alpha = 0.12f) else Color.White.copy(alpha = 0.04f))
                        .border(1.dp, if (on) Cyan.copy(alpha = 0.7f) else Color.White.copy(alpha = 0.08f), shape)
                        .clickable { vm.playStation(st) }
                        .padding(start = 14.dp, top = 6.dp, bottom = 6.dp, end = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        st.freqValue?.let { "%.1f".format(Locale.US, it) } ?: "--.-",
                        style = hud(18.sp, if (on) Cyan else TextHi, bold = true, mono = true, spacing = 0.sp),
                        modifier = Modifier.width(64.dp),
                    )
                    Column(Modifier.weight(1f)) {
                        Text(st.name, style = hud(14.sp, if (on) Cyan else TextHi, bold = on, spacing = 0.2.sp), maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(
                            if (on && ui.isPlaying) "● LIVE" else "FM",
                            style = hud(10.sp, if (on && ui.isPlaying) Lime else TextDim, bold = true, spacing = 1.2.sp),
                        )
                    }
                    Box(
                        Modifier.size(44.dp).clip(CircleShape).clickable { editing = st },
                        contentAlignment = Alignment.Center,
                    ) {
                        Icon(Icons.Rounded.Edit, "Edit stasiun", tint = TextDim, modifier = Modifier.size(18.dp))
                    }
                }
            }
        }
    }

    if (adding) {
        StationDialog(
            initial = null,
            onSave = { n, f, u -> vm.addStation(n, f, u); adding = false },
            onDelete = null,
            onDismiss = { adding = false },
        )
    }
    editing?.let { st ->
        StationDialog(
            initial = st,
            onSave = { n, f, u -> vm.updateStation(st.id, n, f, u); editing = null },
            onDelete = { vm.deleteStation(st.id); editing = null },
            onDismiss = { editing = null },
        )
    }
}

@Composable
private fun StationDialog(
    initial: RadioStation?,
    onSave: (name: String, freq: String, url: String) -> Unit,
    onDelete: (() -> Unit)?,
    onDismiss: () -> Unit,
) {
    var name by remember { mutableStateOf(initial?.name ?: "") }
    var freq by remember { mutableStateOf(initial?.freq ?: "") }
    var url by remember { mutableStateOf(initial?.url ?: "") }
    var problem by remember { mutableStateOf<String?>(null) }
    var confirmDelete by remember { mutableStateOf(false) }

    fun trySave() {
        val cleanUrl = normalizeUrl(url)
        val f = freq.trim().replace(',', '.')
        val fNum = f.toFloatOrNull()
        when {
            name.isBlank() -> problem = "Nama stasiun belum diisi."
            cleanUrl == null -> problem = "Alamat URL tidak valid."
            f.isNotEmpty() && (fNum == null || fNum !in 76f..108f) -> problem = "Frekuensi FM harus 76 - 108 MHz (contoh 99.5)."
            else -> onSave(
                name.trim(),
                if (fNum != null) String.format(Locale.US, "%.1f", fNum) else "",
                cleanUrl.orEmpty(),
            )
        }
    }

    // Layar penuh + imePadding: panel naik di atas keyboard; tombol ada di bar atas supaya tidak tertutup.
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false),
    ) {
        val panel = RoundedCornerShape(26.dp)
        Box(
            Modifier.fillMaxSize().background(Color(0xCC02030A)).systemBarsPadding().imePadding().padding(12.dp),
            contentAlignment = Alignment.TopCenter,
        ) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .clip(panel)
                    .background(Brush.verticalGradient(listOf(Color(0xFF161E4E), Color(0xFF0A1030))))
                    .border(1.dp, Brush.linearGradient(listOf(Cyan.copy(alpha = 0.6f), Violet.copy(alpha = 0.3f), Magenta.copy(alpha = 0.5f))), panel)
            ) {
                Row(
                    Modifier.fillMaxWidth().padding(start = 18.dp, end = 6.dp, top = 6.dp, bottom = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        if (initial == null) "TAMBAH STASIUN" else "EDIT STASIUN",
                        style = hud(13.sp, Cyan, bold = true, spacing = 2.sp), modifier = Modifier.weight(1f),
                    )
                    if (onDelete != null) {
                        NeonTextButton(if (confirmDelete) "YAKIN?" else "HAPUS", Danger) {
                            if (confirmDelete) onDelete() else confirmDelete = true
                        }
                    }
                    NeonTextButton("BATAL", TextDim, onDismiss)
                    NeonTextButton("SIMPAN", Cyan) { trySave() }
                }
                Box(Modifier.fillMaxWidth().height(1.dp).background(Color.White.copy(alpha = 0.10f)))
                Column(
                    Modifier.weight(1f, fill = false).verticalScroll(rememberScrollState()).padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    NeonField(name, { name = it.replace("\n", "").take(40); problem = null }, "Nama stasiun")
                    NeonField(freq, { freq = it.take(6); problem = null }, "Frekuensi FM (MHz, boleh kosong)", keyboard = KeyboardType.Decimal)
                    NeonField(url, { url = it.replace("\n", ""); problem = null }, "Alamat stream (URL)", keyboard = KeyboardType.Uri, maxLines = 4)
                    Text(
                        "Alamat harus langsung ke stream audio (MP3/AAC/HLS). Alamat berakhiran \"/\" yang gagal otomatis dicoba dengan \"/;\".",
                        style = hud(10.sp, TextDim, spacing = 0.2.sp),
                    )
                    problem?.let { Text(it, style = hud(12.sp, Danger, spacing = 0.2.sp)) }
                }
            }
        }
    }
}
