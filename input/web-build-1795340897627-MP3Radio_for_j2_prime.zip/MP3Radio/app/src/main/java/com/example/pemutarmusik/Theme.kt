package com.example.pemutarmusik

import android.content.Context
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// ------------------------------------------------------------------ palet NEON DECK
val Bg0 = Color(0xFF05060F)        // hitam angkasa
val Bg1 = Color(0xFF0B1030)        // biru malam
val Cyan = Color(0xFF22E5FF)       // aksen utama
val Violet = Color(0xFF8B5CFF)     // aksen kedua
val Magenta = Color(0xFFFF3DDB)    // aksen puncak
val Lime = Color(0xFF9DFF4A)       // status hidup / LIVE
val Amber = Color(0xFFFFB020)
val Danger = Color(0xFFFF4D6D)     // zona merah VU
val TextHi = Color(0xFFEAF6FF)
val TextDim = Color(0xFF7C8BB0)
val TextFaint = Color(0xFF47527A)

val NeonBrush: Brush get() = Brush.linearGradient(listOf(Cyan, Violet, Magenta))

val Mono = FontFamily.Monospace
val Sans = FontFamily.SansSerif

/** Gaya teks HUD: huruf lebar, renggang. */
fun hud(size: TextUnit, color: Color = TextDim, bold: Boolean = false, spacing: TextUnit = 1.2.sp, mono: Boolean = false) =
    TextStyle(
        color = color,
        fontSize = size,
        fontFamily = if (mono) Mono else Sans,
        fontWeight = if (bold) FontWeight.Bold else FontWeight.Medium,
        letterSpacing = spacing,
    )

/** Kompatibilitas dengan FloatingPlayerService (mini player melayang). */
class LedPalette(val c3: Color, val specLow: Color, val specHigh: Color)

object Skin {
    val p = LedPalette(c3 = Cyan, specLow = Cyan, specHigh = Magenta)
    @Suppress("UNUSED_PARAMETER")
    fun init(context: Context) {
    }
}

/** Panel kaca: isi putih tipis, tepi berkilau dari atas ke bawah. */
fun Modifier.glass(radius: Dp = 22.dp, tint: Color = Color.White, strength: Float = 1f): Modifier {
    val shape = RoundedCornerShape(radius)
    return this
        .clip(shape)
        .background(
            Brush.verticalGradient(
                listOf(tint.copy(alpha = 0.10f * strength), tint.copy(alpha = 0.03f * strength))
            )
        )
        .border(
            1.dp,
            Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.26f), Color.White.copy(alpha = 0.04f))),
            shape,
        )
}

/** Cahaya neon bulat di belakang komponen (jangan di-clip oleh induk). */
fun Modifier.neonGlow(color: Color, radius: Dp, alpha: Float = 0.42f): Modifier = this.drawBehind {
    val r = radius.toPx() * 1.9f
    drawCircle(
        brush = Brush.radialGradient(listOf(color.copy(alpha = alpha), Color.Transparent), center = center, radius = r),
        radius = r,
        center = center,
    )
}

/** Latar aurora: gradasi gelap dengan tiga cahaya violet / cyan / magenta yang pelan bergeser. */
@Composable
fun AuroraBackground(modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    val t = rememberInfiniteTransition(label = "aurora")
    val drift by t.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(22000, easing = LinearEasing), RepeatMode.Reverse),
        label = "drift",
    )
    Box(modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Bg1, Bg0)))) {
        Canvas(Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            fun glow(cx: Float, cy: Float, r: Float, c: Color) {
                drawCircle(
                    brush = Brush.radialGradient(listOf(c, Color.Transparent), center = Offset(cx, cy), radius = r),
                    radius = r,
                    center = Offset(cx, cy),
                )
            }
            glow(w * (0.10f + 0.35f * drift), h * 0.10f, w * 0.95f, Violet.copy(alpha = 0.34f))
            glow(w * (0.95f - 0.40f * drift), h * 0.46f, w * 0.85f, Cyan.copy(alpha = 0.14f))
            glow(w * (0.20f + 0.30f * drift), h * 0.98f, w * 0.95f, Magenta.copy(alpha = 0.18f))
        }
        content()
    }
}
